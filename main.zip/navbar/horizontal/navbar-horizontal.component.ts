import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { UditMainComponent } from '../../main.component';

@Component({
    selector     : 'udit-navbar-horizontal',
    templateUrl  : './navbar-horizontal.component.html',
    styleUrls    : ['./navbar-horizontal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class UditNavbarHorizontalComponent implements OnInit, OnDestroy
{
    constructor(private uditMainComponent: UditMainComponent)
    {
    }

    ngOnInit()
    {
        this.uditMainComponent.addClass('udit-nav-bar-horizontal');
    }

    ngOnDestroy()
    {
        this.uditMainComponent.removeClass('udit-nav-bar-horizontal');
    }
}
