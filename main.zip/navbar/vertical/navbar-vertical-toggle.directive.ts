import { Directive, HostListener, Input } from '@angular/core';
import { UditNavbarVerticalService } from './navbar-vertical.service';
import { UditNavbarVerticalComponent } from './navbar-vertical.component';

@Directive({
    selector: '[uditNavbarVertical]'
})
export class UditNavbarVerticalToggleDirective
{
    @Input() uditNavbarVertical: string;
    navbar: UditNavbarVerticalComponent;

    constructor(private navbarService: UditNavbarVerticalService)
    {
    }

    @HostListener('click')
    onClick()
    {
        this.navbar = this.navbarService.getNavBar();

        if ( !this.navbar[this.uditNavbarVertical] )
        {
            return;
        }

        this.navbar[this.uditNavbarVertical]();
    }
}
