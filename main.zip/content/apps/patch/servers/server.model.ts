import { UditUtils } from '../../../../../core/uditUtils';

export class Server {
    id: string;
    last_update: string;
    _server_type: string;
    _server: string;
    loc_data: any;
    sys_config: any;
    cmdb_data: any;

    constructor(server) {
        {
            if (server._id)
                this.id = server._id;
            else
                this.id = server.id || UditUtils.generateGUID();

            this.last_update = server.last_update || '';
            this._server_type = server._server_type || '';
            this._server = server._server || '';
            this.loc_data = Object.assign({}, this.loc_data) || {};
            this.sys_config = Object.assign({}, this.sys_config) || {};
            this.cmdb_data = Object.assign({}, this.cmdb_data) || {};
        }
    }
}
