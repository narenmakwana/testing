import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { ServersComponent } from './servers/servers.component';
import { ServersService } from './servers.service';

const routes: Routes = [
  {
    path: 'patch/servers',
    component: ServersComponent,
    resolve: {
      servers: ServersService
    }
  }
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    ServersService
  ],
  declarations: [ServersComponent]
})
export class ServersModule { }

