import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { UditUtils } from '../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';
import { Constants } from '../../../../shared/config/constants';
import { Server } from './server.model';

@Injectable()
export class ServersService implements Resolve<any>
{
  onServersChanged: BehaviorSubject<any> = new BehaviorSubject([]);
  onSelectedServersChanged: BehaviorSubject<any> = new BehaviorSubject([]);
  onSearchTextChanged: Subject<any> = new Subject();
  onFilterChanged: Subject<any> = new Subject();

  servers: any[];
  selectedServers: string[] = [];

  searchText: string;
  filterBy: string;

  constructor(private http: HttpClient) {
  }

  /**
   * The Servers App Main Resolver
   * @param {ActivatedRouteSnapshot} route
   * @param {RouterStateSnapshot} state
   * @returns {Observable<any> | Promise<any> | any}
   */
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any {
    return new Promise((resolve, reject) => {

      Promise.all([
        this.getServers()
      ]).then(
        ([files]) => {

          this.onSearchTextChanged.subscribe(searchText => {
            this.searchText = searchText;
            this.getServers();
          });

          this.onFilterChanged.subscribe(filter => {
            this.filterBy = filter;
            this.getServers();
          });

          resolve();

        },
        reject
      );
    });
  }

  getServers(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(Constants.getServersUrl())
        .subscribe((response: any) => {

          this.servers = response.items.map(server => {
            return new Server(server);
          });

          if (this.searchText && this.searchText !== '') {
            this.servers = UditUtils.filterArrayByString(this.servers, this.searchText);
          }

          this.onServersChanged.next(this.servers);
          resolve(this.servers);
        }, reject);
    }
    );
  }

  /**
   * Toggle selected  by id
   * @param id
   */
  toggleSelectedServer(id) {
    // First, check if we already have that todo as selected...
    if (this.selectedServers.length > 0) {
      const index = this.selectedServers.indexOf(id);

      if (index !== -1) {
        this.selectedServers.splice(index, 1);

        // Trigger the next event
        this.onSelectedServersChanged.next(this.selectedServers);

        // Return
        return;
      }
    }

    // If we don't have it, push as selected
    this.selectedServers.push(id);

    // Trigger the next event
    this.onSelectedServersChanged.next(this.selectedServers);
  }

  /**
   * Toggle select all
   */
  toggleSelectAll() {
    if (this.selectedServers.length > 0) {
      this.deselectServers();
    }
    else {
      this.selectServers();
    }
  }

  selectServers(filterParameter?, filterValue?) {
    this.selectedServers = [];

    // If there is no filter, select all todos
    if (filterParameter === undefined || filterValue === undefined) {
      this.selectedServers = [];
      this.servers.map(server => {
        this.selectedServers.push(server.id);
      });
    }

    // Trigger the next event
    this.onSelectedServersChanged.next(this.selectedServers);
  }

  updateServer(server) {
    let id = server.id;
    // remove the id to allow the update.
    delete server.id;
    return new Promise((resolve, reject) => {

      this.http.put(Constants.getServersUrl() + id, { ...server })
        .subscribe(response => {
          this.getServers();
          resolve(response);
        });
    });
  }

  createServer(server) {
    // We want to remove the ID's if any because we want Mongo to assign one.
    if (server.id)
      delete server.id;
    return new Promise((resolve, reject) => {

      this.http.post(Constants.getServersUrl(), { ...server })
        .subscribe(response => {
          this.getServers();
          resolve(response);
        });
    });
  }

  removeServer(server) {
    let id = server.id;
    // remove the id to allow the update.
    delete server.id;
    return new Promise((resolve, reject) => {

      this.http.delete(Constants.getServersUrl() + id, { ...server })
        .subscribe(response => {
          this.getServers();
          resolve(response);
        });
    });
  }

  deselectServers() {
    this.selectedServers = [];

    // Trigger the next event
    this.onSelectedServersChanged.next(this.selectedServers);
  }

  deleteServer(server) {
    const serverIndex = this.servers.indexOf(server);
    this.servers.splice(serverIndex, 1);
    this.removeServer(server);
    this.onServersChanged.next(this.servers);
  }

  deleteSelectedServers() {
    for (const serverId of this.selectedServers) {
      const server = this.servers.find(_server => {
        return _server.id === serverId;
      });
      const serverIndex = this.servers.indexOf(server);
      this.servers.splice(serverIndex, 1);
      this.removeServer(server);
    }
    this.onServersChanged.next(this.servers);
    this.deselectServers();
  }

}
