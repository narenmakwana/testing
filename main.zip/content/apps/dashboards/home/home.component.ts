
import { Component, OnInit } from '@angular/core';
import { UditTranslationLoaderService } from '../../../../../core/services/translation-loader.service';
import { locale as english } from './i18n/en';
import { locale as turkish } from './i18n/tr';
import { FeedService } from './feed/feed.service';
import { FeedComponent} from './feed/feed.component'
import { UditSplashScreenService } from '../../../../../core/services/splash-screen.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  private feedUrl: string = 'https%3A%2F%2Fwww-947.ibm.com%2Fsystems%2Fsupport%2Fmyfeed%2Fxmlfeeder.wss%3Ffeeder.requid%3Dfeeder.create_public_feed%26feeder.feedtype%3DRSS%26feeder.maxfeed%3D25%26OC%3DSSEQTP%26feeder.subdefkey%3Dswgws%26feeder.channel.title%3DWebSphere%2520Application%2520Server%26feeder.channel.descr%3DThe%2520latest%2520updates%2520about%2520WebSphere%2520Application%2520Server';
  feeds: any = [];
  loading : boolean = false;
  gotResponse : boolean = false;
  gotError : boolean = false;

  constructor(private translationLoader: UditTranslationLoaderService, 
    private uditSpashScreenService: UditSplashScreenService,
    private feedService: FeedService)
  {
      this.translationLoader.loadTranslations(english, turkish);
  }

  ngOnInit() {
    this.loading = true;
    this.refreshFeed();
  }  
 
  private refreshFeed() {
    this.feedService.getFeedContent(this.feedUrl)
        .subscribe(
            feed => {this.feeds = feed.items; this.loading=false;this.gotResponse=true; this.uditSpashScreenService.hide();},
            error => {console.log(error); this.gotError=true; this.loading=false; this.uditSpashScreenService.hide();});

  }
  
}