export const locale = {
    lang: 'tr',
    data: {
        'DASHBOARD': {
            'HELLO': 'Merhaba Dünya!'
        }
    }
};
