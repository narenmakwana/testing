export const locale = {
    lang: 'en',
    data: {
        'DASHBOARD': {
            'HELLO': 'Hello, World!'
        }
    }
};
