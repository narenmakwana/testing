import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../core/modules/shared.module';
import { HomeComponent } from './home/home.component';
import { FeedComponent } from './home/feed/feed.component';
import { FeedService } from './home/feed/feed.service';
import {HttpModule, RequestOptions, XHRBackend} from '@angular/http';

const routes: Routes = [
  {
      path     : 'dashboards/home',
      component: HomeComponent
  },

];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes),
    HttpModule
  ],
  declarations: [ HomeComponent, FeedComponent ],
  providers: [FeedService]
})
export class DashboardsModule { }
