import { Component, OnInit, OnDestroy, Input, Output } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, ActivatedRoute, Params } from '@angular/router';
import { Subscription, Observable, BehaviorSubject } from "rxjs/Rx";
import { Location } from '@angular/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { UditUtils } from '../../../../../core/uditUtils';
import { MatDialogRef, MatDialog } from '@angular/material';
import { StatusDialog } from '../../../../shared/components/status-dialog.component';
import { DialogService } from '../../../../shared/services/dialog.service';
import { AuthenticationService } from '../../../pages/authentication/authentication.service';
import { LibertyCellParseService } from '../../../../shared/services/liberty-cell-parse.service';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { LibertyService } from '../../design/liberty/liberty.service';
import { SocketEvent } from './../../../../shared/models/socket-event';
import { SocketService } from './../../../../shared/services/socket-service';
import { Constants } from './../../../../shared/config/constants';


@Component({
  selector: 'c-liberty-topology',
  templateUrl: './liberty-topology.component.html',
  styleUrls: ['./liberty-topology.component.scss']
})
export class LibertyTopologyComponent implements OnInit {
  private subscription: Subscription;
  private _dialogRef: MatDialogRef<StatusDialog>;
  private searchsub: Subscription;
  private ID: string;
  _params: Observable<any>;
  showJvmMenu: boolean = false;
  showIhsMenu: boolean = false;
  _libertyCell: any;
  ccName: string = "";
  cellname: string = "";
  ccHost: string;
  ccPort: string;
  hasCC: boolean = false;
  isCC: boolean = false;
  isReplica: boolean = false;
  loading: boolean = true;
  isAdmin: boolean = false;

  constructor(protected _cellParseService: LibertyCellParseService, private _location: Location,
    protected _router: Router, protected _route: ActivatedRoute, private _dialog: MatDialog, private _dialogService: DialogService,
    private _invService: InventoryService, private authService: AuthenticationService, private _socketService: SocketService) {

    this._route.params.subscribe(this.onParamChange.bind(this));
  }

  // Get Cell Name from the route params and get cell info from inventory
  onParamChange(params: any) {
    if (params.id) {
      this._invService.getLibertyInvCellByName(params.id).catch(this.handleError.bind(this))
        .then(this.handleSuccess.bind(this));
    }
  }

  // Check if the user has the right role (Admin)
  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
  }

  // Close the Socket.IO Socket when leaving the topology view
  ngOnDestroy() {
    this._socketService.closeSocket();
  }

  // Inventory fetch was successful now we want to capture the environment type and also find the Collective Controller information for this cell
  // then we will initiazlie the socket.io connection
  handleSuccess(_libertyCell: any) {
    var self = this;
    this._libertyCell = _libertyCell.items[0];
    var env = this._libertyCell.cellName.split('-')[2].slice(0, 2);
    var tci = this._libertyCell.cellName.split('-')[0];

    if (this._libertyCell.nodes[0].wlp.shared[0] && this._libertyCell.nodes[0].wlp.shared[0].content.server.collectiveMember) {
      if (this._libertyCell.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerHost.length > 7) {
        this.ccHost = this._libertyCell.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerHost.split('.')[0];
      }
      else {
        this.ccHost = this._libertyCell.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerHost;
      }
      this.ccPort = this._libertyCell.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerPort;
      this._cellParseService.getControllerInfo(this.ccHost, this.ccPort, function (ccInfo) {
        if (ccInfo.ccName) {
          self.ccName = ccInfo.ccName;
          self.hasCC = true;
          self.initIoConnection();
        }
      });
    }
    else if (this._libertyCell.nodes[0].wlp.servers && !this.hasCC) {
      this._libertyCell.nodes[0].wlp.servers.forEach(server => {
        if (server.name.includes('-cntrlr-')) {
          this.isCC = true;
          this.ccName = server.name;
          this.ccHost = this._libertyCell.nodes[0].hostName;
          this.ccPort = server.server.httpEndpoint.httpsPort;
        }
      });
      if (this._libertyCell.nodes[0].wlp.servers.length > 1) {
        this.isReplica = true;
      }

      self.initIoConnection();

    }
  }

  onShowJvmMenu(jvm: any): boolean {
    // toggle showMenu
    jvm.showJvmMenu = !jvm.showJvmMenu;
    return jvm.showJvmMenu;
  }

  onShowIhsMenu(ihs: any): boolean {
    // toggle showMenu
    ihs.showIhsMenu = !ihs.showIhsMenu;
    return ihs.showIhsMenu;
  }

  initIoConnection(): void {
    var self = this;
    // Initialize socket.io connection
    this._socketService.initSocket(this.authService.getToken());

    // Setup Event Listener for the 'connection' event
    this._socketService.onEvent(SocketEvent.CONNECT)
      .subscribe(() => {
        // Connected
        console.log('connected');
        // For each JVM and IHS send a message to the socket API to join a room
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((server) => {
              server.roomName = '/' + self._libertyCell.cellName + '/' + server.name + '/';
              server.detailData$ = new BehaviorSubject({});
              //server.showJvmMenu = true;
              this._socketService.send(SocketEvent.JOIN, server.roomName);
              if (!server.stopping && !server.starting && !server.checkingStatus) {
                server.checkingStatus = true;
                self.refreshJvmStatus(node, server);
              }
            });
          }
          if (node.ihs) {
            node.ihs.servers.forEach((server) => {
              server.roomName = '/' + self._libertyCell.cellName + '/' + server.ihsName + '/';
              server.detailData$ = new BehaviorSubject({});
              //server.showIhsMenu = true;
              this._socketService.send(SocketEvent.JOIN, server.roomName);
              if (!server.stopping && !server.starting && !server.checkingStatus) {
                server.checkingStatus = true;
                self.refreshIhsStatus(node, server);
              }
            });
          }
        });
        self.loading = false;
      });

    // Event Listener for the 'connect_error' event
    // If the udi-ops service is not available, display error message
    this._socketService.onEvent(SocketEvent.CONNECT_ERR)
      .subscribe(() => {
        this.loading = false;
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihs) {
            node.ihs.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });

    // Event Listener for the 'error' event which means Unauthorized..
    this._socketService.onEvent(SocketEvent.ERROR)
      .subscribe((err) => {
        this.loading = false;
        console.log(err);
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihs) {
            node.ihs.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });

    // Event Listener for the 'wlpStatus' event to update the JVM status
    this._socketService.onEvent(SocketEvent.WLP_STATUS)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                jvm.detailData$.next(data);
                if (data.stdout.includes('Server ' + jvm.name + ' is running with process ID')) {
                  jvm.checkingStatus = false;
                  jvm.running = true;
                }
                if (data.stdout.includes('Server ' + jvm.name + ' is not running')) {
                  jvm.checkingStatus = false;
                  jvm.running = false;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.connErr = true;
                  jvm.checkingStatus = false;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'ihsStatus' event to update the IHS status
    this._socketService.onEvent(SocketEvent.IHS_STATUS)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.ihs) {
            node.ihs.servers.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.checkingStatus = false;
                  ihs.running = true;
                }
                if (data.returnCode === 1) {
                  ihs.checkingStatus = false;
                  ihs.running = false;
                }
                if (data.returnCode > 1) {
                  ihs.checkingStatus = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'wlpStart' event to get the JVM Start Data
    this._socketService.onEvent(SocketEvent.WLP_START)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.starting = true;
                jvm.detailData$.next(data);
                if (data.returnCode === 0 || data.returnCode === 1) {
                  jvm.starting = false;
                  jvm.running = true;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.starting = false;
                  jvm.checkingStatus = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'wlpStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.WLP_STOP)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.stopping = true;
                jvm.detailData$.next(data);
                if (data.returnCode === 0 || data.returnCode === 1) {
                  jvm.stopping = false;
                  jvm.running = false;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.stopping = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'ihsStart' event to get the IHS Start Data
    this._socketService.onEvent(SocketEvent.IHS_START)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.ihs) {
            node.ihs.servers.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                if (ihs.checkingStatus) {
                  ihs.checkingStatus = false;
                }
                ihs.starting = true;
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.starting = false;
                  ihs.running = true;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  ihs.starting = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'ihsStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.IHS_STOP)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.ihs) {
            node.ihs.servers.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                if (ihs.checkingStatus) {
                  ihs.checkingStatus = false;
                }
                ihs.stopping = true;
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.stopping = false;
                  ihs.running = false;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  ihs.stopping = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'terminate' event to get the forcefully shut down the JVM
    this._socketService.onEvent(SocketEvent.TERMINATE)
      .subscribe((data) => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.stopping = true;
                jvm.detailData$.next(data);
                if (data.returnCode === 0 || data.returnCode === 1) {
                  jvm.stopping = false;
                  jvm.running = false;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.stopping = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'disconnect' event
    // If the service is stopped then display error status
    this._socketService.onEvent(SocketEvent.DISCONNECT)
      .subscribe(() => {
        self._libertyCell.nodes.forEach((node) => {
          if (node.wlp) {
            node.wlp.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihs) {
            node.ihs.servers.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });

    /*
// Event Listener for the 'tail' event to get the live build status
this._socketService.onEvent(SocketEvent.TAIL)
.subscribe((data) => {
  self._libertyCell.nodes.forEach((node) => {
    if (node.wlp) {
      node.wlp.servers.forEach((jvm) => {
        if (data.room === jvm.roomName) {
          jvm.detailData$.next(data);
        }
      });
    }
    if (node.ihs) {
      node.ihs.servers.forEach((ihs) => {
        if (data.room === ihs.roomName) {
          ihs.detailData$.next(data);
        }
      });
    }
  });
});

*/
  }

  // Function to send an emit message to the udi-ops API to trigger a IHS Start
  startIhs(node: any, ihs: any) {
    this._dialogService.confirm('', 'Start server ' + ihs.ihsName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting ihs..." + ihs.ihsName);
          var runas = node.ihs.imID;
          if (node.ihs.imID === 'root') {
            this._libertyCell.nodes.forEach(node => {
              if (node.wlp) {
                runas = node.wlp.runAsID;
              }
            });
          }
          var server = { ihsName: ihs.ihsName, runasId: runas, hostName: node.hostName, portNumber: ihs.portBlock + '43', room: ihs.roomName };
          this._socketService.send(SocketEvent.IHS_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a IHS Stop
  stopIhs(node: any, ihs: any) {
    this._dialogService.confirm('', 'Stop server ' + ihs.ihsName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping ihs..." + ihs.ihsName);
          var runas = node.ihs.imID;
          if (node.ihs.imID === 'root') {
            this._libertyCell.nodes.forEach(node => {
              if (node.wlp) {
                runas = node.wlp.runAsID;
              }
            });
          }
          var server = { ihsName: ihs.ihsName, runasId: runas, hostName: node.hostName, portNumber: ihs.portBlock + '43', room: ihs.roomName };
          this._socketService.send(SocketEvent.IHS_STOP, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a JVM Start
  startJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Start server ' + jvm.name + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting jvm..." + jvm.name);
          var server = { cellName: this._libertyCell.cellName, jvmName: jvm.name, runasId: node.wlp.runAsID, hostName: node.hostName, room: jvm.roomName };
          this._socketService.send(SocketEvent.WLP_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a JVM Stop
  stopJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Stop server ' + jvm.name + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping jvm..." + jvm.name);
          var server = { cellName: this._libertyCell.cellName, jvmName: jvm.name, runasId: node.wlp.runAsID, hostName: node.hostName, room: jvm.roomName };
          this._socketService.send(SocketEvent.WLP_STOP, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a JVM Forceful Stop
  killJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Terminate server ' + jvm.name + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping jvm..." + jvm.name);
          jvm.stopping = true;
          var server = { cellName: this._libertyCell.cellName, jvmName: jvm.name, runasId: node.wlp.runAsID, hostName: node.hostName, room: jvm.roomName };
          this._socketService.send(SocketEvent.TERMINATE, server);
        }
      });
  }


  // Function to send an emit message to the udi-ops API to Refresh the JVM status
  refreshJvmStatus(node: any, jvm: any) {
    //console.log("Refresh JVM Status..." + jvm.name);
    var server = { cellName: this._libertyCell.cellName, jvmName: jvm.name, runasId: node.wlp.runAsID, hostName: node.hostName, room: jvm.roomName };
    jvm.checkingStatus = true;
    jvm.connErr = false;
    this._socketService.send(SocketEvent.WLP_STATUS, server);
  }

  // Function to send an emit message to the udi-ops API to Refresh the IHS status
  refreshIhsStatus(node: any, ihs: any) {
    //console.log("Refresh IHS Status..." + ihs.ihsName);
    var runas = node.ihs.imID;
    if (node.ihs.imID === 'root') {
      this._libertyCell.nodes.forEach(node => {
        if (node.wlp) {
          runas = node.wlp.runAsID;
        }
      });
    }
    var server = { ihsName: ihs.ihsName, runasId: runas, hostName: node.hostName, portNumber: ihs.portBlock + '43', room: ihs.roomName };
    ihs.checkingStatus = true;
    ihs.connErr = false;
    this._socketService.send(SocketEvent.IHS_STATUS, server);
  }

  /*
  // Function to send an emit message to the udi-ops API to tail a log
  tailIhsLog(node: any, ihs: any) {
    var runas = node.ihs.imID;
    if (node.ihs.imID === 'root') {
      this._libertyCell.nodes.forEach(node => {
        if (node.wlp) {
          runas = node.wlp.runAsID;
        }
      });
    }
    var log = '/apps/ki01/' + ihs.ihsName + '/HTTPServer/logs/access_log';
    var tail = { room: ihs.roomName, hostName: node.hostName, runasId: runas, log: log };
    ihs.tailing = true;
    this._socketService.send(SocketEvent.TAIL, tail);
    this.showDetails(ihs.ihsName, ihs);
  }

  // Function to send an emit message to the udi-ops API to tail a log
  tailJvmLog(node: any, jvm: any) {
    var log = '/apps/ki01/' + this._libertyCell.cellName + '/config/servers/' + jvm.name + '/logs/messages.log';
    var tail = { hostName: node.hostName, room: jvm.roomName, runasId: node.wlp.runAsID,  log: log };
    jvm.tailing = true;
    this._socketService.send(SocketEvent.TAIL, tail);
    this.showDetails(jvm.name, jvm);
  }

  */

  showDetails(serverName, server) {
    this.open(serverName, server);
  }

  // Open a Status Dialog and subscribe to each servers detailData$ BehaviorSubject to show the live status
  open(serverName, server) {
    this._dialogRef = this._dialog.open(StatusDialog, {
      height: '500px',
      width: '750px',
      disableClose: true
    });
    this._dialogRef.componentInstance.title = serverName;
    this._dialogRef.componentInstance.data = '';
    this.subscription = server.detailData$.subscribe(data => {
      this._dialogRef.componentInstance.loading = true;
      if (data.stdout) {
        this._dialogRef.componentInstance.data += data.stdout;
      }
      if (data.returnCode >= 0) {
        this._dialogRef.componentInstance.loading = false;
      }
    });
    this._dialogRef.afterClosed().subscribe(result => {
      this.subscription.unsubscribe();
      this._dialogRef = null;
    });
  }

  handleError(error) {
    console.log("Got Error in Getting Liberty Cell Data")
  }

  finish(): void {
    // Go back to previous page.
    this._location.back();
  }

}
