import { JvmTemplate } from './../../../../shared/models/jvm-template';
import { Component, OnInit, Input, Output } from '@angular/core';
import { Constants } from './../../../../shared/config/constants';
import { CellParseService } from '../../../../shared/services/cell-parse.service';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, ActivatedRoute, Params } from '@angular/router';
import { Subscription, Observable, BehaviorSubject } from "rxjs/Rx";
import { WasNdService } from '../../design/was-nd/was-nd.service';
import { WasDataTransformService } from '../../../../shared/services/was-data-transform.service';
import { Location } from '@angular/common';
import { MatDialogRef, MatDialog } from '@angular/material';
import { DialogService } from '../../../../shared/services/dialog.service';
import { StatusDialog } from '../../../../shared/components/status-dialog.component';
import { AuthenticationService } from '../../../pages/authentication/authentication.service';
import { SocketEvent } from './../../../../shared/models/socket-event';
import { SocketService } from './../../../../shared/services/socket-service';

@Component({
  selector: 'c-was-topology',
  templateUrl: './was-topology.component.html',
  styleUrls: ['./was-topology.component.scss']
})
export class WasTopologyComponent implements OnInit {

  _params: Observable<any>;
  private subscription: Subscription;
  private _dialogRef: MatDialogRef<StatusDialog>;
  private ID: string;
  private cellname: string = "";
  showJvmMenu: boolean = false;
  showIhsMenu: boolean = false;
  _wasCell: any;
  loading: boolean = true;
  isAdmin: boolean = false;
  isBase: boolean = false;

  constructor(protected _cellParseService: CellParseService, private _location: Location,
    private wasDataTransformService: WasDataTransformService,
    protected _router: Router, protected _route: ActivatedRoute, private authService: AuthenticationService,
    private _dialog: MatDialog, private _dialogService: DialogService,
    private _invService: InventoryService, private _wasNdService: WasNdService, private _socketService: SocketService) {

    this._route.params.subscribe(this.onParamChange.bind(this));
  }

  // Check if the user has the right role (Admin)
  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
  }

  // Close the Socket.IO Socket when leaving the topology view
  ngOnDestroy() {
    this._socketService.closeSocket();
  }

  onParamChange(params: any) {
    if (params.id) {
      // Retrieve the document here.
      this._invService.getInventoryById(params.id).catch(this.handleError.bind(this))
        .then(this.handleSuccess.bind(this));
    }
  }

  handleSuccess(_wasNdCell: any) {
    this.ID = _wasNdCell._id;
    this._wasCell = this._cellParseService.convertFromInventoryToDesignFormat(_wasNdCell);
    //console.log(this._wasCell);
    var env = this._wasCell.cellname.split('-')[2].slice(0, 2);
    var tci = this._wasCell.cellname.split('-')[0];

    this._wasCell.nodeTemplates.forEach((node) => {
      if (node.jvmTemplates) {
        node.jvmTemplates.forEach((server) => {
          if (server.jvmName === 'server1') {
            this.isBase = true;
          }
          if (server.jvmName.includes('Portal')) {
            node.nodeName = node.nodeName.replace('node', 'wps');
          }
        });
      }
    });
    this._wasNdService.setWasCell(this._wasCell);
    this.initIoConnection();
  }

  handleError(error) {
    console.log("Got Error in Getting WasCell Data")
  }


  onShowJvmMenu(jvm: any): boolean {
    // toggle showMenu
    jvm.showJvmMenu = !jvm.showJvmMenu;
    return jvm.showJvmMenu;
  }

  onShowIhsMenu(ihs: any): boolean {
    // toggle showMenu
    ihs.showIhsMenu = !ihs.showIhsMenu;
    return ihs.showIhsMenu;
  }

  initIoConnection(): void {
    var self = this;
    // Initialize socket.io connection
    this._socketService.initSocket(this.authService.getToken());

    // Setup Event Listener for the 'connection' event
    this._socketService.onEvent(SocketEvent.CONNECT)
      .subscribe(() => {
        // Connected
        console.log('connected');
        // For each JVM and IHS send a message to the socket API to join a room
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            node.dmgr = {};
            node.dmgr.roomName = '/' + self._wasCell.cellname + '/' + self._wasCell.dmgrName;
            node.dmgr.jvmName = 'dmgr';
            node.dmgr.nodeName = self._wasCell.dmgrName;
            this._socketService.send(SocketEvent.JOIN, node.dmgr.roomName);
            node.dmgr.detailData$ = new BehaviorSubject({});
            if (!node.dmgr.stopping && !node.dmgr.starting && !node.dmgr.checkingStatus) {
              node.dmgr.checkingStatus = true;
              self.refreshJvmStatus(node, node.dmgr);
            }
          }
          if ((typeof node.nodeName != 'undefined') && node.jvmTemplates.length > 0) {
            if ((node.nodeName.includes('node') && !this.isBase) || node.nodeName.includes('wps')) {
              node.roomName = '/' + self._wasCell.cellname + '/' + node.nodeName;
              node.jvmName = 'nodeagent';
              this._socketService.send(SocketEvent.JOIN, node.roomName);
              node.detailData$ = new BehaviorSubject({});
              if (!node.stopping && !node.starting && !node.checkingStatus) {
                node.checkingStatus = true;
                self.refreshJvmStatus(node, node)
              }
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((server) => {
              server.roomName = '/' + self._wasCell.cellname + '/' + server.jvmName + '/';
              server.detailData$ = new BehaviorSubject({});
              this._socketService.send(SocketEvent.JOIN, server.roomName);
              if (!server.stopping && !server.starting && !server.checkingStatus) {
                server.checkingStatus = true;
                self.refreshJvmStatus(node, server);
              }
            });
          }
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((server) => {
              server.roomName = '/' + self._wasCell.cellname + '/' + server.ihsName + '/';
              server.detailData$ = new BehaviorSubject({});
              this._socketService.send(SocketEvent.JOIN, server.roomName);
              if (!server.stopping && !server.starting && !server.checkingStatus) {
                server.checkingStatus = true;
                self.refreshIhsStatus(node, server);
              }
            });
          }
        });
        self.loading = false;
      });

    // Event Listener for the 'connect_error' event
    // If the udi-ops service is not available, display error message
    this._socketService.onEvent(SocketEvent.CONNECT_ERR)
      .subscribe(() => {
        this.loading = false;
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            node.dmgr = {};
            node.dmgr.running = false;
            node.dmgr.checkingStatus = false;
            node.dmgr.connErr = true;
          }
          if ((typeof node.nodeName != 'undefined') && node.jvmTemplates.length > 0) {
            if ((node.nodeName.includes('node') && !this.isBase) || node.nodeName.includes('wps')) {
              node.running = false;
              node.checkingStatus = false;
              node.connErr = true;
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });

    // Event Listener for the 'error' event (Unauthorized)
    this._socketService.onEvent(SocketEvent.ERROR)
      .subscribe((err) => {
        this.loading = false;
        console.log(err);
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            node.dmgr = {};
            node.dmgr.running = false;
            node.dmgr.checkingStatus = false;
            node.dmgr.connErr = true;
          }
          if ((typeof node.nodeName != 'undefined') && node.jvmTemplates.length > 0) {
            if ((node.nodeName.includes('node') && !this.isBase) || node.nodeName.includes('wps')) {
              node.running = false;
              node.checkingStatus = false;
              node.connErr = true;
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });

    // Event Listener for the 'wasStatus' event to update the JVM status
    this._socketService.onEvent(SocketEvent.WAS_STATUS)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            if (data.room === node.dmgr.roomName) {
              node.dmgr.detailData$.next(data);
              if (data.stdout.includes('ADMU0508I: The Deployment Manager "' + node.dmgr.jvmName + '" is STARTED')) {
                node.dmgr.checkingStatus = false;
                node.dmgr.running = true;
              }
              if (data.stdout.includes('ADMU0509I: The Deployment Manager ')) {
                node.dmgr.checkingStatus = false;
                node.dmgr.running = false;
              }
              if (data.returnCode > 0) {
                console.log("Return Code : " + data.returnCode);
                node.dmgr.checkingStatus = false;
                node.dmgr.connErr = true;
              }
            }
          }
          if ((typeof node.nodeName != 'undefined') && node.jvmTemplates.length > 0) {
            if ((node.nodeName.includes('node') && !this.isBase) || node.nodeName.includes('wps')) {
              if (data.room === node.roomName) {
                node.detailData$.next(data);
                if (data.stdout.includes('ADMU0508I: The Node Agent "' + node.jvmName + '" is STARTED')) {
                  node.checkingStatus = false;
                  node.running = true;
                }
                if (data.stdout.includes('ADMU0509I: The Node Agent ')) {
                  node.checkingStatus = false;
                  node.running = false;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  node.checkingStatus = false;
                  node.connErr = true;
                }
              }
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                jvm.detailData$.next(data);
                if (data.stdout.includes('ADMU0508I: The Application Server "' + jvm.jvmName + '" is STARTED')) {
                  jvm.checkingStatus = false;
                  jvm.running = true;
                }
                if (data.stdout.includes('ADMU0508I: The Application Server "' + jvm.jvmName + '" is STARTING')) {
                  jvm.checkingStatus = false;
                  jvm.running = false;
                  jvm.starting = true;
                }
                if (data.stdout.includes('ADMU0508I: The Application Server "' + jvm.jvmName + '" is STOPPING')) {
                  jvm.checkingStatus = false;
                  jvm.running = false;
                  jvm.stopping = true;
                }
                if (data.stdout.includes('ADMU0509I: The Application Server')) {
                  jvm.checkingStatus = false;
                  jvm.running = false;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.checkingStatus = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'ihsStatus' event to update the IHS status
    this._socketService.onEvent(SocketEvent.IHS_STATUS)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.checkingStatus = false;
                  ihs.running = true;
                }
                if (data.returnCode === 1) {
                  ihs.checkingStatus = false;
                  ihs.running = false;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  ihs.checkingStatus = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'wasStart' event to get the JVM Start Data
    this._socketService.onEvent(SocketEvent.WAS_START)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.starting = true;
                jvm.detailData$.next(data);
                if (data.returnCode === 0 || data.returnCode === 255) {
                  jvm.starting = false;
                  jvm.running = true;
                }
                if (data.returnCode > 0 && data.returnCode !== 255) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.checkingStatus = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });


    // Event Listener for the 'wasStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.WAS_STOP)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.stopping = true;
                jvm.detailData$.next(data);
                if (data.returnCode == 0 || data.returnCode === 246) {
                  jvm.stopping = false;
                  jvm.running = false;
                }
                if (data.returnCode > 0 && data.returnCode !== 246) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.checkingStatus = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'dmgrStart' event to get the DMGR Start Data
    this._socketService.onEvent(SocketEvent.DMGR_START)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            if (data.room === node.dmgr.roomName) {
              if (node.dmgr.checkingStatus) {
                node.dmgr.checkingStatus = false;
              }
              node.dmgr.starting = true;
              node.dmgr.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 255) {
                node.dmgr.starting = false;
                node.dmgr.running = true;
              }
              if (data.returnCode > 0 && data.returnCode !== 255) {
                console.log("Return Code : " + data.returnCode);
                node.dmgr.checkingStatus = false;
                node.dmgr.connErr = true;
              }
            }
          }
        });
      });

    // Event Listener for the 'dmgrStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.DMGR_STOP)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            if (data.room === node.dmgr.roomName) {
              if (node.dmgr.checkingStatus) {
                node.dmgr.checkingStatus = false;
              }
              node.dmgr.stopping = true;
              node.dmgr.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 246) {
                node.dmgr.stopping = false;
                node.dmgr.running = false;
              }
              if (data.returnCode > 0 && data.returnCode !== 246) {
                console.log("Return Code : " + data.returnCode);
                node.dmgr.checkingStatus = false;
                node.dmgr.connErr = true;
              }
            }
          }
        });
      });

    // Event Listener for the 'nodeStart' event to get the Nodeagent Start Data
    this._socketService.onEvent(SocketEvent.NODE_AGENT_START)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.nodeName.includes('node') || node.nodeName.includes('wps')) {
            if (data.room === node.roomName) {
              if (node.checkingStatus) {
                node.checkingStatus = false;
              }
              node.starting = true;
              node.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 255) {
                node.starting = false;
                node.running = true;
              }
              if (data.returnCode > 0 && data.returnCode !== 255) {
                console.log("Return Code : " + data.returnCode);
                node.checkingStatus = false;
                node.connErr = true;
              }
            }
          }
        });
      });

    // Event Listener for the 'nodeStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.NODE_AGENT_STOP)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.nodeName.includes('node') || node.nodeName.includes('wps')) {
            if (data.room === node.roomName) {
              if (node.checkingStatus) {
                node.checkingStatus = false;
              }
              node.stopping = true;
              node.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 246) {
                node.stopping = false;
                node.running = false;
              }
              if (data.returnCode > 0 && data.returnCode !== 246) {
                console.log("Return Code : " + data.returnCode);
                node.checkingStatus = false;
                node.connErr = true;
              }
            }
          }
        });
      });

    // Event Listener for the 'ihsStart' event to get the IHS Start Data
    this._socketService.onEvent(SocketEvent.IHS_START)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                if (ihs.checkingStatus) {
                  ihs.checkingStatus = false;
                }
                ihs.starting = true;
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.starting = false;
                  ihs.running = true;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  ihs.starting = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'ihsStop' event to get the JVM Stop Data
    this._socketService.onEvent(SocketEvent.IHS_STOP)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((ihs) => {
              if (data.room === ihs.roomName) {
                if (ihs.checkingStatus) {
                  ihs.checkingStatus = false;
                }
                ihs.stopping = true;
                ihs.detailData$.next(data);
                if (data.returnCode === 0) {
                  ihs.stopping = false;
                  ihs.running = false;
                }
                if (data.returnCode > 0) {
                  console.log("Return Code : " + data.returnCode);
                  ihs.stopping = false;
                  ihs.connErr = true;
                }
              }
            });
          }
        });
      });

    // Event Listener for the 'terminate' event to get the forcefully shut down the JVM
    this._socketService.onEvent(SocketEvent.TERMINATE)
      .subscribe((data) => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            if (data.room === node.dmgr.roomName) {
              if (node.dmgr.checkingStatus) {
                node.dmgr.checkingStatus = false;
              }
              node.dmgr.stopping = true;
              node.dmgr.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 1) {
                node.dmgr.stopping = false;
                node.dmgr.running = false;
              }
              if (data.returnCode > 1) {
                console.log("Return Code : " + data.returnCode);
                node.dmgr.checkingStatus = false;
                node.dmgr.connErr = true;
              }
            }
          }
          if (node.nodeName.includes('node') || node.nodeName.includes('wps')) {
            if (data.room === node.roomName) {
              if (node.checkingStatus) {
                node.checkingStatus = false;
              }
              node.stopping = true;
              node.detailData$.next(data);
              if (data.returnCode === 0 || data.returnCode === 1) {
                node.stopping = false;
                node.running = false;
              }
              if (data.returnCode > 1) {
                console.log("Return Code : " + data.returnCode);
                node.checkingStatus = false;
                node.connErr = true;
              }
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((jvm) => {
              if (data.room === jvm.roomName) {
                if (jvm.checkingStatus) {
                  jvm.checkingStatus = false;
                }
                jvm.stopping = true;
                jvm.detailData$.next(data);
                if (data.returnCode == 0 || data.returnCode === 1) {
                  jvm.stopping = false;
                  jvm.running = false;
                }
                if (data.returnCode > 1) {
                  console.log("Return Code : " + data.returnCode);
                  jvm.checkingStatus = false;
                  jvm.connErr = true;
                }
              }
            });
          }
        });
      });


    // Event Listener for the 'disconnect' event
    // If the service is stopped then display error status
    this._socketService.onEvent(SocketEvent.DISCONNECT)
      .subscribe(() => {
        self._wasCell.nodeTemplates.forEach((node) => {
          if (node.hasDmgr) {
            node.dmgr = {};
            node.dmgr.running = false;
            node.dmgr.checkingStatus = false;
            node.dmgr.connErr = true;
          }
          if ((typeof node.nodeName != 'undefined') && node.jvmTemplates.length > 0) {
            if ((node.nodeName.includes('node') && !this.isBase) || node.nodeName.includes('wps')) {
              node.running = false;
              node.checkingStatus = false;
              node.connErr = true;
            }
          }
          if (node.jvmTemplates) {
            node.jvmTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
          if (node.ihsTemplates) {
            node.ihsTemplates.forEach((server) => {
              server.running = false;
              server.checkingStatus = false;
              server.connErr = true;
            });
          }
        });
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a JVM Start
  startJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Start server ' + jvm.jvmName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting jvm..." + jvm.jvmName);
          var server = {
            cellName: this._wasCell.cellname, jvmName: jvm.jvmName, runasId: this._wasCell.runasId,
            hostName: node.hostName, nodeName: node.nodeName, room: jvm.roomName
          };
          if (jvm.jvmName === 'server1') {
            server.nodeName = server.nodeName.replace('node', 'base');
          }
          if (jvm.jvmName.includes('Portal')) {
            server.nodeName = server.nodeName.replace('node', 'wps');
          }
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.WAS_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a JVM Stop
  stopJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Stop server ' + jvm.jvmName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping jvm..." + jvm.jvmName);
          var server = {
            cellName: this._wasCell.cellname, jvmName: jvm.jvmName, runasId: this._wasCell.runasId,
            hostName: node.hostName, nodeName: node.nodeName, room: jvm.roomName
          };
          if (jvm.jvmName === 'server1') {
            server.nodeName = server.nodeName.replace('node', 'base');
          }
          if (jvm.jvmName.includes('Portal')) {
            server.nodeName = server.nodeName.replace('node', 'wps');
          }
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.WAS_STOP, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to terminate JVM process (kill)
  killJvm(node: any, jvm: any) {
    this._dialogService.confirm('', 'Terminate server ' + jvm.jvmName + ' ?')
      .subscribe(res => {
        if (res) {
          jvm.stopping = true;
          var server = {
            cellName: this._wasCell.cellname, jvmName: jvm.jvmName, runasId: this._wasCell.runasId,
            hostName: node.hostName, nodeName: node.nodeName, room: jvm.roomName
          };
          if (jvm.jvmName === 'server1') {
            server.nodeName = server.nodeName.replace('node', 'base');
          }
          if (jvm.jvmName.includes('Portal')) {
            server.nodeName = server.nodeName.replace('node', 'wps');
          }
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.TERMINATE, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a DMGR Start
  startDmgr(node, dmgr) {
    this._dialogService.confirm('', 'Start DMGR ' + dmgr.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting DMGR..." + dmgr.nodeName);
          var server = {
            cellName: this._wasCell.cellname, dmgrName: dmgr.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: dmgr.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.DMGR_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a DMGR Stop
  stopDmgr(node, dmgr) {
    this._dialogService.confirm('', 'Stop DMGR ' + dmgr.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping DMGR..." + dmgr.nodeName);
          var server = {
            cellName: this._wasCell.cellname, dmgrName: dmgr.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: dmgr.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.DMGR_STOP, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to terminate JVM process (kill)
  killDmgr(node, dmgr) {
    this._dialogService.confirm('', 'Terminate DMGR ' + dmgr.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          dmgr.stopping = true;
          var server = {
            cellName: this._wasCell.cellname, jvmName: dmgr.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: dmgr.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.TERMINATE, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a Nodeagent Start
  startNode(node: any) {
    this._dialogService.confirm('', 'Start Node ' + node.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting Node..." + node.nodeName);
          var server = {
            cellName: this._wasCell.cellname, nodeName: node.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: node.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.NODE_AGENT_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a Nodeagent Stop
  stopNode(node: any) {
    this._dialogService.confirm('', 'Stop Node ' + node.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping Node..." + node.nodeName);
          var server = {
            cellName: this._wasCell.cellname, nodeName: node.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: node.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.NODE_AGENT_STOP, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to terminate JVM process (kill)
  killNode(node: any) {
    this._dialogService.confirm('', 'Terminate Node ' + node.nodeName + ' ?')
      .subscribe(res => {
        if (res) {
          node.stopping = true;
          var server = {
            cellName: this._wasCell.cellname, jvmName: node.nodeName, runasId: this._wasCell.runasId,
            hostName: node.hostName, room: node.roomName
          };
          server.cellName = server.cellName.replace('cell', 'was');
          this._socketService.send(SocketEvent.TERMINATE, server);
        }
      });
  }



  // Function to send an emit message to the udi-ops API to Refresh the JVM status
  refreshJvmStatus(node: any, jvm?: any) {
    //console.log("Refresh JVM Status..." + jvm.jvmName);
    jvm.checkingStatus = true;
    jvm.connErr = false;
    if (jvm.jvmName === 'dmgr') {
      var nodeName = jvm.nodeName;
    }
    else {
      var nodeName = node.nodeName;
    }
    var server = {
      cellName: this._wasCell.cellname, jvmName: jvm.jvmName, runasId: this._wasCell.runasId,
      hostName: node.hostName, nodeName: nodeName, room: jvm.roomName
    };
    server.cellName = server.cellName.replace('cell', 'was');
    if (jvm.jvmName === 'server1') {
      this.isBase = true;
      server.nodeName = server.nodeName.replace('node', 'base');
    }
    if (jvm.jvmName.includes('Portal')) {
      server.nodeName = server.nodeName.replace('node', 'wps');
    }
    this._socketService.send(SocketEvent.WAS_STATUS, server);
  }

  // Function to send an emit message to the udi-ops API to Refresh the IHS status
  refreshIhsStatus(node: any, ihs: any) {
    //console.log("Refresh IHS Status..." + ihs.ihsName);
    var server = { ihsName: ihs.ihsName, runasId: this._wasCell.runasId, hostName: node.hostName, portNumber: ihs.portBlock + '[4,8][0,3]', room: ihs.roomName };
    ihs.checkingStatus = true;
    ihs.connErr = false;
    this._socketService.send(SocketEvent.IHS_STATUS, server);
  }

  // Function to send an emit message to the udi-ops API to trigger a IHS Start
  startIhs(node: any, ihs: any) {
    this._dialogService.confirm('', 'Start server ' + ihs.ihsName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Starting ihs..." + ihs.ihsName);
          var server = { ihsName: ihs.ihsName, runasId: this._wasCell.runasId, hostName: node.hostName, portNumber: ihs.portBlock + '[4,8][0,3]', room: ihs.roomName };
          this._socketService.send(SocketEvent.IHS_START, server);
        }
      });
  }

  // Function to send an emit message to the udi-ops API to trigger a IHS Stop
  stopIhs(node: any, ihs: any) {
    this._dialogService.confirm('', 'Stop server ' + ihs.ihsName + ' ?')
      .subscribe(res => {
        if (res) {
          //console.log("Stopping ihs..." + ihs.ihsName);
          var server = { ihsName: ihs.ihsName, runasId: this._wasCell.runasId, hostName: node.hostName, portNumber: ihs.portBlock + '[4,8][0,3]', room: ihs.roomName };
          this._socketService.send(SocketEvent.IHS_STOP, server);
        }
      });
  }

  showDetails(serverName, server) {
    this.open(serverName, server);
  }


  // Open a Status Dialog and subscribe to each servers detailData$ BehaviorSubject to show the live status
  open(serverName, server) {
    this._dialogRef = this._dialog.open(StatusDialog, {
      height: '500px',
      width: '750px',
      disableClose: true
    });
    this._dialogRef.componentInstance.title = serverName;
    this._dialogRef.componentInstance.data = '';
    this.subscription = server.detailData$.subscribe(data => {
      this._dialogRef.componentInstance.loading = true;
      if (data.stdout) {
        this._dialogRef.componentInstance.data += data.stdout;
      }
      if (data.returnCode >= 0) {
        this._dialogRef.componentInstance.loading = false;
      }
    });
    this._dialogRef.afterClosed().subscribe(result => {
      this.subscription.unsubscribe();
      this._dialogRef = null;
    });
  }
  finish(): void {
    // Go back to previous page.
    this._location.back();
  }

}