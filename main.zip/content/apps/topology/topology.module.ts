import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../core/modules/shared.module';
import { SearchService } from '../../../shared/services/search.service';
import {WasTopologyComponent} from './was-topology/was-topology.component';
import {WasNdService} from '../design/was-nd/was-nd.service';
import { LibertyTopologyComponent } from './liberty-topology/liberty-topology.component';
import {LibertyService} from '../design/liberty/liberty.service';
import { CellParseService } from '../../../shared/services/cell-parse.service';
import { InventoryService } from '../../../shared/services/inventory.service';
import {WasDataTransformService} from '../../../shared/services/was-data-transform.service';
import { LibertyCellParseService } from '../../../shared/services/liberty-cell-parse.service';
import { SocketService } from '../../../shared/services/socket-service';

const routes: Routes = [
  {
    path     : 'topology/was-topology',
    component: WasTopologyComponent
  },
  {
    path     : 'topology/was-topology/:id',
    component: WasTopologyComponent
  },
  {
    path     : 'topology/liberty-topology',
    component: LibertyTopologyComponent
  },
  {
    path     : 'topology/liberty-topology/:id',
    component: LibertyTopologyComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [WasTopologyComponent, LibertyTopologyComponent],
  providers: [WasNdService, LibertyService, SearchService, CellParseService, InventoryService, WasDataTransformService,
              LibertyCellParseService, SocketService]
})
export class TopologyModule { }
