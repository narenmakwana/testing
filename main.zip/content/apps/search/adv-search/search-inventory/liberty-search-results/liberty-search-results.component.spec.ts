import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertySearchResultsComponent } from './liberty-search-results.component';

describe('LibertySearchResultsComponent', () => {
  let component: LibertySearchResultsComponent;
  let fixture: ComponentFixture<LibertySearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertySearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertySearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
