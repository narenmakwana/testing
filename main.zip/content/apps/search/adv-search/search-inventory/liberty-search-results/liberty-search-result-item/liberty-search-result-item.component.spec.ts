import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertySearchResultItemComponent } from './liberty-search-result-item.component';

describe('LibertySearchResultItemComponent', () => {
  let component: LibertySearchResultItemComponent;
  let fixture: ComponentFixture<LibertySearchResultItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertySearchResultItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertySearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
