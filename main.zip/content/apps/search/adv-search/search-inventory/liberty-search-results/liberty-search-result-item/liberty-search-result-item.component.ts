import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LibertyCell } from '../../../../../../../shared/models/liberty-cell';
import { DialogService } from '../../../../../../../shared/services/dialog.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LibertyService } from '../../../../../design/liberty/liberty.service';
import { LibertyWorkflowService } from '../../../../../../../shared/services/liberty-workflow.service';
import { LibertyCellParseService } from '../../../../../../../shared/services/liberty-cell-parse.service';
import { AuthenticationService } from '../../../../../../pages/authentication/authentication.service';


interface ICellSelected {
    cellname: string;
    checked: boolean;
}

@Component({
    selector: 'c-liberty-search-result-item',
    templateUrl: './liberty-search-result-item.component.html',
    styleUrls: ['./liberty-search-result-item.component.scss']
})
export class LibertySearchResultItemComponent implements OnInit {

    @Input() inventoryData: any;
    @Output() selectedCell: EventEmitter<ICellSelected> = new EventEmitter();

    libertyCellData: LibertyCell;
    versions: any;
    public result: any;

    checked: boolean;
    isAdmin: boolean = false;
    showNode: boolean = false;

    constructor(protected _router: Router, protected _libertyService: LibertyService, private _libertyWorkflow: LibertyWorkflowService,
        protected _cellParseService: LibertyCellParseService, private _dialogService: DialogService, private authService: AuthenticationService) {
        this.libertyCellData = new LibertyCell();
    }

    ngOnInit() {
        this.isAdmin = this.authService.isAdmin();

    }


    onSelection($event) {
        let cellSelected: ICellSelected = {
            cellname: this.inventoryData.cellName,
            checked: this.checked
        };
        this.selectedCell.emit(cellSelected);
    }

    applyFixpack() {
        var wlpVersions = [];
        var ihsVersions = [];
        if (this.inventoryData.ihsVersion) {
            this._libertyService.getIhsVersions()
                .then((results: string[]) => {
                    ihsVersions = results.reverse();
                    ihsVersions = ihsVersions.filter(version => version.startsWith('9'));
                    this._libertyService.getWlpVersions()
                        .then((versions: string[]) => {
                            this.versions = versions.reverse();
                            wlpVersions = this.versions.map(function (a) { return a.wlp; });
                            var currentWlpVersion = this._cellParseService.getWlpVersion(this.inventoryData);
                            var currentIhsVersion = this._cellParseService.getIhsVersion(this.inventoryData);
                            var availWlpFixPacks = [];
                            var availIhsFixPacks = [];
                            var installedWlp = this._cellParseService.getWlpInstalled(this.inventoryData.nodes[0]);
                            for (var i = 0; i < wlpVersions.length; i++) {
                                if (wlpVersions[i] > currentWlpVersion) {
                                    availWlpFixPacks.push(wlpVersions[i]);
                                }
                            }

                            for (var i = 0; i < ihsVersions.length; i++) {
                                if (ihsVersions[i] > currentIhsVersion) {
                                    availIhsFixPacks.push(ihsVersions[i]);
                                }
                            }

                            if (availWlpFixPacks.length === 0 || availIhsFixPacks.length === 0) {
                                this._dialogService.ok('Already at the Latest Fixpack!', '');
                                return;
                            }
                            else {
                                this._dialogService.patch('Select Fixpacks to Install', 'Available Fixpacks', availWlpFixPacks, availIhsFixPacks)
                                    .subscribe(res => {
                                        console.log(res);
                                        if (res.data) {
                                            // OK to proceed
                                            this.result = res;
                                            this.inventoryData.selectedWlpVersion = this.result.data.selectedWlpVersion;
                                            this.inventoryData.selectedIhsVersion = this.result.data.selectedIhsVersion;
                                            var installed = false;
                                            if (installedWlp) {
                                                installedWlp.forEach(version => {
                                                    if (version.includes(this.inventoryData.selectedWlpVersion)) {
                                                        installed = true;
                                                        this.inventoryData.rollback = installed;
                                                        this.inventoryData.selectedWlpVersion = version;
                                                        this.inventoryData.selectedJavaVersion = 'java.' + this.versions.find(v => {
                                                            if (version.includes(v.wlp)) {
                                                                return v.java;
                                                            }
                                                        }).java;
                                                    }
                                                });
                                            }
                                            this._libertyWorkflow.patchCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                                .catch(this.handleError.bind(this));

                                        }
                                    });
                            }
                        })
                }).catch((error => console.log(error)));
        }
        else {
            this._libertyService.getWlpVersions()
                .then((results: string[]) => {
                    this.versions = results.reverse();
                    var wlpVersions = this.versions.map(function (a) { return a.wlp; });
                    var currentWlpVersion = this._cellParseService.getWlpVersion(this.inventoryData);
                    var availWlpFixPacks = [];
                    var installedWlp = this._cellParseService.getWlpInstalled(this.inventoryData.nodes[0]);
                    for (var i = 0; i < wlpVersions.length; i++) {
                        if (wlpVersions[i] > currentWlpVersion) {
                            availWlpFixPacks.push(wlpVersions[i]);
                        }
                    }

                    if (availWlpFixPacks.length === 0) {
                        this._dialogService.ok('Already at the Latest Fixpack!', '');
                        return;
                    }
                    else {
                        this._dialogService.patch('Select Fixpack to Install', 'Available Fixpacks', availWlpFixPacks, [])
                            .subscribe(res => {
                                if (res.data) {
                                    // OK to proceed
                                    console.log(res);
                                    this.result = res;
                                    this.inventoryData.selectedWlpVersion = this.result.data.selectedWlpVersion;
                                    var installed = false;
                                    if (installedWlp) {
                                        installedWlp.forEach(version => {
                                            if (version.includes(this.inventoryData.selectedWlpVersion)) {
                                                installed = true;
                                                this.inventoryData.rollback = installed;
                                                this.inventoryData.selectedWlpVersion = version;
                                                this.inventoryData.selectedJavaVersion = 'java.' + this.versions.find(v => {
                                                    if (version.includes(v.wlp)) {
                                                        return v.java;
                                                    }
                                                }).java;
                                            }
                                        });
                                    }
                                    this._libertyWorkflow.patchCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                        .catch(this.handleError.bind(this));

                                }
                            });
                    }
                })
                .catch((error => console.log(error)));
        }
    }

    rollback() {
        var wlpVersions = [];
        var ihsVersions = [];
        if (this.inventoryData.ihsVersion) {
            this._libertyService.getIhsVersions()
                .then((results: string[]) => {
                    ihsVersions = results.reverse();
                    ihsVersions = ihsVersions.filter(version => version.startsWith('9'));
                    this._libertyService.getWlpVersions()
                        .then((versions: string[]) => {
                            this.versions = versions.reverse();
                            var wlpVersions = this.versions.map(function (a) { return a.wlp; });
                            var currentWlpVersion = this._cellParseService.getWlpVersion(this.inventoryData);
                            var currentIhsVersion = this._cellParseService.getIhsVersion(this.inventoryData);
                            var availWlpFixPacks = [];
                            var availIhsFixPacks = [];
                            var installedWlp = this._cellParseService.getWlpInstalled(this.inventoryData.nodes[0]);

                            for (var i = 0; i < wlpVersions.length; i++) {
                                if (wlpVersions[i] < currentWlpVersion) {
                                    installedWlp.forEach(version => {
                                        if (version.includes(wlpVersions[i])) {
                                            availWlpFixPacks.push(wlpVersions[i]);
                                        }
                                    });
                                }
                            }

                            for (var i = 0; i < ihsVersions.length; i++) {
                                if (ihsVersions[i] < currentIhsVersion) {
                                    availIhsFixPacks.push(ihsVersions[i]);
                                }
                            }

                            if (availWlpFixPacks.length === 0 || availIhsFixPacks.length === 0) {
                                this._dialogService.ok('No Fixpacks available to Rollback to!', '');
                                return;
                            }
                            else {
                                this._dialogService.patch('Select Fixpacks to Rollback', 'Available Fixpacks', availWlpFixPacks, availIhsFixPacks)
                                    .subscribe(res => {
                                        console.log(res);
                                        if (res.data) {
                                            // OK to proceed
                                            this.result = res;
                                            this.inventoryData.selectedIhsVersion = this.result.data.selectedIhsVersion;
                                            this.inventoryData.selectedWlpVersion = this.result.data.selectedWlpVersion;
                                            var installed = false;
                                            if (installedWlp) {
                                                installedWlp.forEach(version => {
                                                    if (version.includes(this.inventoryData.selectedWlpVersion)) {
                                                        installed = true;
                                                        this.inventoryData.rollback = installed;
                                                        this.inventoryData.selectedWlpVersion = version;
                                                        this.inventoryData.selectedJavaVersion = 'java.' + this.versions.find(v => {
                                                            if (version.includes(v.wlp)) {
                                                                return v.java;
                                                            }
                                                        }).java;
                                                    }
                                                });
                                            }
                                            this._libertyWorkflow.rollbackCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                                .catch(this.handleError.bind(this));

                                        }
                                    });
                            }
                        })
                }).catch((error => console.log(error)));
        }
        else {
            this._libertyService.getWlpVersions()
                .then((results: string[]) => {
                    this.versions = results.reverse();
                    var wlpVersions = this.versions.map(function (a) { return a.wlp; });
                    var currentWlpVersion = this._cellParseService.getWlpVersion(this.inventoryData);
                    var availWlpFixPacks = [];
                    var installedWlp = this._cellParseService.getWlpInstalled(this.inventoryData.nodes[0]);
                    for (var i = 0; i < wlpVersions.length; i++) {
                        if (wlpVersions[i] < currentWlpVersion) {
                            installedWlp.forEach(version => {
                                if (version.includes(wlpVersions[i])) {
                                    availWlpFixPacks.push(wlpVersions[i]);
                                }
                            });
                        }
                    }


                    if (availWlpFixPacks.length === 0) {
                        this._dialogService.ok('No Fixpacks available to Rollback to!', '');
                        return;
                    }
                    else {
                        this._dialogService.patch('Select Fixpack to Rollback', 'Available Fixpacks', availWlpFixPacks, [])
                            .subscribe(res => {
                                if (res.data) {
                                    // OK to proceed
                                    console.log(res);
                                    this.result = res;
                                    this.inventoryData.selectedWlpVersion = this.result.data.selectedWlpVersion;
                                    var installed = false;
                                    if (installedWlp) {
                                        installedWlp.forEach(version => {
                                            if (version.includes(this.inventoryData.selectedWlpVersion)) {
                                                installed = true;
                                                this.inventoryData.rollback = installed;
                                                this.inventoryData.selectedWlpVersion = version;
                                                this.inventoryData.selectedJavaVersion = 'java.' + this.versions.find(v => {
                                                    if (version.includes(v.wlp)) {
                                                        return v.java;
                                                    }
                                                }).java;
                                            }
                                        });
                                    }
                                    this._libertyWorkflow.rollbackCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                        .catch(this.handleError.bind(this));

                                }
                            });
                    }
                })
                .catch((error => console.log(error)));
        }
    }


    uninstall() {
        this._dialogService.confirm("Uninstall Cell : " + this.inventoryData.cellName, "Are you sure you want to uninstall this cell?")
            .subscribe(res => {
                console.log(res);
                if (res) {
                    // OK to proceed
                    this._libertyWorkflow.uninstallCell(this.inventoryData).then(this.handleSuccess.bind(this))
                        .catch(this.handleError.bind(this));
                }
            });

    }
    showTopology() {
        //console.log("Viewing Topology For..", this.inventoryData.cellName);
        this._router.navigate(['apps/topology/liberty-topology', this.inventoryData.cellName]);
    }

    showNodes() {
        //console.log("Viewing Nodes For..", this.inventoryData);
        this.showNode = !this.showNode;

        //this._router.navigate(['/topology/liberty-topology', this.inventoryData.nodes[0]._id]);
    }

    cloneCell() {
        //console.log("Cloning Cell..", this.inventoryData);
        this._cellParseService.convertFromInventoryToDesignFormat(this.inventoryData, (libCell) => {
            //console.log(libCell);
            this.libertyCellData = libCell;
            this.libertyCellData._id = ""; // blank out the ID and save the new document first.
            //console.log("Saving new cell...");
            var newCell = this._libertyService.saveLibertyCell(this.libertyCellData).catch(this.handleSaveError.bind(this))
                .then(this.handleSaveSuccess.bind(this));
        });

    }

    handleSuccess() {
        this._router.navigate(['apps/search/jobs-search-results',
            {
                cellId: this.inventoryData.cellName,
                product: 'wlp',
                limit: 20
            }]);
    }

    handleError(error) {
        this._dialogService
            .ok('Error Patching Cell ' + this.inventoryData.cellName, ' Error:' + error)
            .subscribe(res => this.result = res);
    }


    // If the new Cell is saved, go to edit it now
    handleSaveSuccess(response: any) {
        console.log("Success...", response);
        var newCell = response;
        this._router.navigate(['apps/design/liberty', newCell._id]);

    }

    handleSaveError(error: string) {
        console.log("Error Encountered..", error);
    }

    getWlpProductType(): string {
        var productType = this._cellParseService.getwlpProductType(this.inventoryData);
        return "Edition : " + productType;
    }

    getJavaVersion(): string {
        var version = this._cellParseService.getJavaSDKVersions(this.inventoryData);
        return "Java :  " + version;
    }

    getWlpFixPackVersion(): string {
        var version = this._cellParseService.getWlpVersion(this.inventoryData);
        return "Liberty : " + version;
    }

    getIhsFixPackVersion(): string {
        var version = this._cellParseService.getIhsVersion(this.inventoryData);
        return "IHS : " + version;
    }

    getAdminCenterLink(jvm, node): string {
        var adminCenterLink = this._cellParseService.getAdminCenterLink(jvm, node);
        return adminCenterLink;
    }

    getAdminCenterHostName(jvm, node): string {
        var hostName = this._cellParseService.getAdminCenterHostName(node);
        return hostName;
    }
}

