import { InventoryService } from '../../../../../../shared/services/inventory.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectionStrategy, OnInit, OnDestroy, Component, Input } from '@angular/core';
import { OrgService } from '../../../../../../shared/services/org.service';
import { SearchService } from '../../../../../../shared/services/search.service';
import { ResponseResult } from '../../../../../../shared/models/response-result';
import { Subscription, Observable } from "rxjs/Rx";
import { ApplyTagDialogComponent } from '../inv-search-results/apply-tag-dialog/apply-tag-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { LibertySearchResultItemComponent } from './liberty-search-result-item/liberty-search-result-item.component';
import { LibertyCellParseService } from '../../../../../../shared/services/liberty-cell-parse.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import {UditUtils} from '../../../../../../../core/uditUtils';

interface ICellSelected {
  cellname: string;
  checked: boolean;
}


@Component({
  selector: 'c-liberty-search-results',
  templateUrl: './liberty-search-results.component.html',
  styleUrls: ['./liberty-search-results.component.scss'],
  viewProviders: [LibertySearchResultItemComponent]
})
export class LibertySearchResultsComponent implements OnInit {

  responseResults: ResponseResult;
  inventoryCells = [];
  _params: Observable<any>;
  private subscription: Subscription;
  private searchsub: Subscription;
  private _dialogRef: MatDialogRef<ApplyTagDialogComponent>;

  private cellname: string = "";
  private hostname: string = "";
  private tciCode: string = "";
  private envType: string = "";
  private searchText: string = "";
  private tag: string = "";

  private params: string[];
  private limit: number;
  private offset: number;
  private trim: string;

  showGlobalMenu: boolean = false;

  selectedCells: string[] = [];

  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  private _results: { success: boolean, data?: { fullName: string } } = { success: false };

  constructor(protected route: ActivatedRoute, protected _cellParseService: LibertyCellParseService, protected _orgService: OrgService, 
    protected _inventoryService: InventoryService, private _dialog: MatDialog) {
    this.responseResults = new ResponseResult();
  }

  ngOnInit() {
    // subscribe to router event
    /*
    this.route.params.subscribe((_params: Params) => {
        this.params = this.route.queryParams;
        let pparams = this.route.parent.params;
        let cparams = this.route.firstChild.params;
      });
    */
    this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.cellname = params['cellName'];
        this.hostname = params['hostName'];
        this.tciCode = params['tci'];
        this.envType = params['envtype'];
        this.searchText = params['textSearch'];
        this.tag = params['tag'];
        this.limit = +params['limit'];
      });

    this.getPage(1);
  }

  open() {
    this._dialogRef = this._dialog.open(ApplyTagDialogComponent, {
      disableClose: true
    });
    this._dialogRef.componentInstance.fullName = this._results.data ? this._results.data.fullName : '';
    this._dialogRef.afterClosed().subscribe(result => {
      this._results = result;
      this._dialogRef = null;
    });
  }


  invokeSearch(searchTerm) {
 
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  onShowGlobalMenu(): boolean {
    // toggle showMenu
    this.showGlobalMenu = !this.showGlobalMenu;
    return this.showGlobalMenu;
  }

  applyTag($event) {
    // before we apply tag, check to see if atleast one cell is selected.
    if (this.selectedCells.length > 0) {
      //Display a dialog to show the tags.
      this.open();
    }
  }

  clearTag($event) {
    // before we remove tag, check to see if atleast one cell is selected.
    if (this.selectedCells.length > 0) {
      //Display a dialog to show the tags.
    }
  }

  compareCells($event) {
    // before we compare cells, check to see if atleast two cells are selected.
    if (this.selectedCells.length >= 2) {
      //Display a dialog to show the tags.
    }
  }

  filterSelection($event) {
  
  }


  handleCellSelection(event: ICellSelected) {
    if (event.checked) {
      // add the cellname to the list of selected cells.
      this.selectedCells.push(event.cellname);
    }
    else {
      // the cell is deselected. check to see if it exists in our list of selected cells 
      // if it exists, then remove it from that list.
      for (let i = 0; i < this.selectedCells.length; i++) {
        if (this.selectedCells[i] === event.cellname) {
          // found it. remove it from the list.
          this.selectedCells.splice(i, 1);
        }
      }
    }
  }

  search(limit: number, page: number) {
    // calculate the offset based on page number and limit.
    var offset = (page - 1) * limit;
    var paramObj = {
      "cellName": this.cellname,
      "nodes.hostName": this.hostname,
      "cellName.startsWith": this.tciCode,
      "cellName.contains": this.envType,
      "textSearch": this.searchText,
      "tag": this.tag
    };
    var paramString = UditUtils.buildQueryParams(paramObj);
    let httpParams = new HttpParams({
      fromString: paramString
    });
               
    this._inventoryService.getWlpInventory(httpParams)
      .then((data) => {
        this.responseResults = data;
        this.inventoryCells = this.responseResults.items;
        this.total = this.responseResults.items.length;
        //this.total = this.responseResults.total;
        this.p = page;
        this.loading = false;
      });
  }


  getPage(page: number) {
    this.loading = true;
    if (page === 1) {
      this.inventoryCells = [];
      this.search(this.limit, page);
    } else {
      this.p = page;
      this.loading = false;
    }
  }
}

