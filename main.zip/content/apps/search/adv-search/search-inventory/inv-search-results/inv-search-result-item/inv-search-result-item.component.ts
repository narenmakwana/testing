import { Component, OnInit, Input, Output, EventEmitter, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { CellParseService } from '../../../../../../../shared/services/cell-parse.service';
import { WasCell } from '../../../../../../../shared/models/was-cell';
import { WasDataTransformService } from '../../../../../../../shared/services/was-data-transform.service';
import { DialogService } from './../../../../../../../shared/services/dialog.service';
import { WasWorkflowService } from './../../../../../../../shared/services/was-workflow.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { WasNdService } from '../../../../../design/was-nd/was-nd.service';
import { UditConfirmDialogComponent } from '../../../../../../../../core/components/confirm-dialog/confirm-dialog.component';
import { uditAnimations } from '../../../../../../../../core/animations';
import { AuthenticationService } from '../../../../../../pages/authentication/authentication.service';


interface ICellSelected {
    cellname: string;
    checked: boolean;

}

@Component({
    selector: 'c-inv-search-result-item',
    templateUrl: './inv-search-result-item.component.html',
    styleUrls: ['./inv-search-result-item.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations: uditAnimations
})
export class InvSearchResultItemComponent implements OnInit {

    @Input() inventoryData: any;
    @Output() selectedCell: EventEmitter<ICellSelected> = new EventEmitter();

    @ViewChild('dialogContent') dialogContent: TemplateRef<any>;

    wasNdCellData: WasCell;
    versions: any;
    checked: boolean;
    public result: any;
    isAdmin: boolean = false;

    constructor(protected _cellParseService: CellParseService, private wasDataTransformService: WasDataTransformService,
        protected _router: Router, protected _wasNdService: WasNdService, private authService: AuthenticationService,
        private _dialogService: DialogService, private _wasWorkflow: WasWorkflowService) {
        this.wasNdCellData = new WasCell();
    }

    ngOnInit() {
        this.isAdmin = this.authService.isAdmin();
    }


    onSelection($event) {
        let cellSelected: ICellSelected = {
            cellname: this.inventoryData.cellName,
            checked: this.checked
        };
        this.selectedCell.emit(cellSelected);
    }

    applyFixpack() {
        var wasVersions = [];
        var ihsVersions = [];
        var ihsInstalled = false;

        this.inventoryData.nodes.forEach(node => {
            if (node.nodeName.includes('ihs')) {
                ihsInstalled = true;
            }
        });

        this._wasNdService.getWasNdVersions()
            .then((results: string[]) => {
                this.versions = results;
                var wasVersion = this._cellParseService.getWasVersion(this.inventoryData.cellName);
                wasVersion = wasVersion.slice(0, 1) + '.' + wasVersion.slice(1);
                wasVersions = results;
                var currentWasVersion = this._cellParseService.getWasVersions(this.inventoryData)[0].version;
                var availWasFixPacks = [];
                var availIhsFixPacks = [];

                if (ihsInstalled) {
                    var currentIhsVersion = this._cellParseService.getWasVersions(this.inventoryData)[0].version;
                    ihsVersions = results;
                }

                for (var i = 0; i < this.versions.length; i++) {
                    var version = parseInt(this.versions[i].replace(/\./g, ''));
                    var current = parseInt(currentWasVersion.replace(/\./g, ''));
                    if (version > current && this.versions[i].includes(wasVersion)) {
                        availWasFixPacks.push(this.versions[i]);
                        if (ihsInstalled) {
                            availIhsFixPacks.push(this.versions[i]);
                        }
                    }
                }

                availWasFixPacks.sort().reverse();
                if (availIhsFixPacks.length > 0) {
                    availIhsFixPacks.sort().reverse();
                }

                if (availWasFixPacks.length === 0 && availIhsFixPacks.length === 0) {
                    this._dialogService.ok('Already at the Latest Fixpack!', '');
                    return;
                }
                else {
                    this._dialogService.patch('Select Fixpacks to Install', 'Available Fixpacks', availWasFixPacks, availIhsFixPacks)
                        .subscribe(res => {
                            console.log(res);
                            if (res.data) {
                                // OK to proceed
                                this.result = res;
                                this.inventoryData.nodes.forEach(node => {
                                    node.selectedWasVersion = this.result.data.selectedWlpVersion;
                                    if (ihsInstalled) {
                                        node.selectedIhsVersion = this.result.data.selectedIhsVersion;
                                    }
                                });
                                this._wasWorkflow.patchCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                    .catch(this.handleError.bind(this));
                            }
                        });
                }
            }).catch((error => console.log(error)));
    }

    rollback() {
        var wasVersions = [];
        var ihsVersions = [];
        var ihsInstalled = false;

        this.inventoryData.nodes.forEach(node => {
            if (node.nodeName.includes('ihs')) {
                ihsInstalled = true;
            }
        });

        this._wasNdService.getWasNdVersions()
            .then((results: string[]) => {
                this.versions = results;
                var wasVersion = this._cellParseService.getWasVersion(this.inventoryData.cellName);
                wasVersion = wasVersion.slice(0, 1) + '.' + wasVersion.slice(1);
                wasVersions = results;
                var currentWasVersion = this._cellParseService.getWasVersions(this.inventoryData)[0].version;
                var availWasFixPacks = [];
                var availIhsFixPacks = [];

                if (ihsInstalled) {
                    var currentIhsVersion = this._cellParseService.getWasVersions(this.inventoryData)[0].version;
                    ihsVersions = results;
                }

                for (var i = 0; i < this.versions.length; i++) {
                    var version = parseInt(this.versions[i].replace(/\./g, ''));
                    var current = parseInt(currentWasVersion.replace(/\./g, ''));
                    if (version < current && this.versions[i].includes(wasVersion)) {
                        availWasFixPacks.push(this.versions[i]);
                        if (ihsInstalled){
                            availIhsFixPacks.push(this.versions[i]);
                        }
                    }
                }

                if (availWasFixPacks.length === 0 && availIhsFixPacks.length === 0) {
                    this._dialogService.ok('Already at the Latest Fixpack!', '');
                    return;
                }
                else {
                    availWasFixPacks = availWasFixPacks.reverse();
                    availIhsFixPacks = availIhsFixPacks.reverse();
                    this._dialogService.patch('Select Fixpacks to Rollback to', 'Available Fixpacks', availWasFixPacks, availIhsFixPacks)
                        .subscribe(res => {
                            console.log(res);
                            if (res.data) {
                                // OK to proceed
                                this.result = res;
                                this.inventoryData.nodes.forEach(node => {
                                    node.selectedWasVersion = this.result.data.selectedWlpVersion;
                                    node.selectedIhsVersion = this.result.data.selectedIhsVersion;
                                });
                                console.log(this.inventoryData);
                                this._wasWorkflow.rollbackCell(this.inventoryData).then(this.handleSuccess.bind(this))
                                    .catch(this.handleError.bind(this));
                            }
                        });
                }
            }).catch((error => console.log(error)));
    }

    uninstall() {
        this._dialogService.confirm("Uninstall Cell : " + this.inventoryData.cellName, "Are you sure you want to uninstall this cell?")
            .subscribe(res => {
                console.log(res);
                if (res) {
                    // OK to proceed
                    this._wasWorkflow.uninstallCell(this.inventoryData).then(this.handleSuccess.bind(this))
                        .catch(this.handleError.bind(this));
                }
            });
    }


    handleSuccess() {
        this._router.navigate(['apps/search/jobs-search-results',
            {
                cellId: this.inventoryData.cellName,
                product: 'was',
                limit: 20
            }]);
    }

    handleError(error) {
        this._dialogService
            .ok('Error Patching Cell ' + this.inventoryData.cellName, ' Error:' + error)
            .subscribe(res => this.result = res);
    }


    showTopology() {

        this._router.navigate(['apps/topology/was-topology', this.inventoryData._id]);
    }

    // If the new Cell is saved, go to edit it now.
    handleSaveSuccess(response: any) {
        var newCell = response;
        this._router.navigate(['apps/design/wasnd', newCell._id]);
    }

    handleSaveError(error: string) {
        console.log("Error Encountered..", error);
    }

    cloneCell() {
        this._wasNdService.getWasInvCellByCellId(this.inventoryData.cellName).then(this.retrieveAndCloneCell.bind(this));
    }

    retrieveAndCloneCell(response: any) {
        if (response.count > 0) {
            this.inventoryData = response.items[0];
            this.wasNdCellData = this._cellParseService.convertFromInventoryToDesignFormat(this.inventoryData);
            this.wasNdCellData._id = ""; // blank out the ID and save the new document first.
            var newCell = this._wasNdService.saveWasCell(this.wasNdCellData).catch(this.handleSaveError.bind(this))
                .then(this.handleSaveSuccess.bind(this));

        }
    }

    getNodeSDK(): string {
        for (var i = 0; i < this.inventoryData.nodes.length; i++) {
            if (this.inventoryData.nodes[i].nodeSDK)
                return this.inventoryData.nodes[i].nodeSDK;
        }
        return "N/A";
    }

    getWasVersion(): string {
        var versions = this._cellParseService.getWasVersions(this.inventoryData);
        return versions.length ? versions[0].version : 'None';
    }

    getJavaVersion(): string {
        var versions = this._cellParseService.getJavaSDKVersions(this.inventoryData);
        return versions.length ? versions[0].version : 'None';
    }

    getWasFPVersion(): string {
        var versions = this._cellParseService.getWasFixPackVersions(this.inventoryData);
        return versions.length ? versions[0].version : 'None';
    }

    getDmgrLink(): string {
        return this._cellParseService.getDmgrLink(this.inventoryData);
    }

    getDmgrHostName(): string {
        return this._cellParseService.getDmgrHostName(this.inventoryData);
    }

}
