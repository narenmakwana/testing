import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvSearchResultItemComponent } from './inv-search-result-item.component';

describe('InvSearchResultItemComponent', () => {
  let component: InvSearchResultItemComponent;
  let fixture: ComponentFixture<InvSearchResultItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvSearchResultItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvSearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
