import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvSearchResultsComponent } from './inv-search-results.component';

describe('InvSearchResultsComponent', () => {
  let component: InvSearchResultsComponent;
  let fixture: ComponentFixture<InvSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
