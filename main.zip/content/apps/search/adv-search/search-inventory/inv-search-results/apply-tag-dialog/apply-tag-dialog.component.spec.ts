import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyTagDialogComponent } from './apply-tag-dialog.component';

describe('ApplyTagDialogComponent', () => {
  let component: ApplyTagDialogComponent;
  let fixture: ComponentFixture<ApplyTagDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyTagDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyTagDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
