import { Component, OnInit } from '@angular/core';
import {MatDialogRef} from '@angular/material';

@Component({
  selector: 'c-apply-tag-dialog',
  templateUrl: './apply-tag-dialog.component.html',
  styleUrls: ['./apply-tag-dialog.component.scss']
})
export class ApplyTagDialogComponent implements OnInit {

  fullName: string = '';

  constructor(public dialogRef: MatDialogRef<ApplyTagDialogComponent>) {
  }

  ngOnInit() {
  }

  confirm() {
    this.dialogRef.close({success : true, data : {fullName : this.fullName}});
  }

  cancel() {
    this.dialogRef.close({success : false});
  }

}
