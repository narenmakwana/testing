import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import { OrgService } from '../../../../../shared/services/org.service';
import { InventoryService } from '../../../../../shared/services/inventory.service';
import {Dcio} from '../../../../../shared/models/dcio';
import {TciCodes} from '../../../../../shared/models/tci-codes';
import {TciCodesResult} from '../../../../../shared/models/tci-codes-result';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'c-search-inventory',
  templateUrl: './search-inventory.component.html',
  styleUrls: ['./search-inventory.component.scss']
})

export class SearchInventoryComponent implements OnInit {

  cellname: string = ""; 
  hostname: string = "";
  tciCode: string = "";
  envType: string = "";
  searchText: string = "";
  tag: string = "";

  params: string[];
  limit: number;
  offset: number;
  trim: string;

  constructor( protected _router: Router, protected _orgService: OrgService, protected _inventoryService: InventoryService ) { 

  }


  ngOnInit() { 
  }  

  search() {
     this._router.navigate(['apps/search/inv-search-results', 
              { cellId: this.cellname, 
                host : this.hostname, 
                tci: this.tciCode,
                envtype: this.envType,
                textSearch: this.searchText,
                tag: this.tag,
                limit: 20,
                fields: "-globalSecurity,-nodes.servers"
              }]);
  }
}
