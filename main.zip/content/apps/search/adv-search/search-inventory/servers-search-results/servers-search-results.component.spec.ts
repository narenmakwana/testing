import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServersSearchResultsComponent } from './servers-search-results.component';

describe('ServersSearchResultsComponent', () => {
  let component: ServersSearchResultsComponent;
  let fixture: ComponentFixture<ServersSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServersSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServersSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
