import { InventoryService } from '../../../../../../shared/services/inventory.service';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {ChangeDetectionStrategy, OnInit, OnDestroy, Component, Input} from '@angular/core';
import { OrgService } from '../../../../../../shared/services/org.service';
import { ResponseResult } from '../../../../../../shared/models/response-result';
import { Subscription,  Observable } from "rxjs/Rx";
import {ApplyTagDialogComponent} from '../inv-search-results/apply-tag-dialog/apply-tag-dialog.component';
import {MatDialogRef, MatDialog} from '@angular/material';
import { ServersSearchResultsItemComponent } from './servers-search-results-item/servers-search-results-item.component';
import { HttpClient, HttpParams } from '@angular/common/http';
import {UditUtils} from '../../../../../../../core/uditUtils';

@Component({
  selector: 'c-servers-search-results',
  templateUrl: './servers-search-results.component.html',
  styleUrls: ['./servers-search-results.component.scss']
})
export class ServersSearchResultsComponent implements OnInit {

  responseResults: ResponseResult;
  _params : Observable<any>;
  private subscription: Subscription;
  private searchsub : Subscription;
  private _dialogRef: MatDialogRef<ApplyTagDialogComponent>;

  private hostname: string = "";
  private os: string = "";
  private ipaddress: string = "";

  private params: string[];
  private limit: number;
  private offset: number;
  private trim: string;

  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected route: ActivatedRoute, protected _orgService: OrgService, 
                   protected _inventoryService: InventoryService, 
    private _dialog: MatDialog ) { 
       this.responseResults = new ResponseResult(); 
  }
  ngOnInit() {
        this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.hostname = params['hostname'];
        this.os = params['os'];
        this.ipaddress = params['ipaddress'];
        this.limit = +params['limit'];
    });

    this.getPage(1);
  }

  ngOnDestroy() {
      this.subscription.unsubscribe();
  }

  search(limit: number, page : number){
    // calculate the offset based on page number and limit.
    var offset = (page - 1) * limit;
    var paramObj = {
      "hostname.contains" : this.hostname,
      "os.release.full.contains" : this.os,
      "ipaddress.contains" : this.ipaddress,
      "limit": limit,
      "offset" : offset
    };

    var paramString = UditUtils.buildQueryParams(paramObj);
    let httpParams = new HttpParams({
      fromString: paramString
    });

    this._inventoryService.getServersInventory(httpParams)
                        .then((data)=>{
                          this.responseResults = this.processInvData(data);
                          this.total = this.responseResults.total;
                          this.p = page;
                          this.loading = false;
                        });
  }

  getPage(page: number) {
      this.loading = true;
      this.search(this.limit, page);
  }

  processInvData(data: any) {
      var responseData : any;
      responseData = data;
      return responseData;
  }

}
