import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {MatDialogRef, MatDialog} from '@angular/material';
import {JsonDialog} from '../../../../../../../shared/components/json-dialog.component';

@Component({
  selector: 'c-servers-search-results-item',
  templateUrl: './servers-search-results-item.component.html',
  styleUrls: ['./servers-search-results-item.component.scss']
})
export class ServersSearchResultsItemComponent implements OnInit {

  @Input() inventoryData : any;
  private _dialogRef: MatDialogRef<JsonDialog>;
  private _results: {success: boolean, data?: {serverInfo: any}} = {success : false};
  checked : boolean = false;
 
  constructor(private _dialog: MatDialog) { }

  ngOnInit() {
  }

  showDetails() {
     this.open();
  }

  onSelection( event ) {
     // Checkbox Selected.
  }

  open() {
    this._dialogRef = this._dialog.open(JsonDialog, {
      height: '600px',
      width: '800px',
      disableClose : true
    });
    this._dialogRef.componentInstance.title = this.inventoryData.hostname;
    this._dialogRef.componentInstance.jsondata = JSON.stringify(this.inventoryData);
    this._dialogRef.afterClosed().subscribe(result => {
      this._results = result;
      this._dialogRef = null;
    });
  }

}
