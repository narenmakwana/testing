import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServersSearchResultsItemComponent } from './servers-search-results-item.component';

describe('ServersSearchResultsItemComponent', () => {
  let component: ServersSearchResultsItemComponent;
  let fixture: ComponentFixture<ServersSearchResultsItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServersSearchResultsItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServersSearchResultsItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
