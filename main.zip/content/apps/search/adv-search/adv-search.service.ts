import {Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Constants} from '../../../../../main/shared/config/constants';

@Injectable()
export class AdvSearchService  {

  constructor(private http: HttpClient ) {
  }

  public getWasDeploymentJobs( httpParams ) : Promise<any> {
      return this.http.get(Constants.getDeployWasCellUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.deploymentJobSearchResults)
                    .catch(this.handleError);
  }

  public getWlpDeploymentJobs( httpParams ) : Promise<any> {
      return this.http.get(Constants.getDeployLibertyCellUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.deploymentJobSearchResults)
                    .catch(this.handleError);
  }

  public getLinuxDeploymentJobs( httpParams ) : Promise<any> {
      return this.http.get(Constants.getDeployLinuxUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.deploymentJobSearchResults)
                    .catch(this.handleError);
  }


  deploymentJobSearchResults (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 
}
