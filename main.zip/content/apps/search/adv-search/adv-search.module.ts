import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { AdvSearchComponent } from './adv-search.component';
import { InvSearchResultsComponent } from './search-inventory/inv-search-results/inv-search-results.component';
import { SearchInventoryComponent } from './search-inventory/search-inventory.component';
import { InvSearchResultItemComponent } from './search-inventory/inv-search-results/inv-search-result-item/inv-search-result-item.component';
import { ApplyTagDialogComponent } from './search-inventory/inv-search-results/apply-tag-dialog/apply-tag-dialog.component';
import { WasNdService } from '../../design/was-nd/was-nd.service';
import { PackagesService } from '../../../../shared/services/packages.service';
import { OptionsService } from '../../../../shared/services/options.service';
import { CellParseService } from '../../../../shared/services/cell-parse.service';
import { DataFormatService } from '../../../../shared/services/data-format.service';
import { OrgService } from '../../../../shared/services/org.service';
import { TagsService } from '../../../../shared/services/tags.service';
import { DialogService } from '../../../../shared/services/dialog.service';
import { SearchService } from '../../../../shared/services/search.service';
import { WasDataTransformService } from '../../../../shared/services/was-data-transform.service';
import { LibertyCellParseService } from '../../../../shared/services/liberty-cell-parse.service';
import { LibertyDataTransformService } from '../../../../shared/services/liberty-data-transform.service';
import { LibertyWorkflowService } from '../../../../shared/services/liberty-workflow.service';
import { LinuxWorkflowService } from '../../../../shared/services/linux-workflow.service';
import { WasWorkflowService } from '../../../../shared/services/was-workflow.service';
import { DeployService } from '../../../../shared/services/deploy.service';
import { LibertyService } from '../../design/liberty/liberty.service';
import { LibertySearchResultsComponent } from './search-inventory/liberty-search-results/liberty-search-results.component';
import { LibertySearchResultItemComponent } from './search-inventory/liberty-search-results/liberty-search-result-item/liberty-search-result-item.component';
import { ServersSearchResultsComponent } from './search-inventory/servers-search-results/servers-search-results.component';
import { ServersSearchResultsItemComponent } from './search-inventory/servers-search-results/servers-search-results-item/servers-search-results-item.component';
import { SearchJobsComponent } from './search-jobs/search-jobs.component';
import { JobsSearchResultsComponent } from './search-jobs/jobs-search-results/jobs-search-results.component';
import { WasSearchResultItemComponent } from './search-jobs/jobs-search-results/was-search-result-item/was-search-result-item.component';
import { WlpSearchResultItemComponent } from './search-jobs/jobs-search-results/wlp-search-result-item/wlp-search-result-item.component';
import { AdvSearchService } from './adv-search.service';
import { SearchLinuxJobsComponent } from './search-jobs/search-linux-jobs/search-linux-jobs.component';
import { LinuxJobsSearchResultsComponent } from './search-jobs/search-linux-jobs/linux-job-search-results/linux-job-search-results.component';
import { LinuxJobSearchResultItemComponent } from './search-jobs/search-linux-jobs/linux-job-search-results/linux-job-search-result-item/linux-job-search-result-item.component';
import { SocketService } from '../../../../shared/services/socket-service';


const routes: Routes = [
  {
      path     : 'search/adv-search',
      component: AdvSearchComponent
  },
  {
    path     : 'search/inv-search-results',
    component: InvSearchResultsComponent
  },
  {
    path     : 'search/liberty-search-results',
    component: LibertySearchResultsComponent
  },
  {
    path     : 'search/servers-search-results',
    component: ServersSearchResultsComponent
  },
  {
    path     : 'search/jobs-search-results',
    component: JobsSearchResultsComponent
  },
  {
    path     : 'search/linux-jobs-search-results',
    component: LinuxJobsSearchResultsComponent
  },
];


@NgModule({
  imports: [
    SharedModule,
    NgxPaginationModule,
    RouterModule.forChild(routes)
  ],
  declarations: [AdvSearchComponent, InvSearchResultsComponent, SearchInventoryComponent, InvSearchResultItemComponent, 
    ApplyTagDialogComponent, LibertySearchResultsComponent, LibertySearchResultItemComponent, 
    ServersSearchResultsComponent, ServersSearchResultsItemComponent, SearchJobsComponent, 
    JobsSearchResultsComponent, WasSearchResultItemComponent, WlpSearchResultItemComponent, SearchLinuxJobsComponent, 
    LinuxJobSearchResultItemComponent, LinuxJobsSearchResultsComponent],
  providers: [InventoryService, WasNdService, PackagesService, OptionsService, DataFormatService,
              OrgService, TagsService, DialogService, SearchService, WasDataTransformService, WasWorkflowService,
              LibertyCellParseService, LibertyDataTransformService, LibertyWorkflowService, LibertyService,
              AdvSearchService, DeployService, LinuxWorkflowService, SocketService
   ]
})
export class AdvSearchModule { }
