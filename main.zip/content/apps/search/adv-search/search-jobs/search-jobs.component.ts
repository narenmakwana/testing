import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { OrgService } from '../../../../../shared/services/org.service';
import {Dcio} from '../../../../../shared/models/dcio';
import {TciCodes} from '../../../../../shared/models/tci-codes';
import {TciCodesResult} from '../../../../../shared/models/tci-codes-result';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'c-search-jobs',
  templateUrl: './search-jobs.component.html',
  styleUrls: ['./search-jobs.component.scss']
})

export class SearchJobsComponent implements OnInit {

  cellName: string = ""; 
  buildState: string = "";
  tciCode: string = "";
  envType: string = "";
  searchText: string = "";

  constructor( protected _router: Router, protected _orgService: OrgService ) { 

  }

  ngOnInit() {
  }  

  search() {
    this._router.navigate(['apps/search/jobs-search-results', 
              { cellId: this.cellName, 
                tci: this.tciCode,
                env: this.envType,
                textSearch: this.searchText,
                state: this.buildState,
                limit: 20
              }]);     
  }

}
