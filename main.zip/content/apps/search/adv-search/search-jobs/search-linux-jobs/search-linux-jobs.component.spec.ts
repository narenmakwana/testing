import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchLinuxJobsComponent } from './search-linux-jobs.component';

describe('SearchLinuxJobsComponent', () => {
  let component: SearchLinuxJobsComponent;
  let fixture: ComponentFixture<SearchLinuxJobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchLinuxJobsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchLinuxJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
