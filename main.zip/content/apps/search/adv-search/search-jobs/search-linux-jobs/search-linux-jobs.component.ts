import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AdvSearchService } from '../../adv-search.service';

@Component({
  selector: 'c-search-linux-jobs',
  templateUrl: './search-linux-jobs.component.html',
  styleUrls: ['./search-linux-jobs.component.scss']
})
export class SearchLinuxJobsComponent implements OnInit {

  project_name: string = ""; 
  searchText: string = "";

  constructor( protected _router: Router, protected _searchService: AdvSearchService ) { 

  }

  ngOnInit() {
  }  

  search() {
    this._router.navigate(['apps/search/linux-jobs-search-results', 
              { project_name: this.project_name, 
                textSearch: this.searchText,
                limit: 20
              }]);     
  }

}