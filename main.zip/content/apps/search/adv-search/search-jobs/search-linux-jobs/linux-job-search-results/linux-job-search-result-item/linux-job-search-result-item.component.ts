import { Component, OnInit, Input  } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { LinuxWorkflowService } from '../../../../../../../../shared/services/linux-workflow.service';
import { DeployService } from '../../../../../../../../shared/services/deploy.service';
import { DialogService } from '../../../../../../../../shared/services/dialog.service';
import { Subscription,  Observable } from "rxjs/Rx";

@Component({
  selector: 'c-linux-job-search-result-item',
  templateUrl: './linux-job-search-result-item.component.html',
  styleUrls: ['./linux-job-search-result-item.component.scss']
})
export class LinuxJobSearchResultItemComponent implements OnInit {

  @Input() deployJobsData : any;

  public dialogResult : any;
  currstatus: string;
  currstate: string;
  projectSelected : boolean = false;

  constructor(protected _router: Router, protected _route: ActivatedRoute, 
   protected _workflowService: LinuxWorkflowService, protected _deployService: DeployService, 
   private _dialogService: DialogService) { 
      
  }

  ngOnInit() {
      this.displayJobProgressState();
      this.displayJobProgressStatus();
  }

  getStatusLabel = function(statusId){
      var label = this._workflowService.getStateLabel('build', statusId);
      return label;
  };

  getLatestStatus = function(statusArr){
      if(!statusArr || !statusArr.length){
        return null;
      }
//      return statusArr[statusArr.length-1];
      return statusArr[0];  // the 0 position has the latest status.
  };

  getStatusValue = function(statusArr){
    var status = this.getLatestStatus(statusArr);
    if(status.complete){
      return '100%';
    }
    else {
      return status.progress + '%';
    }
  };

  displayJobProgressState() {
    this.currstate = this.getStatusLabel(this.getLatestStatus(this.deployJobsData.status).state)
  }

  displayJobProgressStatus(){
    this.currstatus =  this.getStatusValue(this.deployJobsData.status)
  }

  hasRetry = function(doc){
    var status = this.getLatestStatus(doc.status).error;
    return status;
  };

  onMoveToNextStage(event) {
      this._dialogService
      .confirm('Move to Next Stage', 'Are you sure you want to do this?')
      .subscribe(res => { 
        if(res) {
          // OK to proceed
          var status = this.getLatestStatus(this.deployJobsData.status)
          var targetState = this._workflowService.getNextAction('build', status);
          this._deployService.updateLinuxState(this.deployJobsData._id, 'build', targetState).then(resp=>{
            // check the response. If OK, then just navigate back to this url to refresh this page.
              this.currstate = this.getStatusLabel(targetState);
          }, function(err){
            if(err.error !== 'ERR_NOT_AUTHORIZED'){
              // DialogService.showErrorDialog('Deployment Error.  Please Try Again Later');
            }
          });
        }
      });
  }

  onRetryClicked(event) {
      this._dialogService
      .confirm('Retry', 'Are you sure you want to Retry?')
      .subscribe(res => { 
        if(res) {
          // OK to proceed
          var status = this.getLatestStatus(this.deployJobsData.status)
          var targetState = this._workflowService.getNextAction('build', status);
          this._deployService.updateLinuxState(this.deployJobsData._id, 'build', targetState).then(resp=>{
            //scope.refresh();
            window.location.reload(); // reload page.
          }, function(err){
            if(err.error !== 'ERR_NOT_AUTHORIZED'){
              // DialogService.showErrorDialog('Deployment Error.  Please Try Again Later');
            }
          });
        }
      });
  }

}
