import { AdvSearchService } from '../../../adv-search.service';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {OnInit, Component, Input} from '@angular/core';
import { ResponseResult } from '../../../../../../../shared/models/response-result';
import { Subscription,  Observable } from "rxjs/Rx";
import { LinuxWorkflowService } from '../../../../../../../shared/services/linux-workflow.service';
import {LinuxJobSearchResultItemComponent} from './linux-job-search-result-item/linux-job-search-result-item.component';
import { HttpClient, HttpParams } from '@angular/common/http';
import {UditUtils} from '../../../../../../../../core/uditUtils';

@Component({
  selector: 'c-linux-jobs-search-results',
  templateUrl: './linux-job-search-results.component.html',
  styleUrls: ['./linux-job-search-results.component.scss'],
  viewProviders: [LinuxJobSearchResultItemComponent]
})
export class LinuxJobsSearchResultsComponent implements OnInit {

  responseResults: ResponseResult;
  private subscription: Subscription;
  project_name: string = ""; 
  searchText: string = "";
  product: string = "linux";

  params: string[] = [];
  limit: number = 20;
  offset: number = 0;
  trim: string = "";

  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected route: ActivatedRoute, protected _searchService: AdvSearchService, 
              protected _linuxWorkflow: LinuxWorkflowService ) { 
       this.responseResults = new ResponseResult();
  }

 
  ngOnInit() { 
    // subscribe to router event
     this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.project_name = params['project_name'];
        this.product = params['product'];
        this.searchText = params['textSearch'];
        this.limit = +params['limit'];
    });
    this._linuxWorkflow.discoverWorkflow();
    this.getPage(1);
  }

   search(limit: number, page : number){
     // calculate the offset based on page number and limit.
     var offset = (page - 1) * limit;
     var paramObj = {
        "project_name" : (this.project_name === "undefined")? "" : this.project_name,
         "textSearch" : (this.searchText === "undefined") ? "" : this.searchText,
         "limit": 20
     };

     var paramString = UditUtils.buildQueryParams(paramObj);

     let httpParams = new HttpParams({
       fromString: paramString
     });
   
     this._searchService.getLinuxDeploymentJobs(httpParams)
                          .then((data)=>{
                            this.responseResults = this.processData(data);
                            this.total = this.responseResults.total;
                            this.p = page;
                            this.loading = false;
                          });
  }

  getPage(page: number) {
      this.loading = true;
      this.search(this.limit, page);
  }

  processData(data: any) {
      var responseData : any;
      responseData = data;
      return responseData;
  }

}
