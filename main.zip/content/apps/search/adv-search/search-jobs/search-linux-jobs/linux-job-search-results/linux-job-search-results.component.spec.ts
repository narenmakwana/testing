import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxJobSearchResultsComponent } from './linux-job-search-results.component';

describe('LinuxJobSearchResultsComponent', () => {
  let component: LinuxJobSearchResultsComponent;
  let fixture: ComponentFixture<LinuxJobSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxJobSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxJobSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
