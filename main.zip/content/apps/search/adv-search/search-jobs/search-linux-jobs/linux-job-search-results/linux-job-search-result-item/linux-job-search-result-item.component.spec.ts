import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxJobSearchResultItemComponent } from './linux-job-search-result-item.component';

describe('LinuxJobSearchResultItemComponent', () => {
  let component: LinuxJobSearchResultItemComponent;
  let fixture: ComponentFixture<LinuxJobSearchResultItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxJobSearchResultItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxJobSearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
