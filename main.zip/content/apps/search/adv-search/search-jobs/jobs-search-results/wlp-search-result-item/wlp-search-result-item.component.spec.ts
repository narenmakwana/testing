import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WlpSearchResultItemComponent } from './wlp-search-result-item.component';

describe('WlpSearchResultItemComponent', () => {
  let component: WlpSearchResultItemComponent;
  let fixture: ComponentFixture<WlpSearchResultItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WlpSearchResultItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WlpSearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
