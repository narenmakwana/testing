import { DialogService } from './../../../../../../../shared/services/dialog.service';
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LibertyWorkflowService } from '../../../../../../../shared/services/liberty-workflow.service';
import { DeployService } from '../../../../../../../shared/services/deploy.service';
import { Subscription, Observable } from "rxjs/Rx";
import { AnonymousSubscription } from "rxjs/Subscription";
import { AuthenticationService } from '../../../../../../pages/authentication/authentication.service';



@Component({
  selector: 'c-wlp-search-result-item',
  templateUrl: './wlp-search-result-item.component.html',
  styleUrls: ['./wlp-search-result-item.component.scss']
})
export class WlpSearchResultItemComponent implements OnInit {

  @Input() deployJobsData: any;
  @Output() deleteEvent = new EventEmitter();

  private timerSubscription: AnonymousSubscription;
  public dialogResult: any;
  currstatus: string;
  currstate: string;
  isAdmin: boolean = false;
  cellSelected: boolean = false;
  showStatus: boolean = false;
  loading: boolean = false;
  inProgress: boolean = false;
  failed: boolean = false;
  complete: boolean = false;
  logMessage: string;


  constructor(protected _router: Router, protected _route: ActivatedRoute, protected _workflowService: LibertyWorkflowService,
    protected _deployService: DeployService, private _dialogService: DialogService, private authService: AuthenticationService) {
  }

  ngOnInit() {
    this.displayJobStatus();
    this.refreshData();
    this.isAdmin = this.authService.isAdmin();
  }

  ngOnDestroy(): void {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
  }

  private refreshData(): void {
    //console.log("inside refresh data");
    if (this.inProgress) {
      this._workflowService.getDeploymentJob(this.deployJobsData._id)
        .subscribe(
          data => {
            this.deployJobsData = data["items"][0];
            this.displayJobStatus();
            this.subscribeToData();
          },
          err => {
            console.log(err);
          })
    }
    else {
      this._workflowService.getDeploymentJob(this.deployJobsData._id)
        .subscribe(
          data => {
            this.deployJobsData = data;
            this.deployJobsData = this.deployJobsData.items[0];
            this.displayJobStatus();
            ///console.log(this.currstate);
          },
          err => {
            console.log(err);
          })

    }
  }

  displayJobStatus() {
    var status = this.getLatestStatus(this.deployJobsData.status);
    this.currstate = this.getStatusLabel(status.state);
    this.currstatus = this.getStatusValue(status);
    this.logMessage = this.getStatusMessage(status);
    //console.log(this.currstate);
    if (this.currstatus !== '100%') {
      this.inProgress = true;
      this.loading = true;
      if (this.logMessage && this.logMessage.startsWith('Command failed')) {
        this.failed = true;
        this.inProgress = false;
        this.loading = false;
      }
    }
    else {
      this.inProgress = false;
      this.loading = false;
      this.showStatus = false;
      this.complete = this.deployJobsData.status.complete;
    }
  }

  showLogStatus() {
    this.showStatus = !this.showStatus;
  }

  private subscribeToData(): void {
    this.timerSubscription = Observable.timer(5000).first().subscribe(() => this.refreshData());
  }

  getStatusLabel(statusId) {
    var label = this._workflowService.getStateLabel(this.deployJobsData.deploymentType, statusId);
    return label;
  };

  getLatestStatus(statusArr) {
    if (!statusArr || !statusArr.length) {
      return null;
    }
    //      return statusArr[statusArr.length-1];
    return statusArr[0];  // the 0 position has the latest status.
  };

  getStatusValue(status) {
    if (status.complete) {
      return '100%';
    }
    else {
      return status.progress + '%';
    }
  };

  getStatusMessage(status) {
    if (status.log) {
      return status.log[0];
    }
    else {
      return null;
    }
  }

  hasRetry = function (doc) {
    var status = this.getLatestStatus(doc.status).error;
    return status;
  };

  updateState() {
    var status = this.getLatestStatus(this.deployJobsData.status);
    var targetState = this._workflowService.getNextAction(this.deployJobsData.deploymentType, status);
    //console.log(targetState);
    this.subscribeToData();
    this._deployService.updateWlpState(this.deployJobsData._id, this.deployJobsData.deploymentType, targetState)
      .then(resp => {
        if (resp) {
          //console.log("Successful");
          this.currstate = this.getStatusLabel(targetState);
          //console.log(this.currstate);
        }
      })
      .catch(err => {
        console.log(err);
        this.refreshData();
        //this._dialogService.ok('Deployment Error!', '')
      });
  }

  onMoveToNextStage(event) {
    this._dialogService
      .confirm('Move to Next Stage', 'Are you sure you want to do this?')
      .subscribe(res => {
        if (res) {
          // OK to proceed
          //window.location.reload(true);
          //console.log(this.currstate);
          if (this.currstate === 'Ready For Build') {
            this.currstatus = '';
            this.currstate = 'Building';
            this.loading = true;
            this.inProgress = true;
            this.updateState();
          }
          else if (this.currstate === 'Building' && this.inProgress) {
            this._dialogService.ok(" Can't Move to Next Stage! Build in Progress!!", '');
            return;
          }
          else if (this.currstate === 'Ready For Patch') {
            this.currstatus = '';
            this.currstate = 'Patching';
            this.loading = true;
            this.inProgress = true;
            this.updateState();
          }
          else if (this.currstate === 'Patching' && this.inProgress) {
            this._dialogService.ok(" Can't Move to Next Stage! Patch in Progress!!", '');
            return;
          }
          else if (this.currstate === 'Ready For Rollback') {
            this.currstatus = '';
            this.currstate = 'Rollback';
            this.loading = true;
            this.inProgress = true;
            this.updateState();
          }
          else if (this.currstate === 'Rollback' && this.inProgress) {
            this._dialogService.ok(" Can't Move to Next Stage! Rollback in Progress!!", '');
            return;
          }
          else if (this.currstate === 'Ready For Uninstall') {
            this.currstatus = '';
            this.currstate = 'Uninstalling';
            this.loading = true;
            this.inProgress = true;
            this.updateState();
          }
          else if (this.currstate === 'Uninstalling' && this.inProgress) {
            this._dialogService.ok(" Can't Move to Next Stage! Uninstall in Progress!!", '');
            return;
          }
          else {
            this.updateState();
          }
        }
      });
  }

  deleteJob() {
    this._dialogService
      .confirm('Delete Job : ' + this.deployJobsData.cellId, "Are you sure you want to delete this deployment job?")
      .subscribe(res => {
        if (res) {
          this.dialogResult = res;
          //console.log("Deleting Job", this.dialogResult);
          this._workflowService.deleteDeployJob(this.deployJobsData._id)
            .then(this.handleDeleteSuccess.bind(this))
            .catch(this.handleDeleteError.bind(this));
        }
      })
  }

  handleDeleteSuccess() {
    //console.log("Successfully Deleted Job!");
    this.deleteEvent.emit(null);
  }

  handleDeleteError(error) {
    this._dialogService
      .ok('Error Deleting Job ' + this.deployJobsData.cellId, 'Error: ' + error)
      .subscribe(res => this.dialogResult = res);
  }

  onRetryClicked(event) {
    this._dialogService
      .confirm('Retry', 'Are you sure you want to Retry?')
      .subscribe(res => {
        if (res) {
          // OK to proceed
          var status = this.getLatestStatus(this.deployJobsData.status)
          var targetState = this._workflowService.getNextAction(this.deployJobsData.deploymentType, status);
          this._deployService.updateWlpState(this.deployJobsData._id, this.deployJobsData.deploymentType, targetState).then(resp => {
            //scope.refresh();
          }, function (err) {
            if (err.error !== 'ERR_NOT_AUTHORIZED') {
              // DialogService.showErrorDialog('Deployment Error.  Please Try Again Later');
            }
          });
        }
      });
  }
}
