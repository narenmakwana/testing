import {Router, ActivatedRoute, Params} from '@angular/router';
import {OnInit, Component, Input} from '@angular/core';
import { OrgService } from '../../../../../../shared/services/org.service';
import { ResponseResult } from '../../../../../../shared/models/response-result';
import { Subscription,  Observable } from "rxjs/Rx";
import { WasWorkflowService } from '../../../../../../shared/services/was-workflow.service';
import { LibertyWorkflowService } from '../../../../../../shared/services/liberty-workflow.service';
import {WasSearchResultItemComponent} from './was-search-result-item/was-search-result-item.component';
import {WlpSearchResultItemComponent} from './wlp-search-result-item/wlp-search-result-item.component';
import { HttpClient, HttpParams } from '@angular/common/http';
import {UditUtils} from '../../../../../../../core/uditUtils';
import { AdvSearchService } from '../../adv-search.service';

@Component({
  selector: 'c-jobs-search-results',
  templateUrl: './jobs-search-results.component.html',
  styleUrls: ['./jobs-search-results.component.scss'],
  viewProviders: [WasSearchResultItemComponent, WlpSearchResultItemComponent]
})
export class JobsSearchResultsComponent implements OnInit {

  responseResults: ResponseResult;
  private subscription: Subscription;
  cellName: string = ""; 
  buildState: string = "";
  tciCode: string = "";
  envType: string = "";
  searchText: string = "";
  product: string = "was";

  params: string[] = [];
  limit: number;
  offset: number = 0;
  trim: string = "";

  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected route: ActivatedRoute, protected _orgService: OrgService, protected _searchService: AdvSearchService,
              protected _wasWorkflow: WasWorkflowService, protected _wlpWorkflow: LibertyWorkflowService ) { 
       this.responseResults = new ResponseResult();
  }

  ngOnInit() { 
    // subscribe to router event
     this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.cellName = params['cellId'];
        this.product = params['product'];
        this.buildState = params['state'];
        this.tciCode = params['tci'];
        this.envType = params['env'];
        this.searchText = params['textSearch'];
        this.limit = +params['limit'];
    });

    this.getPage(1);

    this._wasWorkflow.discoverWorkflow();
    this._wlpWorkflow.discoverWorkflow();
  }

  showWas() : boolean {
     return this.product === "was";
  }

  showWlp() : boolean {
     return this.product === "wlp";
  }

  search(limit: number, page : number) {
    // calculate the offset based on page number and limit.
    var offset = (page - 1) * limit;
    var paramObj = {
      "cellId" : (this.cellName === "undefined")? "" : this.cellName,
      "cellId.startsWith" : (this.tciCode === "undefined") ? "" : this.tciCode,
      "cellId.contains" : (this.envType === "undefined") ? "" : this.envType,
      "textSearch" : (this.searchText === "undefined") ? "" : this.searchText,
      "status.0.state" : (this.buildState === "undefined") ? "" : this.buildState,
      "limit": limit,
      "offset" : offset
    };

    var paramString = UditUtils.buildQueryParams(paramObj);
    let httpParams = new HttpParams({
      fromString: paramString
    });

    if( this.product === "wlp")
       this._searchService.getWlpDeploymentJobs(httpParams)
                      .then((data)=>{
                        this.responseResults = data;
                        this.total = this.responseResults.total;
                        this.p = page;
                        this.loading = false;
                      });
    else
       this._searchService.getWasDeploymentJobs(httpParams)
                      .then((data)=>{
                        this.responseResults = data;
                        this.total = this.responseResults.total;
                        this.p = page;
                        this.loading = false;
                      });        

  }

  getPage(page: number) {
      this.loading = true;
      this.search(this.limit, page);
  }
}
