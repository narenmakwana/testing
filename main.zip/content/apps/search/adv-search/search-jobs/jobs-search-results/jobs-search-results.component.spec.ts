import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobsSearchResultsComponent } from './jobs-search-results.component';

describe('JobsSearchResultsComponent', () => {
  let component: JobsSearchResultsComponent;
  let fixture: ComponentFixture<JobsSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobsSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobsSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
