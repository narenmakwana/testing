import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasSearchResultItemComponent } from './was-search-result-item.component';

describe('WasSearchResultItemComponent', () => {
  let component: WasSearchResultItemComponent;
  let fixture: ComponentFixture<WasSearchResultItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasSearchResultItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasSearchResultItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
