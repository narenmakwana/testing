import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { WasWorkflowService } from '../../../../../../../shared/services/was-workflow.service';
import { DeployService } from '../../../../../../../shared/services/deploy.service';
import { DialogService } from '../../../../../../../shared/services/dialog.service';
import { Subscription, Observable, BehaviorSubject } from "rxjs/Rx";
import { AnonymousSubscription } from "rxjs/Subscription";
import { AuthenticationService } from '../../../../../../pages/authentication/authentication.service';

@Component({
  selector: 'c-was-search-result-item',
  templateUrl: './was-search-result-item.component.html',
  styleUrls: ['./was-search-result-item.component.scss']
})
export class WasSearchResultItemComponent implements OnInit {

  @Input() deployJobsData: any;
  @Output() deleteEvent = new EventEmitter();


  public dialogResult: any;
  private timerSubscription: AnonymousSubscription;
  cellSelected: boolean = false;
  currstatus: string;
  currstate: string;
  log: Array<any> = [];
  isAdmin: boolean = false;
  loading: boolean = false;
  inProgress: boolean = false;
  failed: boolean = false;
  complete: boolean = false;
  checkingStatus: boolean = false;
  connected: boolean = false;
  hosts: Array<any> = [];

  constructor(protected _router: Router, protected _route: ActivatedRoute, protected _workflowService: WasWorkflowService,
    protected _deployService: DeployService, private _dialogService: DialogService, private authService: AuthenticationService) {

  }

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    this.displayJobStatus();
    this.refreshData();
  }

  ngOnDestroy(): void {
    if (typeof this.timerSubscription !== 'undefined') {
      this.timerSubscription.unsubscribe();
    }
  }

  private refreshData(): void {
    //console.log("inside refresh data for " + this.deployJobsData.cellId);
    if (this.inProgress) {
      this.checkingStatus = true;
      this._workflowService.getDeploymentStatus(this.deployJobsData._id)
        .subscribe(
          data => {
            this.deployJobsData.status = data['status'];
            this.displayJobStatus();
            //this.subscribeToData();
          },
          err => {
            console.log(err);
          })
    }
    else {
      this._workflowService.getDeploymentStatus(this.deployJobsData._id)
        .subscribe(
          data => {
            this.deployJobsData.status = data['status'];
            this.displayJobStatus();
            ///console.log(this.currstate);
          },
          err => {
            console.log(err);
          })

    }
  }

  displayJobStatus() {
    var status = this.deployJobsData.status;
    this.currstate = this.getStatusLabel(status.state);
    this.currstatus = this.getStatusValue(status);
    this.log = this.getStatusMessage(status);
    if(this.deployJobsData.nodeTemplates){
      this.hosts = [...Array.from(new Set(this.deployJobsData.nodeTemplates.map(item => item.host)))];
      if (typeof this.hosts[0] === 'undefined') {
        this.hosts = [...Array.from(new Set(this.deployJobsData.nodeTemplates.map(item => item.hostName)))];
      }
    }

    this.checkingStatus = false;

    if (this.currstatus !== '100%') {
      this.inProgress = true;
      this.loading = true;
      if (this.deployJobsData.status.error === true) {
        this.failed = true;
        this.inProgress = false;
        this.loading = false;
      }
    }
    else {
      this.inProgress = false;
      this.loading = false;
      this.complete = this.deployJobsData.status.complete;
    }
  }

  private subscribeToData(): void {
    this.timerSubscription = Observable.timer(10000).first().subscribe(() => this.refreshData());
  }

  getStatusLabel = function (statusId) {
    var label = this._workflowService.getStateLabel(this.deployJobsData.deploymentType, statusId);
    return label;
  };

  getStatusValue(status) {
    if (status.complete) {
      return '100%';
    }
    else {
      return status.progress + '%';
    }
  };

  getStatusMessage(status) {
    if (status.log) {
      return status.log;
    }
    else {
      return null;
    }
  }

  hasRetry = function (doc) {
    var status = this.deployJobsData.status.error;
    return status;
  };

  updateState() {
    var status = this.deployJobsData.status;
    var targetState = this._workflowService.getNextAction(this.deployJobsData.deploymentType, status);
    this.subscribeToData();
    this._deployService.updateWasState(this.deployJobsData._id, this.deployJobsData.deploymentType, targetState)
      .then(resp => {
        if (resp) {
          this.currstate = this.getStatusLabel(targetState);
        }
      })
      .catch(err => {
        console.log(err);
        //this._dialogService.ok('Deployment Error!', err.toString());
      });
  }


  onMoveToNextStage(event) {
    this._dialogService
      .confirm('Move to Next Stage', 'Are you sure you want to do this?')
      .subscribe(res => {
        if (res) {
          // OK to proceed
          if (this.currstate === 'Ready For Build') {
            this.currstatus = '';
            this.currstate = 'Building';
            this.loading = true;
            this.inProgress = true;
            this.checkingStatus = true;
            this.updateState();
          }
          else if (this.currstate === 'Ready For Patch') {
            this.currstatus = '';
            this.currstate = 'Patching';
            this.loading = true;
            this.inProgress = true;
            this.checkingStatus = true;
            this.updateState();
          }
          else if (this.currstate === 'Ready For Rollback') {
            this.currstatus = '';
            this.currstate = 'Rollback';
            this.loading = true;
            this.inProgress = true;
            this.checkingStatus = true;
            this.updateState();
          }
          else if (this.currstate === 'Ready For Uninstall') {
            this.currstatus = '';
            this.currstate = 'Uninstalling';
            this.loading = true;
            this.inProgress = true;
            this.checkingStatus = true;
            this.updateState();
          }
          else {
            this.updateState();
          }
        }
      });
  }


  deleteJob() {
    this._dialogService
      .confirm('Delete Job : ' + this.deployJobsData.cellId, "Are you sure you want to delete this deployment job?")
      .subscribe(res => {
        if (res) {
          this.dialogResult = res;
          //console.log("Deleting Job", this.dialogResult);
          this._workflowService.deleteDeployJob(this.deployJobsData._id)
            .then(this.handleDeleteSuccess.bind(this))
            .catch(this.handleDeleteError.bind(this));
        }
      })
  }


  handleDeleteSuccess() {
    console.log("Successfully Deleted Job!");
    this.deleteEvent.emit(null);
  }

  handleDeleteError(error) {
    this._dialogService
      .ok('Error Deleting Job ' + this.deployJobsData.cellId, 'Error: ' + JSON.stringify(error))
      .subscribe(res => this.dialogResult = res);
  }

  onRetryClicked(event) {
    this._dialogService
      .confirm('Retry', 'Are you sure you want to Retry?')
      .subscribe(res => {
        if (res) {
          this.failed = false;
          this.inProgress = true;
          this.log = [];
          this.currstatus = '';
          this.loading = true;
          this.checkingStatus = true;
          this.updateState();
        }
      });
  }
}
