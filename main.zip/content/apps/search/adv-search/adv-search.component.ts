import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adv-search',
  templateUrl: './adv-search.component.html',
  styleUrls: ['./adv-search.component.scss']
})
export class AdvSearchComponent implements OnInit {

  searchForm: FormGroup;

  searchProduct: string = "was";
  searchCollection:string = "inv";
  showServers: boolean = false;

  showTags: boolean = true;
  showText: boolean = true;
  showBuildStates: boolean = false;

  constructor(
      private formBuilder: FormBuilder,
      private router: Router
    ) 
  { 

  }

  ngOnInit() {
        this.searchForm = this.formBuilder.group({
          searchProduct   : ['was'],
          searchCollection: ['inv'],
          cellName      : [''],
          hostName      : [''],
          tciCodes      : [''],
          envTypes      : [''],
          buildStates   : [''],
          searchText    : [''],
          searchTags    : [''],
          project_name  : [''],
          pmt_num       : [''],
          rc_num        : [''],
          searchHosts   : [''],
          searchOs      : [''],
          searchIp      : ['']
      });
  }

  selectProduct(_product: string) {
    this.searchProduct = _product;
    if (_product === "servers")
        this.showServers = true;
    else
        this.showServers = false;
  } 

  selectCollection(_searchCollection: string) {
    this.searchCollection = _searchCollection;
    if( _searchCollection === 'inv') {
        this.showTags = true;
        this.showText = true;
        this.showBuildStates = false;
    }
    else {
        this.showTags = false;
        this.showText = false;    
        if( _searchCollection === 'deployment')   
           this.showBuildStates = true;
        else
           this.showBuildStates = false;
    }
  }

  // Inventory Searches
  searchWasInventory() {
    this.router.navigate(['apps/search/inv-search-results', 
             { cellId: this.searchForm.controls['cellName'].value, 
               host : this.searchForm.controls['hostName'].value, 
               tci: this.searchForm.controls['tciCodes'].value,
               envtype: this.searchForm.controls['envTypes'].value,
               textSearch: this.searchForm.controls['searchText'].value,
               tag:  this.searchForm.controls['searchTags'].value,
               limit: 20,
               fields: "-globalSecurity,-nodes.servers"
             }]);
  }

  searchLibertyInventory() {
     this.router.navigate(['apps/search/liberty-search-results', 
              { cellName: this.searchForm.controls['cellName'].value, 
                hostName : this.searchForm.controls['hostName'].value, 
                tci: this.searchForm.controls['tciCodes'].value,
                envtype: this.searchForm.controls['envTypes'].value,
                textSearch: this.searchForm.controls['searchText'].value,
                tag: this.searchForm.controls['searchTags'].value,
                limit: 20
              }]);
  }

  searchServersInventory() {
    this.router.navigate(['apps/search/servers-search-results', 
             { hostname: this.searchForm.controls['searchHosts'].value,
               os: this.searchForm.controls['searchOs'].value,
               ipaddress: this.searchForm.controls['searchIp'].value,
               limit: 20
             }]);
  }

  searchWasDesigns() {
    this.router.navigate(['apps/design/wasnd/list', 
             { cellId: this.searchForm.controls['cellName'].value, 
               host : this.searchForm.controls['hostName'].value, 
               tci: this.searchForm.controls['tciCodes'].value,
               envtype: this.searchForm.controls['envTypes'].value,
               limit: 20
             }]);
  }

  searchLibertyDesigns() {
    this.router.navigate(['apps/design/liberty/list', 
             { cellId: this.searchForm.controls['cellName'].value, 
               host : this.searchForm.controls['hostName'].value, 
               tci: this.searchForm.controls['tciCodes'].value,
               envtype: this.searchForm.controls['envTypes'].value,
               limit: 20
             }]);
  }

  searchServerDesigns() {
    this.router.navigate(['apps/design/linux-list', 
           { project_name : this.searchForm.controls['project_name'].value, 
             pmt_num: this.searchForm.controls['pmt_num'].value,
             rc_num: this.searchForm.controls['rc_num'].value,
             limit: 20
           }]);
  } 

  searchWasDeployments() {
    this.router.navigate(['apps/search/jobs-search-results', 
             { cellId: this.searchForm.controls['cellName'].value, 
               product: 'was',
               tci: this.searchForm.controls['tciCodes'].value,
               env: this.searchForm.controls['envTypes'].value,
               textSearch: this.searchForm.controls['searchText'].value,
               state: this.searchForm.controls['buildStates'].value,
               limit: 20
             }]);     
  }

 searchLibertyDeployments() {
   this.router.navigate(['apps/search/jobs-search-results', 
            { cellId: this.searchForm.controls['cellName'].value, 
              product: 'wlp',
              tci: this.searchForm.controls['tciCodes'].value,
              env: this.searchForm.controls['envTypes'].value,
              textSearch: this.searchForm.controls['searchText'].value,
              state: this.searchForm.controls['buildStates'].value,
              limit: 20
            }]);     
  }

  searchServerDeployments() {
    this.router.navigate(['apps/search/linux-jobs-search-results', 
             { project_name: this.searchForm.controls['project_name'].value, 
               product: 'linux',
               pmt_num: this.searchForm.controls['pmt_num'].value,
               rc_num: this.searchForm.controls['rc_num'].value,
               textSearch: this.searchForm.controls['searchText'].value,
               state: this.searchForm.controls['buildStates'].value,
               limit: 20
             }]);     
  }

  search() {
    switch(this.searchCollection) {
      case 'inv': {
        if( this.searchProduct === 'liberty')
            this.searchLibertyInventory();
        else
        if(this.searchProduct === 'servers')
            this.searchServersInventory();
        else
            this.searchWasInventory();
        break;
      }
      case 'design': {
        if( this.searchProduct === 'liberty')
            this.searchLibertyDesigns();
        else
        if(this.searchProduct === 'servers')
            this.searchServerDesigns();
        else
            this.searchWasDesigns();
        break;
      }
      case 'deployment': {
        if( this.searchProduct === 'liberty')
            this.searchLibertyDeployments();
        else
        if(this.searchProduct === 'servers')
            this.searchServerDeployments();
        else
            this.searchWasDeployments();
        break;
      }

      default: {
        console.log("Invalid");
      }
    }
  } // Search

}
