import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasNdSummaryComponent } from './was-nd-summary.component';

describe('WasNdSummaryComponent', () => {
  let component: WasNdSummaryComponent;
  let fixture: ComponentFixture<WasNdSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasNdSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasNdSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
