import { Component, AfterViewInit, OnInit, Input } from '@angular/core';
import {JvmTemplate} from '../../../../../shared/models/jvm-template';
import {Constants} from '../../../../../shared/config/constants';
import {WasCell} from '../../../../../shared/models/was-cell';
import {WasNdService} from '../was-nd.service';

@Component({
  selector: 'c-was-nd-summary',
  templateUrl: './was-nd-summary.component.html',
  styleUrls: ['./was-nd-summary.component.scss']
})
export class WasNdSummaryComponent implements OnInit, AfterViewInit {

  @Input() _wasCell : WasCell;
  showJvmMenu: boolean = false;

  constructor( private _wasNdService: WasNdService ) { 
     this._wasCell = _wasNdService.wasCell;
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

  onShowJvmMenu() : boolean {
    // toggle showMenu
     this.showJvmMenu = !this.showJvmMenu;
     return this.showJvmMenu;
  }

  startJvm(event) {

  }

  stopJvm(event){

  }
 

}
