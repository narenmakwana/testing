import { NgModule, Host } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { WasNdIhsComponent } from './was-nd-ihs/was-nd-ihs.component';
import { WasNdJvmComponent } from './was-nd-jvm/was-nd-jvm.component';
import { WasNdListComponent } from './was-nd-list/was-nd-list.component';
import { WasNdNodeComponent } from './was-nd-node/was-nd-node.component';
import { WasNdSummaryComponent } from './was-nd-summary/was-nd-summary.component';
import { WasNdListItemComponent } from './was-nd-list/was-nd-list-item/was-nd-list-item.component';
import { WasNdComponent } from './was-nd.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { WasNdService } from './was-nd.service';
import { PackagesService } from '../../../../shared/services/packages.service';
import { OptionsService } from '../../../../shared/services/options.service';
import { CellParseService } from '../../../../shared/services/cell-parse.service';
import { DataFormatService } from '../../../../shared/services/data-format.service';
import { OrgService } from '../../../../shared/services/org.service';
import { TagsService } from '../../../../shared/services/tags.service';
import { DialogService } from '../../../../shared/services/dialog.service';

const routes: Routes = [
  {
      path     : 'design/wasnd/list',
      component: WasNdListComponent
  },
  {
      path     : 'design/wasnd',
      component: WasNdComponent
  },
  {
      path     : 'design/wasnd/:id',
      component: WasNdComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    NgxPaginationModule,
    RouterModule.forChild(routes)
  ],
  declarations: [WasNdIhsComponent, WasNdJvmComponent, WasNdListComponent, WasNdNodeComponent, 
    WasNdSummaryComponent, WasNdListItemComponent, WasNdComponent],
  providers: [WasNdService, PackagesService, OptionsService, CellParseService, DataFormatService,
             OrgService, TagsService, DialogService
            ]
})
export class WasNdModule { }
