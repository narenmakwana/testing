import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import {NgForm} from '@angular/forms';
import {WasNodeTemplate} from '../../../../../shared/models/was-node-template';
import {WasCell} from '../../../../../shared/models/was-cell';
import {Constants} from '../../../../../shared/config/constants';
import {WasNdIhsComponent} from '../was-nd-ihs/was-nd-ihs.component';
import {WasIhsTemplate} from '../../../../../shared/models/was-ihs-template';
import {WasJvmTemplate} from '../../../../../shared/models/was-jvm-template';
import {WasNdService} from '../was-nd.service';
import { DialogService } from '../../../../../shared/services/dialog.service';


@Component({
  selector: 'c-was-nd-node',
  templateUrl: './was-nd-node.component.html',
  styleUrls: ['./was-nd-node.component.scss']
})

export class WasNdNodeComponent implements OnInit, AfterViewInit {

  wasNodeTemplate: WasNodeTemplate;
  @Output()
  _wasCell : WasCell;
  public dialogResult : any;

  @Input() wasNdCellData : WasCell;

  showDmgrNode : boolean = false;

  @Input() nodeIndex: number = 0;
  @Output() currWasNode: number = 0;
  @Output() jvmChanged = new EventEmitter();
  @Output() hasChanged = new EventEmitter();

  constructor( private _wasNdService: WasNdService, private _dialogService: DialogService ) { 
     this.wasNodeTemplate = new WasNodeTemplate();       
  }

  ngOnInit(){
     this._wasCell = this._wasNdService.wasCell;
     this.wasNodeTemplate = this._wasCell.getNode(this.nodeIndex);
     this.currWasNode = this.nodeIndex;
  }

  ngAfterViewInit() {
  }

  showDmgr() : boolean {
     this.showDmgrNode = true;
     return this.showDmgrNode;
  }

  isWasBase(){
      if(this._wasCell.installType === "WAS_BASE")
         return true;
      else
         return false;
  }

  onDmgrSelection(dmgrSelected : boolean) {
      if(dmgrSelected) {
           this._wasCell.dmgrNode = this.wasNodeTemplate.hostName;
      }
  }

  showRemoveJvm(currIndex: number) : boolean {
      if (currIndex >= 0) {
         if(this.wasNodeTemplate.numJvms > 0)
            return true;
          else
            return false;
      }
      else{
          return false;
      }
  }

  showRemoveIhs(currIndex: number) : boolean {
      if (currIndex >= 0) {
         if(this.wasNodeTemplate.numHttpServers > 0)
            return true;
          else
            return false;
      }
      else{
          return false;
      }
  }


  addNewJvm() {
      // First check to see if there are no duplicate port numbers on this host.
      var portBlocks = this.wasNodeTemplate.findDuplicateJvmPorts();
      if(portBlocks.length > 0 ) {
           // Duplicates found.
           this._dialogService
            .ok('Error Adding JVM', "Duplicate PORT BLOCKS Found on the SAME HOST :" + portBlocks)
                .subscribe();     
      }
      else {
        if((this._wasCell.installType === "WAS_BASE") && this.wasNodeTemplate.numJvms > 0) {
            this._dialogService
                .ok('Error Adding JVM', "Cannot Add more than ONE JVM for WAS_BASE")
                    .subscribe();          
        }
        else
        {
            let newJvm = this.wasNodeTemplate.addJvm(this.wasNdCellData, this._wasCell.installType);
            this.currWasNode = this.nodeIndex;
            this.jvmChanged.emit(newJvm);          
        }
     }
  }

  removeJvm(currIndex) {
      this.currWasNode = this.nodeIndex;
      this.wasNodeTemplate.removeJvm(this.wasNdCellData, currIndex);
  }

  addIhs() {
      var portBlocks = this.wasNodeTemplate.findDuplicateIhsPorts();
      if(portBlocks.length > 0 ) {
           // Duplicates found.
           this._dialogService
            .ok('Error Adding IHS', "Duplicate PORT BLOCKS Found on the SAME HOST :" + portBlocks)
                .subscribe();     
      }
      else {
        let newJvm = this.wasNodeTemplate.addIhs(this.wasNdCellData);
        this.currWasNode = this.nodeIndex;
      }
  }

  removeIhs(currIndex) {
      this.currWasNode = this.nodeIndex;
      this.wasNodeTemplate.removeIhs(this.wasNdCellData, currIndex);
  }

  ihsChanged(_ihsTemplate: WasIhsTemplate, _selectedIHS: number): void {
     this.wasNodeTemplate.ihsTemplates[_selectedIHS] = _ihsTemplate;
     this.wasNodeTemplate.setIhs(this.wasNdCellData, _selectedIHS, _ihsTemplate);
  }

  OnJvmChange(_jvmTemplate: WasJvmTemplate, _selectedJVM: number): void {
     this.wasNodeTemplate.jvmTemplates[_selectedJVM] = _jvmTemplate;
     this.wasNodeTemplate.setJvm(this.wasNdCellData, _selectedJVM, _jvmTemplate);
     this.currWasNode = this.nodeIndex;
  }

  onChange(nodename: string) {
     if( this.validateTemplate() ) {
        this.hasChanged.emit(this.wasNodeTemplate);
        this.currWasNode = this.nodeIndex;
     }
  }

  onHostChange(hostname: string) {
      if(!(this._wasCell.installType === "WAS_BASE"))
        this.showDmgr();
      if(this.wasNodeTemplate.hasDmgr)
        this._wasCell.dmgrNode = hostname;
  }

  validateTemplate() : boolean {
    if( this.wasNodeTemplate.hostName.length === Constants.MAX_HOSTNAME_LEN) {
      return true;      
    }
    console.log('returned false');
    return false;
  }

}
