import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasNdNodeComponent } from './was-nd-node.component';

describe('WasNdNodeComponent', () => {
  let component: WasNdNodeComponent;
  let fixture: ComponentFixture<WasNdNodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasNdNodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasNdNodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
