import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {Observable} from 'rxjs';
import {WasCell} from '../../../../shared/models/was-cell';
import {ResponseResult} from '../../../../shared/models/response-result';
import {PackagesService} from '../../../../shared/services/packages.service';
import {OptionsService} from '../../../../shared/services/options.service';
import {Subject, BehaviorSubject} from 'rxjs';
import {Constants} from '../../../../shared/config/constants';
import { UditUtils } from '../../../../../core/uditUtils';
import { TokenService } from '../../../pages/authentication/token.service';


export class WasVersions {
  constructor(
    public _id: string,
    public version: string) {}
}

@Injectable()
export class WasNdService{

  _wasCell: WasCell;
  _responseResults: ResponseResult;
  _wasPackages: any;
  _wasVersions: any;
  _fixPacks: any;
  userData: any;

  constructor(private http: HttpClient, protected _packageService: PackagesService, 
              protected _optionsService: OptionsService, private tokenService: TokenService ) {

  }

  get wasCell() : WasCell {
     return this._wasCell;
  }

  setWasCell( wasCell: WasCell ): void {
     this._wasCell = wasCell;
  }

  createWasCell(): WasCell {
     this._wasCell = new WasCell();
     return this._wasCell;
  }

  loadFixpacks = function(version){
       return this._optionsService.queryWasFixPacks(this._wasPackages, Constants.INSTALL_TYPES.ND.value, version).then(function(results){
        this._fixpacks = results;
      }.bind(this));
  };

  
  loadWasVersions = function(){
    return this._optionsService.queryWasVersions(null, Constants.INSTALL_TYPES.ND.value)
              .then((results) => {
        this._wasCell.setWasVersions(results.reverse(), true);
    });
  }

  loadPortalVersions = function(){
    return this._optionsService.queryWasVersions(null, Constants.INSTALL_TYPES.PORTAL.value).then(function(results) {
        this.portalVersions = results;
    }.bind(this));
  }
  
  loadPortalFixpacks = function(version){
    return this._optionsService.queryWasFixPacks(null, Constants.INSTALL_TYPES.PORTAL.value, version).then(function(results){
      this.portalFixpacks = results;
    }.bind(this));
  }

  getWasNdVersions() {
    return this._optionsService.queryWasVersions(null, Constants.INSTALL_TYPES.ND.value);
  }

 createWasCellFromExisting(cell: any): WasCell {
     this._wasCell = new WasCell(cell);
     return this._wasCell;
 }

 public getWasCell( cellname: string ) : Promise<any> {
  return new Promise((resolve, reject) => {
    const httpParams = new HttpParams().set('cellname', cellname);
    this.http.get(Constants.getWasDesignUrl(), { params: httpParams})
                .toPromise()
                .then(this.getCellDetails)
                .catch(this.handleError);
  });
  
 }

  getCellDetails (_response: Response) : any {
     let body = _response;
     return body || { };
  }


  getWasDesigns( httpParams ) : Promise<any> {
      return this.http.get(Constants.getWasDesignUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.wasDesignSearchResults)
                    .catch(this.handleError);
  }

  wasDesignSearchResults (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  public getWasCellById( id: string) : Promise<any> {
      return this.http.get(Constants.getWasDesignUrl() + "/" + id) 
                    .toPromise()
                    .then(this.getCellDetails)
                    .catch(this.handleError);
  }

  getInvCellDetails (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  public getWasInvCellByCellId( cellId: string) : Promise<any> {
      const httpParams = new HttpParams().set('cellId', cellId);
      return this.http.get(Constants.getWasInventoryUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.getInvCellDetails)
                    .catch(this.handleError);
  }

  public getWasDesignCellByCellId( cellId: string) : Promise<any> {
      const httpParams = new HttpParams().set('cellId', cellId);
      return this.http.get(Constants.getWasDesignUrl(), { params: httpParams}) 
                    .toPromise()
                    .then(this.getDesignCellDetails)
                    .catch(this.handleError);
  }

  getDesignCellDetails (_response: Response) : any {
     let body = _response;
     return body || { };
  }


 public runPreCheck(wasCell: WasCell): Promise<any> {
    // First check to see if this cell already exists.  

    var  userName = this.tokenService.getUserId();
    var  cellName = wasCell.cellname;
    var hosts = [];
    wasCell.nodeTemplates.forEach(function (node) {
      if (node.hostName) {
        hosts.push(node.hostName)
      }
      

    });

      var jsonBody = {
        "data": 
        {
        "username": userName,
        "cellId": cellName,
        "hostNames": hosts
        }
      };
  
      
    
      return this.http.post(Constants.getpreCheckUrl(), jsonBody)
        .toPromise()
        .then(this.saveCellDetails)
        .catch(this.handleError);
    
  }

  public saveWasCell(wasCell: WasCell): Promise<any> {
    // This is a new cell we are saving. Since this is new cell
    // we want to make sure that we don't pass the _id and __v to mongo.
    //      delete this.Cell.__v;
    //      delete this.wasCell._id;
    // First check to see if this cell already exists.  
    var id = wasCell._id;
    delete wasCell._id;
    var status = {
      userName: this.tokenService.getUserId(),
      date: new Date()
    }
    if (wasCell.status)
      wasCell.status.push(status);
    else {
      wasCell.status = [];
      wasCell.status.push(status);
    }
    if (id) {
      return this.http.put(Constants.getWasDesignUrl() + "/" + id, wasCell)
        .toPromise()
        .then(this.saveCellDetails)
        .catch(this.handleError);
    }
    else {
      return this.http.post(Constants.getWasDesignUrl(), wasCell)
        .toPromise()
        .then(this.saveCellDetails)
        .catch(this.handleError);
    }
  }

  saveCellDetails (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 


}
