import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasNdIhsComponent } from './was-nd-ihs.component';

describe('WasNdIhsComponent', () => {
  let component: WasNdIhsComponent;
  let fixture: ComponentFixture<WasNdIhsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasNdIhsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasNdIhsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
