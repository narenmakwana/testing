import { Component, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { WasIhsTemplate } from '../../../../../shared/models/was-ihs-template';
import { Constants } from '../../../../../shared/config/constants';
import { WasCell } from '../../../../../shared/models/was-cell';
import { WasNdService } from '../was-nd.service';
import { WasNodeTemplate } from '../../../../../shared/models/was-node-template';
import { DialogService } from '../../../../../shared/services/dialog.service';

@Component({
  selector: 'c-was-nd-ihs',
  templateUrl: './was-nd-ihs.component.html',
  styleUrls: ['./was-nd-ihs.component.scss']
})
export class WasNdIhsComponent implements AfterViewInit {

  @Input() ihsIndex: number = 0;
  @Input() currWasNode: number = 0;
  @Output() hasChanged = new EventEmitter();

  private _wasCell: WasCell;
  ihsTemplate: WasIhsTemplate;
  wasNodeTemplate: WasNodeTemplate;
  public ihsresult: any;

  constructor(private _wasNdService: WasNdService, private dialogService: DialogService) {
    this.ihsTemplate = new WasIhsTemplate();
  }

  ngOnInit() {
    this._wasCell = this._wasNdService.wasCell;
    this.wasNodeTemplate = this._wasCell.getNode(this.currWasNode);
    this.ihsTemplate = this.wasNodeTemplate.getIhs(this.ihsIndex);
  }

  // Check for any duplicate IHS Names.
  ihsUpdated(event: any) {

    let dups = this._wasCell.findDuplicateIhsNames();
    if (dups) {
      if (dups.length > 0)
        this.dialogService
          .ok('Duplicate IHS Names Found.', dups[0])
          .subscribe(res => this.ihsresult = res);
    }
  }

  ngAfterViewInit() {
  }

  onChange() {
    if (this.validateTemplate())
      this.hasChanged.emit(this.ihsTemplate);
  }

  validateTemplate(): boolean {
    return true;
  }

}
