import { Component, OnInit, Output, AfterViewInit, AfterViewChecked, OnDestroy, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { MatSlideToggle } from '@angular/material';
import { MatSlider } from '@angular/material';
import { WasNodeTemplate } from '../../../../shared/models/was-node-template';
import { WasCell } from '../../../../shared/models/was-cell';
import { WasNdService } from './was-nd.service';
import { OptionsService } from '../../../../shared/services/options.service';
import { WasNdSummaryComponent } from './was-nd-summary/was-nd-summary.component';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialogRef, MatDialog } from '@angular/material';
import { InputDialog } from '../../../../shared/components/input-dialog.component';
import { DialogService } from '../../../../shared/services/dialog.service';

@Component({
  selector: 'c-was-nd',
  templateUrl: './was-nd.component.html',
  styleUrls: ['./was-nd.component.scss']
})

export class WasNdComponent implements OnInit, AfterViewInit, OnDestroy {

  public _selectedIndex: number = 0;
  @Output()
  _wasCell: WasCell;

  @Output() nodeIndex: number = 0;
  @Output() ID: string;
  @Output()
  change: EventEmitter<WasCell> = new EventEmitter<WasCell>();

  public result: any;

  separate

  productOptions = [
    { value: 'WAS_ND', viewValue: 'WebSphere ND' },
    { value: 'WAS_BASE', viewValue: 'WebSphere BASE' },
    { value: 'WAS_PORTAL', viewValue: 'WebSphere Portal' }
  ];

  showClusters: boolean = true;

  javaVersionOptions: string[] = ["6.0", "7.0", "7.1", "8.0_64"]

  tciCodes: string[] = [];

  private _results: { success: boolean, data?: { inputField: string } } = { success: false };
  private _dialogRef: MatDialogRef<InputDialog>;

  constructor(protected _router: Router, private _activeRoute: ActivatedRoute,
    private _wasNdService: WasNdService,
    private _optionsService: OptionsService, private _dialog: MatDialog, private dialogService: DialogService) {
    this._wasCell = _wasNdService.createWasCell();
  }

  // Subscribe to the change in the route parameters. We want to know if the route contains the ID of the cell.
  ngOnInit() {
    this._activeRoute.params.subscribe(this.onParamChange.bind(this));
  }

  // Cleanup Stuff here.
  ngOnDestroy() {
  }

  // Edit Cell Being Handled here. We need to load the existing 
  // Cell data here. The data coming from database does not have everything
  // which is needed by the object to be initialized. So we need to instantiate
  // a new object.
  handleSuccess(_wasNdCell: any) {
    this.ID = _wasNdCell._id;
    console.log('Found ID = ', this.ID);
    this._wasCell = this._wasNdService.createWasCellFromExisting(_wasNdCell);
  }

  handleError(error) {
    console.log("Got Error in Getting WasCell Data")
  }

  // We got here when a user selected a cell to be edited. So we get the cell details
  // from the database and then initiaze the models with this data.
  onParamChange(params: any) {
    if (params['id']) {
      // Retrieve the document here.
      this._wasNdService.getWasCellById(params['id']).catch(this.handleError.bind(this))
        .then(this.handleSuccess.bind(this));
    }
  }

  addCluster() {
    this._dialogRef = this._dialog.open(InputDialog, {
      disableClose: true
    });
    this._dialogRef.componentInstance.inputField = this._results.data ? this._results.data.inputField : '';
    this._dialogRef.componentInstance.title = "Add Cluster";
    this._dialogRef.componentInstance.message = "Please Enter a Cluster Name";
    this._dialogRef.componentInstance.placeHolderText = "Cluster Name";
    this._dialogRef.componentInstance.inputField = this._wasCell.buildClusterName();
    this._dialogRef.afterClosed().subscribe(result => {
      this._results = result;
      if (result.data) {
        this._wasCell.clusterNames.push(result.data.inputField);
      }
      this._dialogRef = null;
    });
  }

  removeCluster(selectedNode: number): void {
    if (selectedNode < this._wasCell.clusterNames.length) {
      this._wasCell.clusterNames.splice(selectedNode, 1);
    }
  }

  get results(): string {
    return JSON.stringify(this._results, null, '\t');
  }

  ngAfterViewInit() {
    console.log('Cell Name', this._wasCell.cellname);
    // Initialize the was versions and fixpacks
    this._wasNdService.loadWasVersions();
  }

  ngAfterViewChecked() {
  }

  get selectedIndex(): number {
    return this._selectedIndex;
  }

  set selectedIndex(selectedIndex: number) {
    this._selectedIndex = selectedIndex;
  }

  changeStandards($event) {
    this._wasCell.processChangeStandards();
  }

  getTciCodes(event: any) {
    var val = this._wasCell.tciCode + event.key;
    this._optionsService.queryTciCodes(val)
      .then(resp => {
        this.tciCodes = resp;
      });
  }

  showRemoveNode(currIndex: number): boolean {
    if (currIndex >= 1) {
      return true;
    }
    else {
      return false;
    }
  }

  validate(): boolean {
    var isValid = false;
    if (this._wasCell) {
      // Check if the cellname already exists in our inventory.
      this._wasNdService.getWasInvCellByCellId(this._wasCell.cellname).then(this.cellFound);
    }
    return isValid;
  }

  cellFound(cell) {
    console.log("Found Cell..");
  }

  validateProjectInfo(): boolean {
    // Check to see if no duplicate cluster names allowed.
    var valid = false;
    var clusNames = this._wasCell.findDuplicateClusterNames();
    if (clusNames.length > 0) {
      // Found Duplicate Cluster Names. Display them.
      valid = false;
    }
    else
      valid = true;
    if (valid)
      valid = this._wasCell.isValidTCI();
    return valid;
  }

  validateClusterNames(): boolean {
    let valid = true;


    return valid;
  }

  canMove(index: number): boolean {
    switch (index) {
      case 0:
        return true;
      case 1:
        return this.validateProjectInfo();
      case 2:
        return this.canMove(1);
      default:
        return true;
    }
  }

  next(): void {

    if (this.selectedIndex === 1) {
      let jvmNames = this._wasCell.findJvmsWithNoClusters();
      if (jvmNames.length > 0) {
        let message = "We noticed that you have the following JVMs which are NOT assigned to any cluster.<br>";
        jvmNames.forEach(jvm => {
          message += "<p><strong>" + jvm + "</strong></p>"
        });
        message += "<p>Please ensure that this is the desired design!</p>"
        this.dialogService
          .ok("Warning: Found JVMs Which are NOT Assigned to Any Clusters.", message)
          .subscribe(res => this.result = res);
      }
    }

    if (this.canMove(this.selectedIndex + 1)) {
      this.selectedIndex++;
      this.change.emit(this._wasCell);  //notify everyone.
    }
  }

  previous(): void {
    if (this.canMove(this.selectedIndex - 1)) {
      this.selectedIndex--;
      this.change.emit(this._wasCell);  //notify everyone.
    }
  }

  handleSaveError(error: string) {
    console.log("Error Encountered..", error);
  }

  wasProductChanged(_wasProduct: string) {
    // Extract the Product
    console.log("Product =", _wasProduct);
    this._wasCell.installType = _wasProduct;
    if (this._wasCell.installType === "WAS_BASE")
      this.showClusters = false;
    else
      this.showClusters = true;
  }

  handleSaveSuccess() {
    console.log("Success..");
    this._router.navigate(['apps/design/wasnd/list',
      {
        cellId: this._wasNdService._wasCell.cellname,
        limit: 20
      }]);
  }


  finish(): void {
    this._wasCell.validate();
    console.log("Saving Was Cell.");
    this._wasNdService.saveWasCell(this._wasCell).catch(this.handleSaveError.bind(this))
      .then(this.handleSaveSuccess.bind(this));
  }

  nodesChanged(_node: WasNodeTemplate, _selectedNode: number): void {
    // Save each node in the correct index.
    console.log("Was ND Component Nodes Changed Called.", _node.nodeName, " Index=", _selectedNode);
    this._wasCell.setNode(_selectedNode, _node);
  }

  submit(form: NgForm): void {
  }

}
