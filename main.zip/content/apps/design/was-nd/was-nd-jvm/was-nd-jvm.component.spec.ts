import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasNdJvmComponent } from './was-nd-jvm.component';

describe('WasNdJvmComponent', () => {
  let component: WasNdJvmComponent;
  let fixture: ComponentFixture<WasNdJvmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasNdJvmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasNdJvmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
