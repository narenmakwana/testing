import { Component, AfterViewInit, Output, Input, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { WasJvmTemplate } from '../../../../../shared/models/was-jvm-template';
import { WasNodeTemplate } from '../../../../../shared/models/was-node-template';
import { Constants } from '../../../../../shared/config/constants';
import { WasCell } from '../../../../../shared/models/was-cell';
import { WasNdService } from '../was-nd.service';
import { DialogService } from '../../../../../shared/services/dialog.service';

@Component({
  selector: 'c-was-nd-jvm',
  templateUrl: './was-nd-jvm.component.html',
  styleUrls: ['./was-nd-jvm.component.scss']
})
export class WasNdJvmComponent implements AfterViewInit {


  @Input() jvmIndex: number = 0;
  @Input() currWasNode: number = 0;
  @Output() hasChanged = new EventEmitter();

  _wasCell: WasCell;
  jvmTemplate: WasJvmTemplate;
  wasNodeTemplate: WasNodeTemplate;
  public jvmresult: any;

  constructor(private _wasNdService: WasNdService, private dialogService: DialogService) {
    this.jvmTemplate = new WasJvmTemplate();
  }

  ngOnInit() {
    this._wasCell = this._wasNdService.wasCell;
    this.wasNodeTemplate = this._wasCell.getNode(this.currWasNode);
    this.jvmTemplate = this.wasNodeTemplate.getJvm(this.jvmIndex);
  }

  ngAfterViewInit() {
  }

  onChange() {
    if (this.validateTemplate())
      this.hasChanged.emit(this.jvmTemplate);
  }

  clusterChanged(selcluster: string) {
    // Update the jvmName to reflect the clusterName
    var jvmName = this.jvmTemplate.jvmName;
    var jvmend = jvmName.slice(jvmName.lastIndexOf("-") + 1);
    var newJvm = selcluster + "-" + jvmend;
    this.jvmTemplate.jvmName = newJvm;
  }

  // Check for any duplicate JVM Names.
  jvmUpdated(event: any) {

    let dups = this._wasCell.findDuplicateJvmNames();
    if (dups) {
      if (dups.length > 0)
        this.dialogService
          .ok('Duplicate JVM Names Found.', dups[0])
          .subscribe(res => this.jvmresult = res);
    }
  }

  validateTemplate(): boolean {
    return true;
  }

}
