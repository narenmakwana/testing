import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasNdListItemComponent } from './was-nd-list-item.component';

describe('WasNdListItemComponent', () => {
  let component: WasNdListItemComponent;
  let fixture: ComponentFixture<WasNdListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasNdListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasNdListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
