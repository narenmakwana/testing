import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {WasCell} from '../../../../../../shared/models/was-cell';
import {DialogService} from '../../../../../../shared/services/dialog.service';
import {WasWorkflowService} from '../../../../../../shared/services/was-workflow.service';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {WasNdService} from '../../was-nd.service';
import { AuthenticationService } from '../../../../../pages/authentication/authentication.service';
import { TokenService } from '../../../../../pages/authentication/token.service';
import {MatSnackBar} from '@angular/material';


@Component({
  selector: 'c-was-nd-list-item',
  templateUrl: './was-nd-list-item.component.html',
  styleUrls: ['./was-nd-list-item.component.scss']
})

export class WasNdListItemComponent implements OnInit {

 @Input() wasNdCellData : WasCell;
 @Output() deleteEvent = new EventEmitter();
 cellSelected: boolean;
 isAdmin: boolean = false;
 public result: any;
 status: any;

  constructor( protected _router: Router, private _wasWorkflow: WasWorkflowService,public snackBar: MatSnackBar, 
               private _wasNdService: WasNdService, private dialogService: DialogService, private authService: AuthenticationService) { 
      this.wasNdCellData = new WasCell();
  }

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
     if(this.wasNdCellData.status) {
         this.status = this.wasNdCellData.status.pop();
     }
     else
        this.status = [{userName: "", date: new Date()}];
  }

  editCell() {
     this._router.navigate(['apps/design/wasnd', this.wasNdCellData._id]);
  }

  runPre() {
    //   this._router.navigate(['apps/design/wasnd', this.wasNdCellData._id]);
    console.log("WAS Cell", this.wasNdCellData);
    this.dialogService
    .confirm("Run PreCheck - " +this.wasNdCellData.cellname,"Please click OK to proceed" )
    .subscribe(res => {
      if (res) {
        this.result = res;
        this.snackBar.open('PreCheck Started for ' + this.wasNdCellData.cellname + '!','Dismiss',{
          duration:5000
        });
        this.snackBar._openedSnackBarRef.onAction().subscribe(() => {
          this.snackBar.dismiss();
        });
        this._wasNdService.runPreCheck(this.wasNdCellData).then(this.handleRunPreSuccess.bind(this))
        .catch(this.handleError.bind(this));
      }
    }); 
    
  }

  // If the new Cell is saved, go to edit it now.
  handleSaveSuccess(response : any) {
     var newCell = response;
     this._router.navigate(['apps/design/wasnd', newCell._id]);
  }

    // If the runPre is successful display a notification
  handleRunPreSuccess(response : any) {
      this.snackBar.open('PreCheck finished for ' + this.wasNdCellData.cellname + '!', 'Dismiss',{
        duration:5000
      });
      this.snackBar._openedSnackBarRef.onAction().subscribe(() => {
        this.snackBar.dismiss();
      });
  }

  handleDeleteSuccess() {
    this.deleteEvent.emit(null);
  }

  handleDeleteError(error) {
    this.dialogService
      .ok('Error Deleting Cell ' + this.wasNdCellData.cellname, 'Error: ' + error)
      .subscribe(res => this.result = res);
  }


  handleSaveError(error: string){
      console.log("Error Encountered..", error);
  }

  cloneCell() {
     this.wasNdCellData = this._wasNdService.createWasCellFromExisting(this.wasNdCellData);
     this.wasNdCellData._id = ""; // blank out the ID and save the new document first.
     var newCell = this._wasNdService.saveWasCell(this.wasNdCellData).catch(this.handleSaveError.bind(this))
                                                           .then(this.handleSaveSuccess.bind(this));
  }

  handleSuccess() {
     this._router.navigate(['apps/search/jobs-search-results', 
              { cellId: this.wasNdCellData.cellname, 
                product: 'was',
                limit: 20
              }]);
  }

  handleError(error) {
    this.dialogService
      .ok('Error Deploying Cell '+this.wasNdCellData.cellname, ' Error:' + error)
      .subscribe(res => this.result = res);
  }

  deployCell() {
    this.dialogService
      .confirm('Deploy Cell ' + this.wasNdCellData.cellname, 'Please click OK to proceed with deploying cell.')
      .subscribe(res => {
        if (res) {
          this.result = res;
          this._wasWorkflow.deployCell(this.wasNdCellData).then(this.handleSuccess.bind(this))
            .catch(this.handleError.bind(this));
        }
      });
  }

  deleteCell() {
    this.dialogService
      .confirm('Delete Cell : ' + this.wasNdCellData.cellname, "Are you sure you want to delete this cell design?")
      .subscribe(res => {
        if (res) {
          this.result = res;
          this._wasWorkflow.deleteCellDesign(this.wasNdCellData._id)
            .then(this.handleDeleteSuccess.bind(this))
            .catch(this.handleDeleteError.bind(this));
        }
      });
  }
}
