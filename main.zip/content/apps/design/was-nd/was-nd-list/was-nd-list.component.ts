import { WasNdService } from '../was-nd.service';
import { Observable } from 'rxjs/Observable';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {OnInit, Component, Input} from '@angular/core';
import { ResponseResult } from '../../../../../shared/models/response-result';
import { Subscription } from "rxjs/Rx";
import {UditUtils}  from '../../../../../../core/uditUtils';
import { HttpClient, HttpParams } from '@angular/common/http';

interface ICellSelected {
    cellname : string;
    checked : boolean;
}

@Component({
  selector: 'c-was-nd-list',
  templateUrl: './was-nd-list.component.html',
  styleUrls: ['./was-nd-list.component.scss']
})

export class WasNdListComponent implements OnInit {

  responseResults: ResponseResult;
  _params : Observable<any>;
  private subscription: Subscription;
  private searchsub : Subscription;

  private cellname: string = ""; 
  private hostname: string = "";
  private tciCode: string = "";
  private envType: string = "";

  private params: string[];
  private limit: number;
  private offset: number;
  
  selectedCells : string[] = [];
  
  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected route: ActivatedRoute, protected _wasService: WasNdService ) { 
       this.responseResults = new ResponseResult();
  }

  ngOnInit() { 
    // subscribe to router event
    this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.cellname = params['cellId'];
        this.hostname = params['host'];
        this.tciCode = params['tci'];
        this.envType = params['envtype'];
        this.limit = +params['limit'];
    });

    this.getPage(1);
  }

  search(limit: number, page : number){
     // calculate the offset based on page number and limit.
     var offset = (page - 1) * limit;
     var paramObj = {
        "cellname" : this.cellname,
        "nodes.host" : this.hostname,
        "cellname.startsWith" : this.tciCode,
        "cellname.contains" : this.envType,
        "limit": limit,
        "offset" : offset
    };

    var paramString = UditUtils.buildQueryParams(paramObj);
    let httpParams = new HttpParams({
      fromString: paramString
    });
    
    this._wasService.getWasDesigns(httpParams)
                          .then((data)=>{
                            this.responseResults = data;
                            this.total = this.responseResults.total;
                            this.p = page;
                            this.loading = false;
                          });
  }

  getPage(page: number) {
      this.loading = true;
      this.search(this.limit, page);
  }

  handleCellSelection(event : ICellSelected) {
    if( event.checked ) {
        // add the cellname to the list of selected cells.
        this.selectedCells.push(event.cellname);
    }
    else{
        // the cell is deselected. check to see if it exists in our list of selected cells 
        // if it exists, then remove it from that list.
        for(let i = 0; i < this.selectedCells.length; i++) {
            if(this.selectedCells[i] === event.cellname) {
                // found it. remove it from the list.
                this.selectedCells.splice(i, 1);
            }
        }
    }
}

}

