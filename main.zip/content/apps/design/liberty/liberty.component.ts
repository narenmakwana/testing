import { Component, OnInit, AfterViewInit, Output, OnDestroy, EventEmitter } from '@angular/core';
import {NgForm} from '@angular/forms';
import {MatDialog, MatDialogRef} from '@angular/material';
import {MatSlideToggle} from '@angular/material';
import {MatSlider} from '@angular/material';
import {LibertyNodeTemplate} from '../../../../shared/models/liberty-node-template';
import {LibertyCell} from '../../../../shared/models/liberty-cell';
import {LibertyService} from './liberty.service';
import {LibertySummaryComponent} from './liberty-summary/liberty-summary.component';
import {CompletedDialogComponent} from './completed-dialog/completed-dialog.component';
import {Subscription} from 'rxjs';
import {OptionsService} from '../../../../shared/services/options.service';
import {Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'c-liberty',
  templateUrl: './liberty.component.html',
  styleUrls: ['./liberty.component.scss']
})

export class LibertyComponent implements OnInit, OnDestroy  {

  public _selectedIndex: number = 0;
  @Output()
  _libertyCell: LibertyCell;

  tciCodes : string[] = [];

  @Output() nodeIndex: number = 0;
  @Output() ID : string;
  @Output() 
  change: EventEmitter<LibertyCell> = new EventEmitter<LibertyCell>();
  @Output() hasChanged = new EventEmitter();

  constructor(protected _router: Router, private _activeRoute: ActivatedRoute, private _libertyService: LibertyService, 
               private _optionsService: OptionsService  ) { 
     this._libertyCell = _libertyService.createLibertyCell();
  }

  // Subscribe to the change in the route parameters. We want to know if the route contains the ID of the cell.
  ngOnInit() {
    this._activeRoute.params.subscribe(this.onParamChange.bind(this));
  }

  ngAfterViewInit(){
       // Initialize the was & wlp versions and fixpacks
       this._libertyService.loadWlpVersions()
       .then(() =>{
         this._libertyService.loadWasVersions();
       })
       .catch((err) =>{
         console.log(err);
       })
  }

  // Cleanup Stuff here.
  ngOnDestroy() {
  }

  // Edit Cell Being Handled here. We need to load the existing 
  // Cell data here. The data coming from database does not have everything
  // which is needed by the object to be initialized. So we need to instantiate
  // a new object.
  handleSuccess( _libCell: any) {
      this.ID = _libCell._id;
      this._libertyCell = this._libertyService.createLibertyCellFromExisting(_libCell);
      this.change.emit(this._libertyCell);
  }

  handleError(error) {
      console.log("Got Error in Getting LibertyCell Data")
  }

  // We got here when a user selected a cell to be edited. So we get the cell details
  // from the database and then initiaze the models with this data.
  onParamChange(params : any) {
      if(params['id']) {
          // Retrieve the document here.
        this._libertyService.getLibertyCellById(params['id']).catch(this.handleError.bind(this))
                                                           .then(this.handleSuccess.bind(this));  
      }
  }

  get selectedIndex(): number {
    return this._selectedIndex;
  }

  set selectedIndex(selectedIndex: number) {
    this._selectedIndex = selectedIndex;
  }

  showRemoveNode(currIndex: number) : boolean {
     if (currIndex >= 1) {
        return true;
     }
     else{
        return false;
     }
  }

  getTciCodes(event : any) {
     var val = this._libertyCell.tciCode + event.key;
     this._optionsService.queryTciCodes(val)
            .then(resp => {
                this.tciCodes = resp;
            });             
  }

  validateProjectInfo() : boolean {
    // Perform some validations here first.
    // Check to see if the cell already exists on our system.
   //  return true;
   return (this._libertyCell.isValidTCI());
  }

  canMove(index: number): boolean {
    switch (index) {
      case 0:
        return true;
      case 1:
        return this.validateProjectInfo();
      case 2:
        return this.canMove(1);
      default:
        return true;
    }
  } 

  next(): void {
    if(this.canMove(this.selectedIndex + 1)) {
      this.selectedIndex++;
      this.change.emit(this._libertyCell);  //notify everyone.
    }
  }

  previous(): void {
    if(this.canMove(this.selectedIndex - 1)) {
      this.selectedIndex--;
    }
  }

  handleSaveError(error: string){
      console.log("Error Encountered..", error);
  }

  handleSaveSuccess() {
     this._router.navigate(['apps/design/liberty/list', 
          { cellId: this._libertyService.libertyCell.cellname, 
            limit: 20
          }]);
  }


  finish(): void {
    this._libertyCell.validate();
    this._libertyService.saveLibertyCell(this._libertyCell).catch(this.handleSaveError.bind(this))
                                                           .then(this.handleSaveSuccess.bind(this));
  }

  addNewNode() {
      let newNode = this._libertyCell.addNode();  // Add a new Node.
      this.hasChanged.emit(); 
  }

  removeNode(currIndex) {
      this._libertyCell.removeNode(currIndex);
  }

  nodesChanged(_node: LibertyNodeTemplate, _selectedNode: number): void {
     // Save each node in the correct index.
     this._libertyCell.setNode(_selectedNode, _node);
  }

  submit(form: NgForm): void {
  }

}
