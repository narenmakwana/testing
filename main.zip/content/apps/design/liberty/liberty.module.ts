import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { LibertyDesignListComponent } from './liberty-design-list/liberty-design-list.component';
import { LibertyIhsComponent } from './liberty-ihs/liberty-ihs.component';
import { LibertyJvmComponent } from './liberty-jvm/liberty-jvm.component';
import { LibertyNodeComponent } from './liberty-node/liberty-node.component';
import { LibertySummaryComponent } from './liberty-summary/liberty-summary.component';
import { LibertyComponent } from './liberty.component';
import { LibertyDesignListItemComponent } from './liberty-design-list/liberty-design-list-item/liberty-design-list-item.component';
import { OptionsService } from '../../../../shared/services/options.service';
import { PackagesService } from '../../../../shared/services/packages.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { DialogService } from '../../../../shared/services/dialog.service';
import { LibertyService } from './liberty.service';
import { CompletedDialogComponent } from './completed-dialog/completed-dialog.component';

const routes: Routes = [
  {
      path     : 'design/liberty/list',
      component: LibertyDesignListComponent
  },
  {
      path     : 'design/liberty',
      component: LibertyComponent
  },
  {
      path     : 'design/liberty/:id',
      component: LibertyComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    NgxPaginationModule,
    RouterModule.forChild(routes)
  ],
  declarations: [LibertyDesignListComponent, LibertyIhsComponent, LibertyJvmComponent, LibertyNodeComponent, LibertySummaryComponent, 
    LibertyComponent, LibertyDesignListItemComponent, CompletedDialogComponent],
  providers: [OptionsService, PackagesService, DialogService, LibertyService
       ]
})
export class LibertyModule { }
