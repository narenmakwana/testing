import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyIhsComponent } from './liberty-ihs.component';

describe('LibertyIhsComponent', () => {
  let component: LibertyIhsComponent;
  let fixture: ComponentFixture<LibertyIhsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyIhsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyIhsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
