import { Component, AfterViewInit, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {NgForm} from '@angular/forms';
import {IhsTemplate} from '../../../../../shared/models/ihs-template';
import {Constants} from '../../../../../shared/config/constants';
import {LibertyCell} from '../../../../../shared/models/liberty-cell';
import {LibertyService} from '../liberty.service';
import {LibertyNodeTemplate} from '../../../../../shared/models/liberty-node-template';


@Component({
  selector: 'c-liberty-ihs',
  templateUrl: './liberty-ihs.component.html',
  styleUrls: ['./liberty-ihs.component.scss']
})

export class LibertyIhsComponent  implements AfterViewInit {

  @Input() ihsIndex: number = 0;
  @Input() currWlpNode: number = 0;
  @Output() hasChanged = new EventEmitter();

  private _libertyCell : LibertyCell;
  ihsTemplate: IhsTemplate;
  libertyNodeTemplate: LibertyNodeTemplate;

  constructor( private _libertyService: LibertyService ) { 
     this.ihsTemplate = new IhsTemplate();
  }

  ngOnInit(){
     this._libertyCell = this._libertyService.libertyCell;
     this.libertyNodeTemplate = this._libertyCell.getNode(this.currWlpNode);
     this.ihsTemplate = this.libertyNodeTemplate.getIhs(this.ihsIndex);
  }

  ngAfterViewInit() {
  }

  onChange() {
     if( this.validateTemplate() )
        this.hasChanged.emit(this.ihsTemplate);
  }

  validateTemplate() : boolean {
    if( this.ihsTemplate.hostName.length === Constants.MAX_HOSTNAME_LEN) {
      return true;      
    }
    return false;
  }

}
