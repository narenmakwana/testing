import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertySummaryComponent } from './liberty-summary.component';

describe('LibertySummaryComponent', () => {
  let component: LibertySummaryComponent;
  let fixture: ComponentFixture<LibertySummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertySummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertySummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
