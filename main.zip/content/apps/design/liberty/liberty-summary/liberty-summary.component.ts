import { Component, AfterViewInit, OnInit, Input } from '@angular/core';
import {JvmTemplate} from '../../../../../shared/models/jvm-template';
import {Constants} from '../../../../../shared/config/constants';
import {LibertyCell} from '../../../../../shared/models/liberty-cell';
import {LibertyService} from '../liberty.service';

@Component({
  selector: 'c-liberty-summary',
  templateUrl: './liberty-summary.component.html',
  styleUrls: ['./liberty-summary.component.scss']
})
export class LibertySummaryComponent implements AfterViewInit {

  @Input() _libertyCell : LibertyCell;

  constructor( private _libertyService: LibertyService ) { 
     this._libertyCell = _libertyService.libertyCell;
  }

  ngOnInit() {

  }

  ngAfterViewInit() {
  }

  ngOnDestroy() {
     // unsubscribe to ensure no memory leaks
  }

}
