import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LibertyCell } from '../../../../shared/models/liberty-cell';
import { ResponseResult } from '../../../../shared/models/response-result';
import { PackagesService } from '../../../../shared/services/packages.service';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { OptionsService } from '../../../../shared/services/options.service';
import { Constants } from '../../../../shared/config/constants';
import { UditUtils } from '../../../../../core/uditUtils';
import { TokenService } from '../../../pages/authentication/token.service';


@Injectable()
export class LibertyService {

  _libertyCell: LibertyCell;
  _responseResults: ResponseResult;

  constructor(private http: HttpClient, protected _packageService: PackagesService, private tokenService: TokenService,
    protected _optionsService: OptionsService, protected _invService: InventoryService) {
  }

  get libertyCell(): LibertyCell {
    return this._libertyCell;
  }

  setLibertyCell(libertyCell: LibertyCell): void {
    this._libertyCell = libertyCell;
  }

  createLibertyCell(): LibertyCell {
    return (this._libertyCell = new LibertyCell());
  }

  loadWasVersions(): Promise<any> {
    //console.log("Loading WAS Versions...");
    return this._optionsService.queryWasVersions(null, Constants.INSTALL_TYPES.ND.value)
      .then((results: string[]) => {
        this._libertyCell.setIhsVersions(results.reverse())
      })
      .catch((error => console.log(error)));
  }

  loadWlpVersions(): Promise<any> {
    return this._optionsService.getWlpVersions()
      .then((results: string[]) => {
        //console.log("Loading WLP Versions...");
        this._libertyCell.setWlpVersions(results.reverse())
      })
      .catch((error => console.log(error)));
  }

  getWlpVersions(): Promise<any> {
    return this._optionsService.getWlpVersions();
  }

  getIhsVersions(): Promise<any> {
    return this._optionsService.queryWasVersions(null, Constants.INSTALL_TYPES.ND.value);
  }

  createLibertyCellFromExisting(libCell: any): LibertyCell {
    return (this._libertyCell = new LibertyCell(libCell));
  }

  //return an array of values that match on a certain key
  public getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;
      if (typeof obj[i] == 'object') {
        objects = objects.concat(this.getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }
    return objects;
  }

  public getLibertyDesigns(httpParams): Promise<any> {
    //console.log('Calling getLibertyDesigns...');
    return this.http.get(Constants.getWlpDesignUrl(), { params: httpParams })
      .toPromise()
      .then(this.libDesignSearchResults)
      .catch(this.handleError);
  }

  libDesignSearchResults(_response: Response): any {
    let body = _response;
    return body || {};
  }

  public getLibertyCell(cellname: string): Promise<any> {
    let httpParams = new HttpParams().set('cellname', cellname);
    return this.http.get(Constants.getWlpDesignUrl(), { params: httpParams })
      .toPromise()
      .then(this.getCellDetails)
      .catch(this.handleError);
  }

  getCellDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  public getLibertyCellById(id: string): Promise<any> {
    return this.http.get(Constants.getWlpDesignUrl() + "/" + id)
      .toPromise()
      .then(this.getCellDetails)
      .catch(this.handleError);
  }

  public checkIfCellExists(cellname: string): boolean {
    var exists = false;
    this.getLibertyInvCellByName(cellname).then(function (celldetails) {
      exists = true;
    });
    return exists;
  }

  public getLibertyInvCellByName(cellname: string): Promise<any> {
    return this._invService.getLibertyInvCellByName(cellname)
    .then(this.getWlpDesignCellDetails)
    .catch(this.handleError);
  }


  public getLibertyDesignCellByName(cellname: string): Promise<any> {
    return this.http.get(Constants.getWlpDesignUrl() + "/" + cellname)
      .toPromise()
      .then(this.getWlpDesignCellDetails)
      .catch(this.handleError);
  }

  public runPreCheck(libertyCell: LibertyCell): Promise<any> {
    // First check to see if this cell already exists.  
    var userName = this.tokenService.getUserId();
    var cellName = libertyCell.cellname;
    var hosts = [];
    libertyCell.nodeTemplates.forEach(function (node) {
      if (node.hostName) {
        hosts.push(node.hostName)
      }

    });
    var jsonBody = {
      "data":
        {
          "username": userName,
          "cellId": cellName,
          "hostNames": hosts
        }
    };

    return this.http.post(Constants.getpreCheckUrl(), jsonBody)
      .toPromise()
      .then(this.saveCellDetails)
      .catch(this.handleError);

  }

  getWlpInvCellDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  getWlpDesignCellDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  public saveLibertyCell(libertyCell: LibertyCell): Promise<any> {
    //console.log('Saving Liberty Cell...');
    // This is a new cell we are saving. Since this is new cell
    // we want to make sure that we don't pass the _id and __v to mongo.
    //      delete this.libertyCell.__v;
    //console.log(libertyCell);
    var id = libertyCell._id;
    delete libertyCell._id;
    var status = {
      userName: this.tokenService.getUserId(),
      date: new Date()
    }
    //console.log(status);
    if (libertyCell.status){
      libertyCell.status.push(status);
    }
    else {
      libertyCell.status = [];
      libertyCell.status.push(status);
    }
    if (id) {
      return this.http.put(Constants.getWlpDesignUrl() + "/" + id, libertyCell)
        .toPromise()
        .then(this.saveCellDetails)
        .catch(this.handleError);
    }
    else {
      return this.http.post(Constants.getWlpDesignUrl(), libertyCell)
        .toPromise()
        .then(this.saveCellDetails)
        .catch(this.handleError);
    }
  }

  saveCellDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  }
}
