import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyDesignListComponent } from './liberty-design-list.component';

describe('LibertyDesignListComponent', () => {
  let component: LibertyDesignListComponent;
  let fixture: ComponentFixture<LibertyDesignListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyDesignListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyDesignListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
