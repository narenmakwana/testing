import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyDesignListItemComponent } from './liberty-design-list-item.component';

describe('LibertyDesignListItemComponent', () => {
  let component: LibertyDesignListItemComponent;
  let fixture: ComponentFixture<LibertyDesignListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyDesignListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyDesignListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
