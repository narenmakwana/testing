import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LibertyCell } from '../../../../../../shared/models/liberty-cell';
import { LibertyWorkflowService } from '../../../../../../shared/services/liberty-workflow.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DialogService } from '../../../../../../shared/services/dialog.service';
import { LibertyService } from '../../liberty.service';
import { AuthenticationService } from '../../../../../pages/authentication/authentication.service';
import { MatSnackBar } from '@angular/material';


@Component({
  selector: 'c-liberty-design-list-item',
  templateUrl: './liberty-design-list-item.component.html',
  styleUrls: ['./liberty-design-list-item.component.scss']
})
export class LibertyDesignListItemComponent implements OnInit {

  @Input() libertyCellData: LibertyCell;

  @Output() deleteEvent = new EventEmitter();

  cellSelected: boolean;
  isAdmin: boolean = false;
  public result: any;
  status: any;

  constructor(protected _router: Router, private _libertyWorkflow: LibertyWorkflowService, public snackBar: MatSnackBar,
    private _libertyService: LibertyService, private dialogService: DialogService, private authService: AuthenticationService) {
    this.libertyCellData = new LibertyCell();
  }

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    if (this.libertyCellData.status) {
      this.status = this.libertyCellData.status.pop();
    }
    else
      this.status = [{ userName: "", date: new Date() }];
  }

  editCell() {
    this._router.navigate(['apps/design/liberty', this.libertyCellData._id]);
  }

  runPre() {
    this.dialogService
      .confirm("Run PreCheck - " + this.libertyCellData.cellname, "Please click OK to proceed")
      .subscribe(res => {
        if (res) {
          this.result = res;
          this.snackBar.open('PreCheck Started for ' + this.libertyCellData.cellname + '!', 'Dismiss', {
            duration: 5000
          });
          this.snackBar._openedSnackBarRef.onAction().subscribe(() => {
            this.snackBar.dismiss();
          });
          this._libertyService.runPreCheck(this.libertyCellData).then(this.handleRunPreSuccess.bind(this))
            .catch(this.handleError.bind(this));
        }
      });

  }

  // If the runPre is successful display a notification
  handleRunPreSuccess(response: any) {
    this.snackBar.open('PreCheck finished for ' + this.libertyCellData.cellname + '!', 'Dismiss', {
      duration: 5000
    });
    this.snackBar._openedSnackBarRef.onAction().subscribe(() => {
      this.snackBar.dismiss();
    });
  }

  handleSuccess() {
    this._router.navigate(['apps/search/jobs-search-results',
      {
        cellId: this.libertyCellData.cellname,
        product: 'wlp',
        limit: 20
      }]);
  }

  handleDeleteSuccess() {
    this.deleteEvent.emit(null);
  }

  handleDeleteError(error) {
    this.dialogService
      .ok('Error Deleting Cell ' + this.libertyCellData.cellname, 'Error: ' + error)
      .subscribe(res => this.result = res);
  }

  handleError(error) {
    this.dialogService
      .ok('Error Deploying Cell ' + this.libertyCellData.cellname, ' Error:' + error)
      .subscribe(res => this.result = res);
  }

  // If the new Cell is saved, go to edit it now
  handleSaveSuccess(response: any) {
    var newCell = response;
    this._router.navigate(['apps/design/liberty', newCell._id]);

  }


  handleSaveError(error: string) {
    console.log("Error Encountered..", error);
  }

  cloneCell() {
    this.libertyCellData = this._libertyService.createLibertyCellFromExisting(this.libertyCellData);
    this.libertyCellData._id = ""; // blank out the ID and save the new document first.
    var newCell = this._libertyService.saveLibertyCell(this.libertyCellData).catch(this.handleSaveError.bind(this))
      .then(this.handleSaveSuccess.bind(this));
  }

  deployCell() {
    this.dialogService
      .confirm('Deploy Cell ' + this.libertyCellData.cellname, 'Please click OK to proceed with deploying cell.')
      .subscribe(res => {
        if (res) {
          this.result = res;
          this._libertyWorkflow.deployCell(this.libertyCellData).then(this.handleSuccess.bind(this))
            .catch(this.handleError.bind(this));
        }
      });
  }

  deleteCell() {
    this.dialogService
      .confirm('Delete Cell : ' + this.libertyCellData.cellname, "Are you sure you want to delete this cell design?")
      .subscribe(res => {
        if (res) {
          this.result = res;
          this._libertyWorkflow.deleteCellDesign(this.libertyCellData._id)
            .then(this.handleDeleteSuccess.bind(this))
            .catch(this.handleDeleteError.bind(this));
        }
      });
  }
}
