import {Component} from '@angular/core';
import {MatDialogRef} from '@angular/material';

@Component({
  selector : 'c-completed-dialog',
  template : `
    <mat-card>
      <mat-card-title>Success</mat-card-title>
      <mat-card-content>
        You've successfully completed this form!
      </mat-card-content>
      <mat-card-actions align="end">
        <button mat-raised-button color="primary" (click)="close()">Done</button>
      </mat-card-actions>
    </mat-card>
  `,
  styles : []
})
export class CompletedDialogComponent {

  constructor(public dialogRef: MatDialogRef<CompletedDialogComponent>) {
  }

  close() {
    this.dialogRef.close({success : true});
  }

}
