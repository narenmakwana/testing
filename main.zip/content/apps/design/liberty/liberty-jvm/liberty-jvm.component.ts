import { Component, AfterViewInit, Output, Input, EventEmitter } from '@angular/core';
import {NgForm} from '@angular/forms';
import {JvmTemplate} from '../../../../../shared/models/jvm-template';
import {LibertyNodeTemplate} from '../../../../../shared/models/liberty-node-template';
import {Constants} from '../../../../../shared/config/constants';
import {LibertyCell} from '../../../../../shared/models/liberty-cell';
import {LibertyService} from '../liberty.service';

@Component({
  selector: 'c-liberty-jvm',
  templateUrl: './liberty-jvm.component.html',
  styleUrls: ['./liberty-jvm.component.scss']
})
export class LibertyJvmComponent implements  AfterViewInit {

  @Input() jvmIndex: number = 0;
  @Input() currWlpNode: number = 0;
  @Output() hasChanged = new EventEmitter();

  private _libertyCell : LibertyCell;
  jvmTemplate: JvmTemplate;
  libertyNodeTemplate: LibertyNodeTemplate;

  constructor( private _libertyService: LibertyService ) { 
     this.jvmTemplate = new JvmTemplate();
  }

  ngOnInit(){
     this._libertyCell = this._libertyService.libertyCell;
     this.libertyNodeTemplate = this._libertyCell.getNode(this.currWlpNode);
     this.jvmTemplate = this.libertyNodeTemplate.getJvm(this.jvmIndex);
  }

  ngAfterViewInit() {
  }

  onChange() {
     if( this.validateTemplate() )
        this.hasChanged.emit(this.jvmTemplate);
  }

  validateTemplate() : boolean {
    return true;
  }

}