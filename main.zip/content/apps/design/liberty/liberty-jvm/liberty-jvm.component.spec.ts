import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyJvmComponent } from './liberty-jvm.component';

describe('LibertyJvmComponent', () => {
  let component: LibertyJvmComponent;
  let fixture: ComponentFixture<LibertyJvmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyJvmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyJvmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
