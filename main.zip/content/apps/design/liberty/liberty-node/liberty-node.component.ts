import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LibertyNodeTemplate } from '../../../../../shared/models/liberty-node-template';
import { LibertyCell } from '../../../../../shared/models/liberty-cell';
import { Constants } from '../../../../../shared/config/constants';
import { LibertyIhsComponent } from '../liberty-ihs/liberty-ihs.component';
import { IhsTemplate } from '../../../../../shared/models/ihs-template';
import { JvmTemplate } from '../../../../../shared/models/jvm-template';
import { LibertyService } from '../liberty.service';
import { DialogService } from '../../../../../shared/services/dialog.service';

@Component({
    selector: 'c-liberty-node',
    templateUrl: './liberty-node.component.html',
    styleUrls: ['./liberty-node.component.scss']
})

export class LibertyNodeComponent implements OnInit, AfterViewInit {

    libertyNodeTemplate: LibertyNodeTemplate;
    @Output()
    _libertyCell: LibertyCell;
    public dialogResult: any;

    controllerCell: string[] = [];

    @Input() libertyCellData: LibertyCell;

    @Input() nodeIndex: number = 0;
    @Output() currWlpNode: number = 0;
    @Output() jvmChanged = new EventEmitter();
    @Output() hasChanged = new EventEmitter();

    constructor(private _libertyService: LibertyService, private _dialogService: DialogService) {
        this.libertyNodeTemplate = new LibertyNodeTemplate();
    }

    ngOnInit() {
        this._libertyCell = this._libertyService.libertyCell;
        this.libertyNodeTemplate = this._libertyCell.getNode(this.nodeIndex);
        this.currWlpNode = this.nodeIndex;
    }

    ngAfterViewInit() {
    }

    showRemoveJvm(currIndex: number): boolean {
        if (currIndex >= 0) {
            if (this.libertyNodeTemplate.numJvms > 0)
                return true;
            else
                return false;
        }
        else {
            return false;
        }
    }

    showRemoveIhs(currIndex: number): boolean {
        if (currIndex >= 0) {
            if (this.libertyNodeTemplate.numHttpServers > 0)
                return true;
            else
                return false;
        }
        else {
            return false;
        }
    }

    addNewJvm() {
        // First check to see if there are no duplicate port numbers on this host.
        var portBlocks = this.libertyNodeTemplate.findDuplicateJvmPorts();
        if (portBlocks.length > 0) {
            // Duplicates found.
            this._dialogService
                .ok('Error Adding JVM', "Duplicate PORT BLOCKS Found on the SAME HOST : " + portBlocks + "!!!")
                .subscribe();
        }
        else {
            let newJvm = this.libertyNodeTemplate.addJvm(this.libertyCellData);
            this.currWlpNode = this.nodeIndex;
            this.jvmChanged.emit(newJvm);;
        }
    }

    removeJvm(currIndex) {
        this.currWlpNode = this.nodeIndex;
        this.libertyNodeTemplate.removeJvm(this.libertyCellData, currIndex);
    }

    addIhs() {
        var portBlocks = this.libertyNodeTemplate.findDuplicateIhsPorts();
        if (portBlocks.length > 0) {
            // Duplicates found.
            this._dialogService
                .ok('Error Adding IHS', "Duplicate PORT BLOCKS Found on the SAME HOST : " + portBlocks + "!!!")
                .subscribe();
        }
        else {
            let newJvm = this.libertyNodeTemplate.addIhs(this.libertyCellData);
            this.currWlpNode = this.nodeIndex;
        }
    }

    removeIhs(currIndex) {
        this.currWlpNode = this.nodeIndex;
        this.libertyNodeTemplate.removeIhs(this.libertyCellData, currIndex);
    }

    ihsChanged(_ihsTemplate: IhsTemplate, _selectedIHS: number): void {
        this.libertyNodeTemplate.ihsTemplates[_selectedIHS] = _ihsTemplate;
        this.libertyNodeTemplate.setIhs(this.libertyCellData, _selectedIHS, _ihsTemplate);
    }

    OnJvmChange(_jvmTemplate: JvmTemplate, _selectedJVM: number): void {
        this.libertyNodeTemplate.jvmTemplates[_selectedJVM] = _jvmTemplate;
        this.libertyNodeTemplate.setJvm(this.libertyCellData, _selectedJVM, _jvmTemplate);
        this.currWlpNode = this.nodeIndex;
    }

    onChange(nodename: string) {
        if (this.validateTemplate())
            this.hasChanged.emit(this.libertyNodeTemplate);
        this.currWlpNode = this.nodeIndex;
    }

    getControllerInfo(event: any) {
        var val = this.libertyNodeTemplate.collCellName + event.key;
        var values = [];
        if (val.length >= 11) {
            this._libertyService.getLibertyInvCellByName(val)
                .then(resp => {
                    if (resp.items[0]) {
                        this.controllerCell.push(resp.items[0].cellName);
                        this.libertyNodeTemplate.collHostName = this._libertyService.getValues(resp, 'hostName')[0];
                        this.libertyNodeTemplate.collJavaPath = this._libertyService.getValues(resp, 'javaHome')[0];
                        var names = this._libertyService.getValues(resp, 'name');
                        for (let i = 0; i < names.length; i++) {
                            if (names[i].indexOf("-cntrlr-") >= 0 && names[i].split("-").pop() === '01') {
                                this.libertyNodeTemplate.collControllerName = names[i];
                            }
                        }
                        var ports = this._libertyService.getValues(resp, 'httpsPort');
                        if (ports.length > 0) {
                            this.libertyNodeTemplate.collPortNumber = ports[0];
                        }
                        values = this._libertyService.getValues(resp, 'user');
                        for (let i = 0; i < values.length; i++) {
                            if (values[i].indexOf("sys-") >= 0) {
                                this.libertyNodeTemplate.collAdminUser = values[i];
                            }
                        }
                    }
                });
        }
    }


    controllerCellChanged(value: string) {
        if (value.length < 11) {
            this.controllerCell = [];
            this.libertyNodeTemplate.collHostName = "";
            this.libertyNodeTemplate.collJavaPath = "";
            this.libertyNodeTemplate.collControllerName = "";
            this.libertyNodeTemplate.collPortNumber = "";
            this.libertyNodeTemplate.collAdminUser = "";
        }
    }

    validateTemplate(): boolean {
        if (this.libertyNodeTemplate.hostName.length === Constants.MAX_HOSTNAME_LEN) {
            return true;
        }
        console.log('returned false');
        return false;
    }

}
