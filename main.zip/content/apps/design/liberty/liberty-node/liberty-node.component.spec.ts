import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyNodeComponent } from './liberty-node.component';

describe('LibertyNodeComponent', () => {
  let component: LibertyNodeComponent;
  let fixture: ComponentFixture<LibertyNodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyNodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyNodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
