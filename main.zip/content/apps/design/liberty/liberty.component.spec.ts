import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibertyComponent } from './liberty.component';

describe('LibertyComponent', () => {
  let component: LibertyComponent;
  let fixture: ComponentFixture<LibertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
