import { Component, AfterViewInit, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { ServerConfig } from '../../../../../shared/models/server-config';
import { LinuxGroupTemplate } from '../../../../../shared/models/linux-group-template';
import { LinuxGroupNas } from '../../../../../shared/models/linux-group-nas';
import {LinuxService} from '../linux.service';


@Component({
  selector: 'c-linux-group-nas',
  templateUrl: './linux-group-nas.component.html',
  styleUrls: ['./linux-group-nas.component.scss']
})
export class LinuxGroupNasComponent implements OnInit {

  @Input() nasIndex: number = 0;
  @Input() currGroup: number = 0;
  @Output() hasChanged = new EventEmitter();

  @Input()
  isHudson : boolean;
  @Input()
  isRochelle : boolean;

  _serverConfig: ServerConfig;
  nasTemplate: LinuxGroupNas;
  groupTemplate: LinuxGroupTemplate;

  nasMountOptions = [
    {value: 'yes', viewValue: 'Yes'},
    {value: 'no', viewValue: 'No'}
  ];

  mountTypeOptions= [
    {value: 'nfs', viewValue: 'NFS'},
    {value: 'cifs', viewValue: 'CIFS'}
  ];

  hudsonFilerOptions = ['gl-0185-unas51t', 'gl-9185-unas63t', 'gl-0185-unas01p', 'gl-0185-unas21p',
                        'gl-9185-unas68p'];

  rochelleFilerOptions = ['mw-0775-unas51t', 'mw-9775-unas63t', 'mw-0775-cnas00p-03', 'mw-0775-unas01p',
                          'mw-0775-unas21p', 'mw-9775-unas68p' ];


  constructor( private _linuxService: LinuxService ) { 
     this.groupTemplate = new LinuxGroupTemplate();
     this.nasTemplate = new LinuxGroupNas();
  }

  ngOnInit(){
     this._serverConfig = this._linuxService._serverConfig;
     this.groupTemplate = this._serverConfig.getGroup(this.currGroup);
     this.nasTemplate = this.groupTemplate.getNas(this.nasIndex);
     if(this.groupTemplate.osType === "win")
        this.nasTemplate.mount_type = "cifs";
     else
        this.nasTemplate.mount_type = "nfs";
  }

  ngAfterViewInit() {
  }

  onChange() {
     if( this.validateTemplate() )
        this.hasChanged.emit(this.nasTemplate);
  }

  validateTemplate() : boolean {
    return true;
  }

}
