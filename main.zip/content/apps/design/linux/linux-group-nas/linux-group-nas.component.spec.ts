import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxGroupNasComponent } from './linux-group-nas.component';

describe('LinuxGroupNasComponent', () => {
  let component: LinuxGroupNasComponent;
  let fixture: ComponentFixture<LinuxGroupNasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxGroupNasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxGroupNasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
