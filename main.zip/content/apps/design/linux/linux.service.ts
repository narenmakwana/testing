import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { LinuxGroupTemplate } from '../../../../shared/models/linux-group-template';
import { ServerConfig } from '../../../../shared/models/server-config';
import { Observable } from 'rxjs';
import { ResponseResult } from '../../../../shared/models/response-result';
import { Subject, BehaviorSubject } from 'rxjs';
import { Constants } from '../../../../shared/config/constants';
import { UditUtils } from '../../../../../core/uditUtils';
import { AuthenticationService } from '../../../pages/authentication/authentication.service';

@Injectable()
export class LinuxService {

  _serverConfig: ServerConfig;
  _responseResults: ResponseResult;

  constructor(private http: HttpClient, private _authenticationService: AuthenticationService) {

  }

  get serverConfig(): ServerConfig {
    return this._serverConfig;
  }

  setServerConfig(serverConfig: ServerConfig): void {
    this._serverConfig = serverConfig;
  }

  createServerConfig(): ServerConfig {
    this._serverConfig = new ServerConfig();
    return this._serverConfig;
  }

  createServerConfigFromExisting(config: any): ServerConfig {
    this._serverConfig = new ServerConfig(config);
    return this._serverConfig;
  }

  public getServerConfigById(id: string): Promise<any> {
    return this.http.get(Constants.getLinuxDesignUrl() + "/" + id)
      .toPromise()
      .then(this.getServerDetails)
      .catch(this.handleError);
  }

  querySoftwareProducts(query): Promise<string[]> {
    return new Promise((resolve, reject) => {
      this.getSoftwareProducts().then((resp) => {
        var appArr = resp.result;
        if (query) {
          appArr = appArr.filter(this._createFilterFor(query))
        }
        resolve(appArr);
      }, function () {
        reject();
      });
    });
  };

  public getVropHudsonOptions(): Promise<any> {
    return this.http.get(Constants.getVropsHudsonUrl())
      .toPromise()
      .then(this.getVropHudsonDetails)
      .catch(this.handleError);
  }

  getVropHudsonDetails(_response: Response): any {
    let body = _response;

    return body || {};
  }

  public getVropHudsonProps(query: string): Promise<any> {
    let httpParams = new HttpParams({
      fromString: query
    });
    return this.http.get(Constants.getVropsHudsonPropsUrl(), { params: httpParams })
      .toPromise()
      .then(this.getVropHudsonDetails)
      .catch(this.handleError);
  }

  public getVropRochelleOptions(): Promise<any> {
    return this.http.get(Constants.getVropsRochelleUrl())
      .toPromise()
      .then(this.getVropRochelleDetails)
      .catch(this.handleError);
  }

  public getVropRochelleProps(query: string): Promise<any> {
    let httpParams = new HttpParams({
      fromString: query
    });
    return this.http.get(Constants.getVropsRochellePropsUrl(), { params: httpParams })
      .toPromise()
      .then(this.getVropRochelleDetails)
      .catch(this.handleError);
  }

  getVropRochelleDetails(_response: Response): any {
    let body = _response;

    return body || {};
  }

  public getCMDBBusinessUnits(): Promise<any> {
    return this.http.get(Constants.getBusUnitsUrl())
      .toPromise()
      .then(this.getCMDBBusUnitDetails)
      .catch(this.handleError);
  }

  getCMDBBusUnitDetails(_response: Response): any {
    let body = _response;

    return body || {};
  }

  public getSoftwareProducts(): Promise<any> {
    return this.http.get(Constants.getSoftwareProductsUrl())
      .toPromise()
      .then(this.getSoftwareProductDetails)
      .catch(this.handleError);
  }

  getSoftwareProductDetails(_response: Response): any {
    let body = _response;

    return body || {};
  }

  public getBusDcio(): Promise<any> {
    return this.http.get(Constants.getBusDcioUrl())
      .toPromise()
      .then((response) => {
        return response;
      })
      .catch(this.handleError);
  }

  public getBusSupportingOrgs(): Promise<any> {
    return this.http.get(Constants.getBusSupportingOrgsUrl())
      .toPromise()
      .then((response) => {
        return response;
      })
      .catch(this.handleError);
  }

  public getBusAreas(): Promise<any> {
    return this.http.get(Constants.getBusAreasUrl())
      .toPromise()
      .then((response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getServerDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  public saveServerConfig(serverConfig: ServerConfig): Promise<any> {
    // This is a new config we are saving. Since this is new config
    // we want to make sure that we don't pass the _id and __v to mongo.
    //      delete this.Cell.__v;
    //      delete this.wasCell._id;
    // First check to see if this cell already exists.  
    var id = serverConfig._id;
    delete serverConfig._id;
    if (id) {
      return this.http.put(Constants.getLinuxDesignUrl() + "/" + id, serverConfig)
        .toPromise()
        .then(this.saveServerConfigDetails)
        .catch(this.handleError);
    }
    else {
      return this.http.post(Constants.getLinuxDesignUrl(), serverConfig)
        .toPromise()
        .then(this.saveServerConfigDetails)
        .catch(this.handleError);
    }
  }

  _createFilterFor = function (query) {
    return function filterFn(state) {
      return (('' + state).toLowerCase().match(query.toLowerCase()));
      //   	return ((''+state).match(query));
    }
  }

  queryNetworkLocations(query): string[] {
    var networkArr = this.getDesignLocations();
    if (query) {
      networkArr = networkArr.filter(this._createFilterFor(query));
    }
    return networkArr;
  }

  queryVirtHostOptions(query): string[] {
    var hostOptions = this.getVirtHostOptions();
    if (query) {
      hostOptions = hostOptions.filter(this._createFilterFor(query));
    }
    return hostOptions;
  }

  querySMSUsageOptions(query): string[] {
    var usageOptions = this.getSMSUsageOptions();
    if (query) {
      usageOptions = usageOptions.filter(this._createFilterFor(query));
    }
    return usageOptions;
  }

  queryOsOptions(query, os): string[] {
    var osOptions = this.getOsOfferingOptions(os);
    if (query) {
      osOptions = osOptions.filter(this._createFilterFor(query));
    }
    return osOptions;
  }

  queryPrimaryServerFunctions(query): string[] {
    var serverFuncs = this.getServerFunctions();
    if (query) {
      serverFuncs = serverFuncs.filter(this._createFilterFor(query));
    }
    return serverFuncs;
  }

  getServerFunctions(): string[] {
    return ["app", "dbs", "web", "acs", "adc", "agt", "alc", "all", "avs", "bkp", "cdr", "cdt", "cna", "cnt", "cof", "dfr", "dsm",
      "dtr", "eih", "esm", "fil", "frs", "gld", "hod", "int", "inv", "ivr", "lxv", "mad", "mco", "mmq", "nms", "nrs", "prt", "prx",
      "res", "sbi", "smd", "sna", "sos", "swd", "trs", "vap", "vis", "vmw", "vrs", "vsh", "wts", "xap",
      "xfx", "xgw", "xim", "xjn", "xnf", "xpf", "xpo"];
  }

  getOsOfferingOptions(os): string[] {
    if (os === "win")
      return ["2012", "2016"];
    else
      return ["rhel6", "rhel7"];
  }

  getSMSUsageOptions(): string[] {
    return ["Dev",
      "Dev-Claims",
      "Dev-PCI",
      "Early Adapter-Claims",
      "Early Adaptor",
      "Early Adaptor-PCI",
      "ETest",
      "MyND-PPro",
      "MyND-Prod",
      "MyND-Test",
      "Non-Production",
      "Pre-Production",
      "Pre-Production-Claims",
      "Pre-production-PCI",
      "Production Week 1",
      "Production Week 1-Claims",
      "Production Week 2",
      "Production Week 2-Claims",
      "Production Week 3(DC-NRS)",
      "Production Week 3(DC-NRS)-Claims",
      "Production Week 3(DC-NRS)-PCI",
      "Production Week 1-PCI",
      "Production Week 2-PCI",
      "Staging",
      "Staging-Claims",
      "Staging-PCI",
      "Test",
      "Test-Claims",
      "Test-PCI"
    ];
  }

  getVirtHostOptions(): string[] {
    return ["test/dev/pre-pro",
      "pre-pro",
      "production",
      "apn",
      "dmz",
      "tibco-test",
      "dev-was",
      "prod-was",
      "future deployment",
      "management",
      "aor production test",
      "prod-citrix",
      "test-citrix",
      "data protection services",
      "temp poc",
      "spod"
    ]
  }

  getDesignLocations(): string[] {
    return ["AD_Hudson",
      "AD_Rochelle",
      "ADPZ_Hudson",
      "ADPZ_Rochelle",
      "AllEXTZONES_Hudson",
      "AllEXTZONES_Rochelle",
      "AllMPNZones",
      "AllMPNZones_Hudson",
      "AllMPNZones_Rochelle",
      "AllPCIZones_Hudson",
      "AllPCIZones_Rochelle",
      "Backup",
      "collab_Hudson",
      "collab_Rochelle",
      "DMZ VIP-Internal",
      "DMZ_AccessMgmt_Hudson",
      "DMZ_AccessMgmt_Hudson_Pub",
      "DMZ_AccessMgmt_Rochelle",
      "DMZ_AccessMgmt_Rochelle_Pub",
      "DMZ_AllstateVendorPortal_Hud_Pub",
      "DMZ_AllstateVendorPortal_Hud_Pvt",
      "DMZ_AllstateVendorPortal_Roc_Pub",
      "DMZ_AllstateVendorPortal_Roc_Pvt",
      "DMZ_APN_Hudson",
      "DMZ_APN_Rochelle",
      "DMZ_CsExternal_Hudson",
      "DMZ_CsExternal_Rochelle",
      "DMZ_CsInternal_Hudson",
      "DMZ_CsInternal_Rochelle",
      "DMZ_Device_Mngmnt_Hudson",
      "DMZ_DevQaTpt_Hudson",
      "DMZ_DevQaTpt_Rochelle",
      "DMZ_EmailInternet_Hudson",
      "DMZ_EmailInternet_Rochelle",
      "DMZ_EmailIntranet_Rochelle",
      "DMZ_Enterprise_Hudson",
      "DMZ_Enterprise_Hudson_Pub",
      "DMZ_Enterprise_Rochelle",
      "DMZ_Extranet_Hudson",
      "DMZ_Extranet_Northbrook",
      "DMZ_IMT_Hudson",
      "DMZ_IMT_Rochelle",
      "DMZ_INET_DevQaTPT_Hudson",
      "DMZ_INET_DevQaTPT_Rochelle",
      "DMZ_Internet_Dallas",
      "DMZ_Internet_Hudson",
      "DMZ_Internet_Northbrook",
      "DMZ_Ivantage_Dallas",
      "DMZ_MPNX_Pub_Hudson",
      "DMZ_MPNX_Pub_Rochelle",
      "DMZ_MPNX_Pvt_Hudson",
      "DMZ_MPNX_Pvt_Rochelle",
      "DMZ_NRG_Dallas",
      "DMZ_NRG_Hudson",
      "DMZ_NRG_Rochelle",
      "DMZ_Other",
      "DMZ_PCI_Hudson",
      "DMZ_PCI_Rochelle",
      "DMZ_Proxy_Pub_Rochelle",
      "DMZ_TamExternal_Hudson",
      "DMZ_TamExternal_Rochelle",
      "DMZ_TamInternal_Hudson",
      "DMZ_TamInternal_Rochelle",
      "DMZ_TptDevQa_Hudson",
      "DMZ_TptDevQa_Rochelle",
      "DMZ_Vendor_Hudson",
      "DMZ_Vendor_Hudson_Pub",
      "DMZ_Vendor_Rochelle",
      "DMZ_Vendor_Rochelle_Pub",
      "DMZ_Webmail_Rochelle",
      "ESX_Storage",
      "Extranet DMZ - NON SLB",
      "Extranet DMZ – SLB",
      "Fault_Tolerance",
      "glic-revproxy",
      "glic-tpt-revproxy",
      "Internet DMZ - NON SLB",
      "IP_Storage",
      "MPN",
      "MPN_DatabaseServers_Hudson",
      "MPN_DatabaseServers_Rochelle",
      "MPN_DevQaTpt_Hudson",
      "MPN_DevQaTpt_Rochelle",
      "MPN_Isonet_Hudson",
      "MPN_Isonet_Rochelle",
      "MPN_Other_Hudson",
      "MPN_Other_Northbrook",
      "MPN_Other_Rochelle",
      "MPN_SystemManagement_Hudson",
      "MPN_SystemManagement_Rochelle",
      "MPN_WebServers_Hudson",
      "MPN_WebServers_Rochelle",
      "N/A (for Tier 0 Servers)",
      "OPENAPI_DMZ_HUDSON",
      "OPENAPI_DMZ_ROCHELLE",
      "OPENAPI_MPN_HUDSON",
      "OPENAPI_MPN_ROCHELLE",
      "PCI-Backup",
      "PCI-Common-Test_Hudson",
      "PCI-Common-Test_Rochelle",
      "PCI-Common_Hudson",
      "PCI-Common_Rochelle",
      "PCI-Private_Hudson",
      "PCI-Private_Rochelle",
      "PXE",
      "rdc-revproxy",
      "rdc-tpt-revproxy",
      "rdc-tpt-revproxy-pvt",
      "Reserved",
      "Service Console",
      "Sysman_Hudson",
      "Sysman_Rochelle",
      "Vmotion"];
  };


  saveServerConfigDetails(_response: Response): any {
    let body = _response;
    return body || {};
  }

  getUser(username: string): Promise<any> {
    // Using the shorthand arrow function here...What it does is basically make sure that
    // 'this' is pointing to te outer _router defined in constructor instead of using a 
    // local function this.
    return this._authenticationService.getUser(username)
      .then(this.getUserResults)
      .catch(this.handleUserError);
  }

  getUserResults(_response: Response): any {
    let body = _response;
    return body || {};
  }


  getServerDesigns(httpParams): Promise<any> {
    return this.http.get(Constants.getLinuxDesignUrl(), { params: httpParams })
      .toPromise()
      .then(this.serverDesignSearchResults)
      .catch(this.handleError);
  }

  serverDesignSearchResults(_response: Response): any {
    let body = _response;
    return body || {};
  }

  private handleUserError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  }

  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  }

}
