import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { ServerConfig } from '../../../../../shared/models/server-config';
import { LinuxGroupTemplate } from '../../../../../shared/models/linux-group-template';
import {LinuxService} from '../linux.service';

@Component({
  selector: 'c-linux-summary',
  templateUrl: './linux-summary.component.html',
  styleUrls: ['./linux-summary.component.scss']
})
export class LinuxSummaryComponent implements OnInit {

  @Input() _serverConfig : ServerConfig;

  constructor( private _linuxService: LinuxService ) { 
     this._serverConfig = _linuxService.serverConfig;
  }

   ngOnInit() {
  }

}
