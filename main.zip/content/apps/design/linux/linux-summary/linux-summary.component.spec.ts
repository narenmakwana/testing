import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxSummaryComponent } from './linux-summary.component';

describe('LinuxSummaryComponent', () => {
  let component: LinuxSummaryComponent;
  let fixture: ComponentFixture<LinuxSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
