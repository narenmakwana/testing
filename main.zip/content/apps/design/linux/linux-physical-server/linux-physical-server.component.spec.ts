import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxPhysicalServerComponent } from './linux-physical-server.component';

describe('LinuxPhysicalServerComponent', () => {
  let component: LinuxPhysicalServerComponent;
  let fixture: ComponentFixture<LinuxPhysicalServerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxPhysicalServerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxPhysicalServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
