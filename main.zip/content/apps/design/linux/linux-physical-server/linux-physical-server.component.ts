import { Component, AfterViewInit, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { ServerConfig } from '../../../../../shared/models/server-config';
import { LinuxGroupTemplate } from '../../../../../shared/models/linux-group-template';
import { LinuxGroupPhysical } from '../../../../../shared/models/linux-group-physical';
import { LinuxService } from '../linux.service';

@Component({
  selector: 'app-linux-physical-server',
  templateUrl: './linux-physical-server.component.html',
  styleUrls: ['./linux-physical-server.component.scss']
})
export class LinuxPhysicalServerComponent implements OnInit {

  @Input() physicalIndex: number = 0;
  @Input() currGroup: number = 0;
  @Output() hasChanged = new EventEmitter();
  @Output() groupIndex: number = 0;
  @Output() physicalTeam: number = 0;
  @Output() phyIdx: number = 0;

  @Input() isHudson: boolean;
  @Input() isRochelle: boolean;

  _serverConfig: ServerConfig;
  physTemplate: LinuxGroupPhysical;
  groupTemplate: LinuxGroupTemplate;

  constructor(private _linuxService: LinuxService) {
    this.groupTemplate = new LinuxGroupTemplate();
    this.physTemplate = new LinuxGroupPhysical();
  }

  ngOnInit() {
    this._serverConfig = this._linuxService._serverConfig;
    this.groupTemplate = this._serverConfig.getGroup(this.currGroup);
    this.groupIndex = this.currGroup;
    this.physTemplate = this.groupTemplate.getPhysical(this.physicalIndex);
    this.phyIdx = this.physicalIndex;
  }

  ngAfterViewInit() {
  }

  onChange() {
    if (this.validateTemplate())
      this.hasChanged.emit(this.physTemplate);
  }

  isCustom(): boolean {
    return this.groupTemplate.local_dasd.dasd_spec === 'cst';
  }

  showRemoveTeam(currIndex: number): boolean {
    if (currIndex >= 0) {
      if (this.physTemplate.networkTeamConfig.length > 0) return true;
      else return false;
    } else {
      return false;
    }
  }

  addNewTeam() {
    console.log('Adding Team..');
    let newTeam = this.physTemplate.addTeam();
    this.groupTemplate.physical.networks = this.physTemplate.networkTeamConfig.length;
  }

  removeTeam(currIndex) {
    console.log('Removing Team..', currIndex);
    this.physTemplate.removeTeam(currIndex);
    this.groupTemplate.physical.networks = this.physTemplate.networkTeamConfig.length;
  }

  validateTemplate(): boolean {
    return true;
  }

}
