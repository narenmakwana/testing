import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server-backup',
  templateUrl: './server-backup.component.html',
  styleUrls: ['./server-backup.component.scss']
})
export class ServerBackupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
