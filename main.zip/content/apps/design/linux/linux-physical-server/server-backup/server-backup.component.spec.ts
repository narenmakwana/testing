import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServerBackupComponent } from './server-backup.component';

describe('ServerBackupComponent', () => {
  let component: ServerBackupComponent;
  let fixture: ComponentFixture<ServerBackupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServerBackupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServerBackupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
