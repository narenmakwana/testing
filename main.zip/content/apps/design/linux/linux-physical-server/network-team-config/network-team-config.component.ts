import { Component, AfterViewInit, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { ServerConfig } from '../../../../../../shared/models/server-config';
import { LinuxGroupTemplate } from '../../../../../../shared/models/linux-group-template';
import { LinuxGroupPhysical, LinuxGroupPhysicalTeam, LinuxGroupPhysicalSE } from '../../../../../../shared/models/linux-group-physical';
import { LinuxService } from '../../linux.service';
import { MatRadioChange } from '@angular/material/radio';

@Component({
  selector: 'app-network-team-config',
  templateUrl: './network-team-config.component.html',
  styleUrls: ['./network-team-config.component.scss']
})

export class NetworkTeamConfigComponent implements OnInit {

  @Input() physicalTeam: number = 0;
  @Input() groupIndex: number = 0;
  @Input() phyIndex: number = 0;
  @Output() hasChanged = new EventEmitter();

  _serverConfig: ServerConfig;
  
  physTemplate: LinuxGroupPhysical;
  teamTemplate: LinuxGroupPhysicalTeam;
  groupTemplate: LinuxGroupTemplate;

  nicSelections: string[] = ['1', '10'];
  pri_interface: string[] = [];
  sec_interface: string[] = [];

  constructor(private _linuxService: LinuxService) {
    this.groupTemplate = new LinuxGroupTemplate();
    this.physTemplate = new LinuxGroupPhysical();
    this.teamTemplate = new LinuxGroupPhysicalTeam();
  }

  ngOnInit() {
    this._serverConfig = this._linuxService._serverConfig;
    this.groupTemplate = this._serverConfig.getGroup(this.groupIndex);
    this.physTemplate = this.groupTemplate.getPhysical(this.phyIndex);
    this.teamTemplate = this.physTemplate.getTeam(this.physicalTeam);
    this.populatePriSecInterfaces(this.teamTemplate.net_type);
  }

  ngAfterViewInit() {
  }

  nicChanged(event: MatRadioChange) {
    this.populatePriSecInterfaces(event.value);
  }

  populatePriSecInterfaces(net_type): void {
    // First check to see the number of 1GB and 10GB nics. 
    // Depending on that number, we need to populate the primary and secondary interfaces.
    this.pri_interface = [];
    this.sec_interface = [];
    if (net_type === "1") {
      // 1 GB Selected
      if (this.groupTemplate.physical.num_nic_1gb > 0) {
        for (let i = 0; i < this.groupTemplate.physical.num_nic_1gb; i++) {
          let nic = "1gbnic" + i;
          this.pri_interface.push(nic);
          this.sec_interface.push(nic);
        }
      }
    } else {
      // 10 GB Nic Selected.
      if (this.groupTemplate.physical.num_nic_10gb > 0) {
        for (let i = 0; i < this.groupTemplate.physical.num_nic_10gb; i++) {
          let nic = "10gbnic" + i;
          this.pri_interface.push(nic);
          this.sec_interface.push(nic);
        }
      }
    }
  }

  onChange() {
    if (this.validateTemplate())
      this.hasChanged.emit(this.physicalTeam);
  }

  validateTemplate(): boolean {
    return true;
  }
}
