import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NetworkTeamConfigComponent } from './network-team-config.component';

describe('NetworkTeamConfigComponent', () => {
  let component: NetworkTeamConfigComponent;
  let fixture: ComponentFixture<NetworkTeamConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NetworkTeamConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NetworkTeamConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
