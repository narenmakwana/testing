import { Component, OnInit, Output } from '@angular/core';
import { LinuxGroupTemplate } from '../../../../shared/models/linux-group-template';
import { ServerConfig } from '../../../../shared/models/server-config';
import { LinuxService } from './linux.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialogRef, MatDialog } from '@angular/material';
import { InputDialog } from '../../../../shared/components/input-dialog.component';
import { DialogService } from '../../../../shared/services/dialog.service';


@Component({
  selector: 'c-linux',
  templateUrl: './linux.component.html',
  styleUrls: ['./linux.component.scss']
})
export class LinuxComponent implements OnInit {

  @Output()
  _serverConfig: ServerConfig;
  showGroup: boolean = false;

  public selectedIndex: number = 0;

  @Output() groupIndex: number = 0;
  @Output() ID: string;


  projectStatusOptions = [
    { value: 'draft', viewValue: 'Draft' },
    { value: 'final', viewValue: 'Final' }
  ];

  public result: any;
  private _results: { success: boolean, data?: { inputField: string } } = { success: false };
  private _dialogRef: MatDialogRef<InputDialog>;

  constructor(protected _router: Router, private _activeRoute: ActivatedRoute, private _linuxService: LinuxService,
    private _dialog: MatDialog, private dialogService: DialogService) {
    this._serverConfig = _linuxService.createServerConfig();
  }

  // Subscribe to the change in the route parameters. We want to know if the route contains the ID of the cell.
  ngOnInit() {
    this._activeRoute.params.subscribe(this.onParamChange.bind(this));
  }

  // We got here when a user selected a cell to be edited. So we get the cell details
  // from the database and then initiaze the models with this data.
  onParamChange(params: any) {
    if (params['id']) {
      // Retrieve the document here.
      this._linuxService.getServerConfigById(params['id']).catch(this.handleError.bind(this))
        .then(this.handleSuccess.bind(this));
    }
  }

  // Edit  Being Handled here. We need to load the existing 
  // data here. The data coming from database does not have everything
  // which is needed by the object to be initialized. So we need to instantiate
  // a new object.
  handleSuccess(_serverCfg: any) {
    this.ID = _serverCfg._id;
    this._serverConfig = this._linuxService.createServerConfigFromExisting(_serverCfg);

  }

  handleError(error) {
    console.log("Got Error in Getting linux server Data")
  }


  validateProjectInfo(): boolean {
    return (true);
  }

  processProjectName(name: any) {

    let dcioidx = name.indexOf("-");
    this._serverConfig.dcio = name.slice(0, dcioidx); // dcio
    let deptidx = name.indexOf("-", dcioidx + 1);
    this._serverConfig.dept = name.slice(dcioidx + 1, deptidx);
    let tseridx = name.indexOf("-", deptidx + 1);
    this._serverConfig.pmt_num = name.slice(deptidx + 1, tseridx);
    this._serverConfig.rc_num = this._serverConfig.pmt_num;
    let descidx = name.indexOf("-", tseridx + 1);
    this._serverConfig.proj_desc = name.slice(tseridx + 1);
  }

  canMove(index: number): boolean {
    switch (index) {
      case 0:
        return true;
      case 1:
        return this.validateProjectInfo();
      case 2:
        return this.canMove(1);
      default:
        return true;
    }
  }

  validateDesign(): boolean {
    return true;
  }

  next(): void {

    if (this.selectedIndex === 1) {
      if (!this.validateDesign()) {
        let message = "We noticed that your design contains errors";

        this.dialogService
          .ok("Warning: Validate Design", message)
          .subscribe(res => this.result = res);
      }
    }

    if (this.canMove(this.selectedIndex + 1)) {
      this.selectedIndex++;
    }
  }

  previous(): void {
    if (this.canMove(this.selectedIndex - 1)) {
      this.selectedIndex--;
    }
  }

  addGroup() {
    this.showGroup = !this.showGroup;
  }

  showRemoveGroup(currIndex: number): boolean {
    if (currIndex >= 1) {
      return true;
    }
    else {
      return false;
    }
  }

  finish(): void {
    //    this._serverConfig.validate();
    this._linuxService.saveServerConfig(this._serverConfig).catch(this.handleSaveError.bind(this))
      .then(this.handleSaveSuccess.bind(this));
  }

  handleSaveError(error: string) {
    console.log("Error Encountered..", error);
  }

  handleSaveSuccess(resp: Response) {
    this._router.navigate(['apps/design/linux-list',
      {
        project_name: this._serverConfig.project_name,
        limit: 20
      }]);
  }

  groupChanged(_group: LinuxGroupTemplate, _selectedGroup: number): void {
    // Save each group in the correct index.
    this._serverConfig.setGroup(_selectedGroup, _group);
  }
}
