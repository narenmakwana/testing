import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxListComponent } from './linux-list.component';

describe('LinuxListComponent', () => {
  let component: LinuxListComponent;
  let fixture: ComponentFixture<LinuxListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
