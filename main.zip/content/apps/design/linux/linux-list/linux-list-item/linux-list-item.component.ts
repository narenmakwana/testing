import { Component, OnInit, Input } from '@angular/core';
import {ServerConfig} from '../../../../../../shared/models/server-config';
import {DialogService} from '../../../../../../shared/services/dialog.service';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {LinuxWorkflowService} from '../../../../../../shared/services/linux-workflow.service';
import {Response} from '@angular/http';
import {LinuxService} from '../../linux.service';

@Component({
  selector: 'c-linux-list-item',
  templateUrl: './linux-list-item.component.html',
  styleUrls: ['./linux-list-item.component.scss']
})
export class LinuxListItemComponent implements OnInit {

  @Input() serverData : ServerConfig;
  projectSelected: boolean;
  public result: any;

  constructor( protected _router: Router, private _linuxWorkflow: LinuxWorkflowService, private dialogService: DialogService, protected _linuxService: LinuxService ) { 
      this.serverData = new ServerConfig();
  }

  ngOnInit() {
  }

  editProject() {
     this._router.navigate(['apps/design/linux', this.serverData._id]);
  }

  cloneProject() {
     this.serverData = this._linuxService.createServerConfigFromExisting(this.serverData);
     this.serverData.project_name = ""; // blankout the project name
     // delete the ID from here because we want to create a new project.
     delete this.serverData._id;
     this._linuxService.saveServerConfig(this.serverData).catch(this.handleSaveError.bind(this))
                                                           .then(this.handleSaveSuccess.bind(this));
  }
  
  handleSaveError(error: string){
      console.log("Error Encountered..", error);
  }

  handleSaveSuccess(resp: any) {
     var id = resp._id;
     this._router.navigate(['apps/design/linux', id]);
  }

 handleSuccess() {
     this._router.navigate(['apps/search/linux-jobs-search-results', 
              { project_name: this.serverData.project_name, 
                product: 'linux',
                limit: 20
              }]);
  }

  handleError(error) {
    this.dialogService
      .ok('Error Deploying Project '+this.serverData.project_name, ' Error:' + error)
      .subscribe(res => this.result = res);
  }

  deployProject() {
    this.dialogService
      .confirm('Deploy Project '+this.serverData.project_name, 'Please click OK to proceed with deploying project.')
      .subscribe(res => {
          this.result = res;
          this._linuxWorkflow.deployProject(this.serverData).then(this.handleSuccess.bind(this))
                                                            .catch(this.handleError.bind(this));
                                                            
      });
  }

}
