import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxListItemComponent } from './linux-list-item.component';

describe('LinuxListItemComponent', () => {
  let component: LinuxListItemComponent;
  let fixture: ComponentFixture<LinuxListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
