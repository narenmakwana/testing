import {LinuxService} from '../linux.service';
import { Observable } from 'rxjs/Observable';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {OnInit, Component, Input} from '@angular/core';
import { ResponseResult } from '../../../../../shared/models/response-result';
import { Subscription } from "rxjs/Rx";
import {UditUtils}  from '../../../../../../core/uditUtils';
import { HttpClient, HttpParams } from '@angular/common/http';

interface IProjectSelected {
    project_name : string;
    checked : boolean;
}

@Component({
  selector: 'c-linux-list',
  templateUrl: './linux-list.component.html',
  styleUrls: ['./linux-list.component.scss']
})
export class LinuxListComponent implements OnInit {

  responseResults: ResponseResult;
  _params : Observable<any>;
  private subscription: Subscription;
  private searchsub : Subscription;

  private project_name: string = "";
  private pmt_num: string = "";
  private rc_num: string = "";

  private params: string[];
  private limit: number;
  private offset: number;
  
  selectedProjects : string[] = [];
  
  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected route: ActivatedRoute, protected _linuxService: LinuxService ) { 
       this.responseResults = new ResponseResult();
  }

  ngOnInit() { 
    // subscribe to router event
    this.subscription = this.route.params
      .subscribe((params: Params) => {
        this.project_name = params['project_name'];
        this.pmt_num = params['pmt_num'];
        this.rc_num = params['rc_num'];
        this.limit = +params['limit'];
    });

    this.getPage(1);
  }

  search(limit: number, page : number){
     // calculate the offset based on page number and limit.
     var offset = (page - 1) * limit;
     var paramObj = {
         "project_name.contains": this.project_name,
         "rc_num.contains" : this.rc_num,
         "pmt_num.contains" : this.pmt_num,
         "limit": limit,
         "offset" : offset
     };

     var paramString = UditUtils.buildQueryParams(paramObj);
     let httpParams = new HttpParams({
       fromString: paramString
     });

     this._linuxService.getServerDesigns(httpParams)
                          .then((data)=>{
                            this.responseResults = data;
                            this.total = this.responseResults.total;
                            this.p = page;
                            this.loading = false;
                          });
  }

  getPage(page: number) {
      this.loading = true;
      this.search(this.limit, page);
  }

  handleProjectSelection(event : IProjectSelected) {
    if( event.checked ) {
        // add the cellname to the list of selected cells.
        this.selectedProjects.push(event.project_name);
    }
    else {
            // the cell is deselected. check to see if it exists in our list of selected cells 
            // if it exists, then remove it from that list.
            for(let i = 0; i < this.selectedProjects.length; i++) {
                if(this.selectedProjects[i] === event.project_name) {
                    // found it. remove it from the list.
                    this.selectedProjects.splice(i, 1);
                }
            }
        }
    }
}
