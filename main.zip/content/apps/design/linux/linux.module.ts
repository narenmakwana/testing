import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { LinuxComponent } from './linux.component';
import { LinuxListComponent } from './linux-list/linux-list.component';
import { LinuxGroupComponent } from './linux-group/linux-group.component';
import { LinuxGroupNasComponent } from './linux-group-nas/linux-group-nas.component';
import { LinuxListItemComponent } from './linux-list/linux-list-item/linux-list-item.component';
import { LinuxSummaryComponent } from './linux-summary/linux-summary.component';
import { AuthenticationService } from '../../../pages/authentication/authentication.service';
import { LinuxService } from './linux.service';
import { LinuxPhysicalServerComponent } from './linux-physical-server/linux-physical-server.component';
import { NetworkTeamConfigComponent } from './linux-physical-server/network-team-config/network-team-config.component';
import { ServerBackupComponent } from './linux-physical-server/server-backup/server-backup.component';

const routes: Routes = [
  {
    path: 'design/linux-list',
    component: LinuxListComponent
  },
  {
    path: 'design/linux',
    component: LinuxComponent
  },
  {
    path: 'design/linux/:id',
    component: LinuxComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    NgxPaginationModule,
    RouterModule.forChild(routes)
  ],
  declarations: [LinuxComponent, LinuxListComponent, LinuxGroupComponent, LinuxGroupNasComponent, LinuxListItemComponent,
    LinuxSummaryComponent,
    LinuxPhysicalServerComponent,
    NetworkTeamConfigComponent,
    ServerBackupComponent
  ],
  providers: [AuthenticationService, LinuxService
  ]
})
export class LinuxModule { }
