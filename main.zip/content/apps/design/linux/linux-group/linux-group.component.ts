import {
  Component,
  OnInit,
  AfterViewInit,
  Output,
  EventEmitter,
  ViewChild,
  Input,
  OnChanges,
  ElementRef
} from '@angular/core';

import { ServerConfig } from '../../../../../shared/models/server-config';
import { LinuxGroupTemplate } from '../../../../../shared/models/linux-group-template';
import { LinuxService } from '../linux.service';
import { LinuxGroupNasComponent } from '../linux-group-nas/linux-group-nas.component';
import { DialogService } from '../../../../../shared/services/dialog.service';


export class IVrop {
  id: string = '';
  deployable: string = '';
  name: string = '';
}

@Component({
  selector: 'c-linux-group',
  templateUrl: './linux-group.component.html',
  styleUrls: ['./linux-group.component.scss']
})
export class LinuxGroupComponent implements OnInit {
  groupTemplate: LinuxGroupTemplate;
  eccRestore: boolean = false;
  public result: any;

  @Input() groupIndex: number = 0;
  @Output() currGroup: number = 0;

  @Output() _serverConfig: ServerConfig;

  priServerWinOptions = [
    { value: 'ACS', viewValue: 'ACS – Access Control Serve' },
    { value: 'ADC', viewValue: 'ADC – Active Directory Connector' },
    {
      value: 'APP',
      viewValue: 'APP – Application (Proprietary and shared applications)'
    },
    { value: 'AVS', viewValue: 'AVS – Anti Virus Server' },
    { value: 'BKP', viewValue: 'BKP – Backup server' },
    { value: 'CDR', viewValue: 'CDR – CD ROM Server' },
    {
      value: 'DBS',
      viewValue: 'DBS – Database Server (generally Oracle or SQL)'
    },
    { value: 'DSM', viewValue: 'DSM – Distributed State Machine server' },
    { value: 'EIH', viewValue: 'EIH – Enterprise Integration Host server' },
    { value: 'EPH', viewValue: 'EPH – E*Gate Participating Host server' },
    { value: 'ERH', viewValue: 'ERH – E*Gate Registry Host server' },
    { value: 'ESM', viewValue: 'ESM – Enterprise Systems Management server' },
    { value: 'FIL', viewValue: 'FIL – File server' },
    { value: 'FRS', viewValue: 'FRS – Forest Root Server' },
    {
      value: 'GAW',
      viewValue: 'GAW – GeoTel Administrative Workstation server'
    },
    { value: 'GHD', viewValue: 'GHD – GeoTel Historical Data server' },
    { value: 'GIL', viewValue: 'GIL – GeoTel ICM Logger server' },
    { value: 'GIR', viewValue: 'GIR – GeoTel ICM Router server' },
    { value: 'GPG', viewValue: 'GPG – GeoTel Peripheral Gateway server' },
    { value: 'IVR', viewValue: 'IVR – Integrated Voice Response server' },
    { value: 'MCO', viewValue: 'MCO – Market Claims Office serverr' },
    { value: 'MMQ', viewValue: 'MMQ – Microsoft Message Queue server' },
    { value: 'MTS', viewValue: 'MTS – Microsoft Transaction Serverr' },
    { value: 'NMS', viewValue: 'NMS – Network Management Server' },
    { value: 'NRS', viewValue: 'NRS – Name Resolution Server' },
    { value: 'PRT', viewValue: 'PRT – Print Server' },
    { value: 'PRX', viewValue: 'PRX – Proxy Server' },
    { value: 'RES', viewValue: 'RES – Resource Domain Controller' },
    { value: 'SMD', viewValue: 'SMD – Systems Management Distribution server' },
    { value: 'SNA', viewValue: 'SNA – Systems Network Architecture server' },
    { value: 'TRS', viewValue: 'TRS – Tree Root Server' },
    { value: 'VRS', viewValue: 'VRS – Voice Recording Server' },
    { value: 'WEB', viewValue: 'WEB – Web server' },
    { value: 'WTS', viewValue: 'WTS – Windows Terminal Server' },
    { value: 'XBH', viewValue: 'XBH – Exchange Bridge Head server' },
    { value: 'XAP', viewValue: 'XAP – Exchange Application server' },
    { value: 'XCS', viewValue: 'XCS – Exchange Conferencing Server' },
    { value: 'XFX', viewValue: 'XFX – Exchange Fax server' },
    { value: 'XGW', viewValue: 'XGW – Exchange Gateway server' },
    { value: 'XIM', viewValue: 'XIM – Exchange Internet Mail server' },
    { value: 'XMS', viewValue: 'XMS – Exchange Monitor Server' },
    { value: 'XNF', viewValue: 'XNF – Exchange Infrastructure server' },
    { value: 'XPF', viewValue: 'XPF – Exchange Public Folder server' },
    { value: 'XPO', viewValue: 'XPO – Exchange Post Office server' },
    { value: 'XSC', viewValue: 'XSC – Exchange SNADS Connector server' }
  ];

  priServerLinuxOptions = [
    { value: 'lxv', viewValue: 'Linux Virtual (lxv)' },
    { value: 'lxe', viewValue: 'Linux Physical (lxe)' },
    { value: 'lxm', viewValue: 'Linux Server (lxm)' }
  ];

  envtTypeOptions = [];

  envtTypeWinOptions = [
    { value: 'Production', viewValue: 'Production' },
    { value: 'Continuity', viewValue: 'Continuity' },
    { value: 'Pre-Production', viewValue: 'Pre-Production' },
    { value: 'Development', viewValue: 'Development' },
    { value: 'Test', viewValue: 'Test' },
    { value: 'eTest', viewValue: 'eTest' },
    { value: 'Lab', viewValue: 'Lab' }
  ];

  envtTypeLinuxOptions = [
    { value: 'Production', viewValue: 'Production' },
    { value: 'Continuity', viewValue: 'Continuity' },
    { value: 'Pre-Production', viewValue: 'Pre-Production' },
    { value: 'Development', viewValue: 'Development' },
    { value: 'Test', viewValue: 'Test' },
    { value: 'Training', viewValue: 'Training' },
    { value: 'TPT', viewValue: 'TPT' },
    { value: 'eTest', viewValue: 'eTest' },
    { value: 'Lab', viewValue: 'Lab' }
  ];


  @Output() isHudson: boolean = true;
  @Output() isRochelle: boolean = false;
  showNas: boolean = true;
  invPriContact: boolean = false;
  invSecContact: boolean = false;
  invContact: boolean = false;

  networkCodes = [];
  virtHostOptions = [];
  smsUsageTypeOptions = [];
  osOfferings = [];
  primaryServerFunctions = [];
  cdcOptions = [];
  cdcResources = [];
  softwareProducts = [];
  cmdbBusUnits = [];
  groupOptions = [
    'group1',
    'group2',
    'group3',
    'group4',
    'group5',
    'group6',
    'group7',
    'group8'
  ];
  virtualHostOptions = ['production', 'test/dev/pre-pro'];
  puppetAddons = ['was::dev', 'was::prod'];

  maintWeekExceptions = ['', '1', '2', '3', '4'];
  priErrorMessage = 'Not a Valid ID or Group.';
  secErrorMessage = 'Not a Valid ID or Group.';
  errorMessage = 'Not a Valid ID or Group.';
  isProduction = true;
  /* usageTypeOptions = [ "Dev", "Dev-Claims", "Dev-PCI", "Early Adapter-Claims",  "Early Adaptor", "Early Adaptor-PCI", "ETest", "MyND-PPro",
             "MyND-Prod", "MyND-Test", "Non-Production", "Pre-Production", "Pre-Production-Claims", "Pre-production-PCI", "Production Week 1",
             "Production Week 1-Claims", "Production Week 2", "Production Week 2-Claims", "Production Week 3(DC-NRS)", "Production Week 3(DC-NRS)-Claims",
             "Production Week 3(DC-NRS)-PCI", "Production Week 1-PCI", "Production Week 2-PCI", "Staging", "Staging-Claims", "Staging-PCI",
             "Test", "Test-Claims", "Test-PCI"
           ]; */
  nonProdUsageTypeOptions = ['Non-Production'];
  prodUsageTypeOptions = ['Production Week 1', 'Production Week 2'];

  usageTypeOptions = [];

  dataCenterOptions = [
    { value: 'Rochelle', viewValue: 'Rochelle' },
    { value: 'Hudson', viewValue: 'Hudson' },
    { value: 'Northbrook', viewValue: 'Northbrook' },
    { value: 'Remote', viewValue: 'Remote' }
  ];

  dasdOptions = [
    { value: 'std', viewValue: 'Standard' },
    { value: 'cst', viewValue: 'Custom' }
  ];

  vendorOptions = [
    { value: 'DELL', viewValue: 'Dell' },
    { value: 'HP', viewValue: 'Hp' }
  ];

  sTypeOptions = [
    { value: 'R630', viewValue: 'R630' },
    { value: 'R730', viewValue: 'R730' },
    { value: 'R740', viewValue: 'R740' },
    { value: 'R930', viewValue: 'R930' },
    { value: 'R940', viewValue: 'R940' },
    { value: 'Dl380', viewValue: 'DL380' },
    { value: 'Bl460', viewValue: 'BL460' },
    { value: 'Dl560', viewValue: 'DL560' }
  ];


  serverTypeOptions = [
    { value: 'vmware', viewValue: 'Vmware' },
    { value: 'physical', viewValue: 'Physical' },
    { value: 'cloud', viewValue: 'Cloud' },
    { value: 'appliance', viewValue: 'Appliance' }
  ];

  mgmtLevelOptions = [
    { value: '24x7 Enterprise', viewValue: '24x7 Enterprise' },
    { value: '9x5 Enterprise', viewValue: '9x5 Enterprise' },
    { value: 'Hardware Only', viewValue: 'Hardware Only' }
  ];

  maintDaysOptions = [
    { value: 'Monday', viewValue: 'Monday' },
    { value: 'Tuesday', viewValue: 'Tuesday' },
    { value: 'Wednesday', viewValue: 'Wednesday' },
    { value: 'Thursday', viewValue: 'Thursday' },
    { value: 'Friday', viewValue: 'Friday' },
    { value: 'Saturday', viewValue: 'Saturday' },
    { value: 'Sunday', viewValue: 'Sunday' }
  ];

  osOptions = [
    { value: 'lin', viewValue: 'Linux' },
    { value: 'win', viewValue: 'Windows' }
  ];

  profileTypeOptions = [];

  profileTypeAllOptions = [
    { value: 'guibase', viewValue: 'Gui Base' },
    { value: 'base', viewValue: 'Base' },
    { value: 'guiapprole', viewValue: 'Gui App Role' },
    { value: 'guiapprolenodb', viewValue: 'Gui App Role No DB' },
    { value: 'corebase', viewValue: 'Core Base' },
    { value: 'coreapprole', viewValue: 'Core App Role' },
    { value: 'coreapprolenodb', viewValue: 'Core App Role No DB' }
  ];

  profileTypeWinOptions = [
    { value: 'guibase', viewValue: 'Gui Base' },
    { value: 'guiapprole', viewValue: 'Gui App Role' },
    { value: 'guiapprolenodb', viewValue: 'Gui App Role No DB' },
    { value: 'corebase', viewValue: 'Core Base' },
    { value: 'coreapprole', viewValue: 'Core App Role' },
    { value: 'coreapprolenodb', viewValue: 'Core App Role No DB' }
  ];

  profileTypeVmwareOptions = [{ value: 'base', viewValue: 'Base' }];

  storageTypeOptions = [
    { value: 'vmware', viewValue: 'VMware' },
    { value: 'physical', viewValue: 'Physical' },
    { value: 'cloud', viewValue: 'Cloud' }
  ];

  envtCodeOptions = [
    { value: 'A', viewValue: 'A – Windows Appliance' },
    { value: 'c', viewValue: 'C – Cluster Server' },
    { value: 'D', viewValue: 'D – Domain Controller' },
    { value: 'R', viewValue: 'R – Remote Access Device' },
    { value: 'S', viewValue: 'S – Member Server' },
    { value: 'T', viewValue: 'T – Terminal Server' },
    { value: 'V', viewValue: 'V – Virtual Resource' }
  ];

  netwCodeOptions = [
    { value: '0', viewValue: '0' },
    { value: '9', viewValue: '9' }
  ];

  cloudTypeOptions = [
    { value: 'AWS', viewValue: 'AWS' },
    { value: 'AZURE', viewValue: 'AZURE' },
    { value: 'GC', viewValue: 'Google Cloud' }
  ];

  netwLocOptions = [{ value: 'MPM', viewValue: 'MPM' }];

  maintWeekOptions = [];

  supportingOrgsOptions = [];

  maintWeekProdOptions = [
    { value: '1', viewValue: 'Week 1' },
    { value: '2', viewValue: 'Week 2' },
    { value: '3', viewValue: 'Week 3' },
    { value: '4', viewValue: 'Week 4' }
  ];

  maintWeekLinuxProdOptions = [
    { value: '2', viewValue: 'Week 2' },
    { value: '3', viewValue: 'Week 3' }
  ];

  maintWeekNonProdOptions = [{ value: '1', viewValue: 'Week 1' }];

  domainWinOptions = [
    { value: 'ad.allstate.com', viewValue: 'ad.allstate.com' }
  ];

  domainLinuxOptions = [{ value: 'allstate.com', viewValue: 'allstate.com' }];

  domainOptions = this.domainLinuxOptions;

  constructor(private _linuxService: LinuxService, private dialogService: DialogService) {
    this._serverConfig = new ServerConfig();
  }

  ngOnInit() {
    this._serverConfig = this._linuxService._serverConfig;
    this.groupTemplate = this._serverConfig.getGroup(this.groupIndex);
    this.currGroup = this.groupIndex;
    this.networkCodes = this._linuxService.getDesignLocations();

    if (this.groupTemplate.osType === 'win') {
      this.osOfferings = this._linuxService.queryOsOptions(
        '2',
        this.groupTemplate.osType
      );
      this.domainOptions = this.domainWinOptions;
      this.groupTemplate.network.domain = 'ad.allstate.com';
      this.primaryServerFunctions = this.priServerWinOptions;
      this.envtTypeOptions = this.envtTypeWinOptions;
      this.profileTypeOptions = this.profileTypeWinOptions;
    } else {
      this.osOfferings = this._linuxService.queryOsOptions(
        'r',
        this.groupTemplate.osType
      );
      this.domainOptions = this.domainLinuxOptions;
      this.groupTemplate.network.domain = 'allstate.com';
      this.primaryServerFunctions = this.priServerLinuxOptions;
      this.envtTypeOptions = this.envtTypeLinuxOptions;
      this.profileTypeOptions = this.profileTypeVmwareOptions;
    }

    this.onEnvironmentChange(this.groupTemplate.env_type);

    // get the business units right now.
    this._linuxService
      .getCMDBBusinessUnits()
      .catch(this.handleError.bind(this))
      .then(this.getCMDBBusUnitsResult.bind(this));
    this._linuxService
      .getSoftwareProducts()
      .catch(this.handleError.bind(this))
      .then(this.getSoftwareProducts.bind(this));

    if (this.groupTemplate.server.datacenter === 'Rochelle') {
      this._linuxService
        .getVropRochelleOptions()
        .catch(this.handleError.bind(this))
        .then(this.getVropResults.bind(this));
    } else {
      this._linuxService
        .getVropHudsonOptions()
        .catch(this.handleError.bind(this))
        .then(this.getVropResults.bind(this));
    }

    this._linuxService
      .getBusSupportingOrgs()
      .catch(this.handleError.bind(this))
      .then(this.getBusSupportingOrgResults.bind(this));

    // Save the data center in appliance too.
    this.groupTemplate.appliance.datacenter = this.groupTemplate.server.datacenter;
  }

  handleError(error) {
    console.log('Got Error in Getting WasCell Data');
  }

  // If the new Cell is saved, go to edit it now.
  getBusSupportingOrgResults(response: any) {
    //store the results in _serverConfi
    this.supportingOrgsOptions = [];
    // convert the result to json.
    var results = JSON.parse(response).result;
    results.forEach(item => {
      if (item.u_status === 'Active')
        this.supportingOrgsOptions.push(item.u_name);
    });
  }

  // If the new Cell is saved, go to edit it now.
  getCMDBBusUnitsResult(response: any) {
    //store the results in _serverConfi
    this._serverConfig.cmdbBusUnits = [];
    // convert the result to json.
    var results = JSON.parse(response).result;
    results.forEach(item => {
      if (item.u_ci_record_status === 'Active')
        this._serverConfig.cmdbBusUnits.push(item.name);
    });
    if (this._serverConfig.cmdbBusUnits)
      this.cmdbBusUnits = this._serverConfig.cmdbBusUnits;
  }

  getVropResults(response: any) {
    //store the results in _serverConfi
    this.cdcResources = [];
    var results = JSON.parse(response).resourceList;
    var urlparams = '';
    results.forEach(item => {
      if (item.resourceKey.name) {
        let obj = new IVrop();
        obj.id = item.identifier;
        obj.name = item.resourceKey.name;
        this.cdcResources.push(obj);
        if (urlparams.length === 0) {
          urlparams = 'resourceId=' + item.identifier;
        } else {
          urlparams += '&resourceId=' + item.identifier;
        }
      }
    });

    // Now get all the deployable properties of the resource Ids
    if (this.groupTemplate.server.datacenter === 'Rochelle') {
      this._linuxService
        .getVropRochelleProps(urlparams)
        .catch(this.handleError.bind(this))
        .then(this.getVropProps.bind(this));
    } else {
      this._linuxService
        .getVropHudsonProps(urlparams)
        .catch(this.handleError.bind(this))
        .then(this.getVropProps.bind(this));
    }
  }

  getVropProps(response: any) {
    //store the results in _serverConfi
    this.cdcOptions = [];
    var results = JSON.parse(response).resourcePropertiesList;
    results.forEach(item => {
      item.property.forEach(property => {
        if (property.name.startsWith('Automation_Property')) {
          if (property.value === 'Y') {
            // We are interested in this item.
            this.cdcResources.forEach(cdcitem => {
              if (cdcitem.id === item.resourceId) {
                // Push this value as one of valid options
                this.cdcOptions.push(cdcitem.name);
              }
            });
          }
        }
      });
    });
  }

  _createFilterFor = function (query) {
    return function filterFn(state) {
      return ('' + state).toLowerCase().match(query.toLowerCase());
    };
  };

  matchSoftwareProducts(event: any) {
    var val = this.groupTemplate.cmdb_app_name + event.key;

    this.softwareProducts = this._serverConfig.softwareProducts.filter(
      this._createFilterFor(val)
    );

    console.log('Found..');
  }

  getBusUnits(event: any) {
    var val = this.groupTemplate.business_unit + event.key;

    this.cmdbBusUnits = this._serverConfig.cmdbBusUnits.filter(
      this._createFilterFor(val)
    );

    console.log('Found..');
  }

  // If the new Cell is saved, go to edit it now.
  getSoftwareProducts(response: any) {
    this._serverConfig.softwareProducts = [];
    var results = JSON.parse(response).result;
    results.forEach(item => {
      this._serverConfig.softwareProducts.push(item.name);
    });
    if (this._serverConfig.softwareProducts)
      this.softwareProducts = this._serverConfig.softwareProducts;
  }

  showVmwareDetails(): boolean {
    if (this.groupTemplate.server.type === 'vmware') return true;
    else return false;
  }

  onOsSelection(os: string) {
    if (os === 'win') {
      this.osOfferings = this._linuxService.queryOsOptions('2', os);
      this.groupTemplate.server.os = '2016'; // default to 2016
      this.domainOptions = this.domainWinOptions;
      this.groupTemplate.network.domain = 'ad.allstate.com';
      this.primaryServerFunctions = this.priServerWinOptions;
      this.groupTemplate.server.pri_srvr_func = 'ACS';
      this.groupTemplate.server.env_code = 'S';
      this.envtTypeOptions = this.envtTypeWinOptions;
      this.profileTypeOptions = this.profileTypeAllOptions;
      if (
        this.groupTemplate.env_type === 'Training' ||
        this.groupTemplate.env_type === 'TPT'
      ) {
        // Since these two are not available in windows, set it to Test
        this.groupTemplate.env_type = 'Test';
      }
    } else {
      this.osOfferings = this._linuxService.queryOsOptions('r', os);
      this.groupTemplate.server.os = 'rhel7'; // default to redhat 7
      this.domainOptions = this.domainLinuxOptions;
      this.groupTemplate.network.domain = 'allstate.com';
      this.primaryServerFunctions = this.priServerLinuxOptions;
      this.groupTemplate.server.pri_srvr_func = 'lxv';
      this.envtTypeOptions = this.envtTypeLinuxOptions;
      if (this.groupTemplate.server.type === 'vmware')
        this.profileTypeOptions = this.profileTypeVmwareOptions;
    }
    this.onEnvironmentChange(this.groupTemplate.env_type);
  }

  onServerTypeChange(serverType: string) {
    this.profileTypeOptions = this.profileTypeAllOptions;

    // Only for Linux and if servertype vmware we want a different option.
    if (serverType === 'vmware') {
      if (this.groupTemplate.osType === 'lin')
        this.profileTypeOptions = this.profileTypeVmwareOptions;
    }
  }

  onEnvironmentChange(env: string) {
    if (env === 'Production' || env === 'Continuity') {
      this.isProduction = true;
      this.usageTypeOptions = this.prodUsageTypeOptions;
      if (this.groupTemplate.osType === 'lin')
        this.maintWeekOptions = this.maintWeekLinuxProdOptions;
      else this.maintWeekOptions = this.maintWeekProdOptions;
    } else {
      this.isProduction = false;
      this.usageTypeOptions = this.nonProdUsageTypeOptions;
      this.maintWeekOptions = this.maintWeekNonProdOptions;
      this.groupTemplate.mgmt.usage_type = 'Non-Production';
      this.groupTemplate.mgmt.maint_week = '1';
    }
  }

  dataCenterChanged(dataCenter: string) {
    // Save the data center in appliance too.
    this.groupTemplate.appliance.datacenter = dataCenter;
    if (dataCenter === 'Hudson') {
      this.isHudson = true;
      this.isRochelle = false;
    } else if (dataCenter === 'Rochelle') {
      this.isRochelle = true;
      this.isHudson = false;
    } else {
      this.isRochelle = false;
      this.isHudson = false;
    }
    if (dataCenter === 'Rochelle') {
      this._linuxService
        .getVropRochelleOptions()
        .catch(this.handleError.bind(this))
        .then(this.getVropResults.bind(this));
    } else {
      this._linuxService
        .getVropHudsonOptions()
        .catch(this.handleError.bind(this))
        .then(this.getVropResults.bind(this));
    }
  }

  cdcChanged(cdc: string) {
    if (this.groupTemplate.osType === 'win') {
      //Check the env type
      let valid = false;
      if (cdc === 'Allstate NON Prod SPSC Windows' ||
        cdc === 'Allstate NON Prod SPOD'
      ) {
        // The only valid values for this cdc is 
        // env_type should be Development, Test, Pre-Production and SMS_USAGE_TYPE should be
        // Dev, Non-Production, Pre-Production, Staging, Test
        if (this.groupTemplate.env_type === 'Development' ||
          this.groupTemplate.env_type === 'Test' ||
          this.groupTemplate.env_type === 'Pre-Production') {

          if (this.groupTemplate.mgmt.usage_type === 'Dev' ||
            this.groupTemplate.mgmt.usage_type === 'Non-Production' ||
            this.groupTemplate.mgmt.usage_type === 'Pre-Production' ||
            this.groupTemplate.mgmt.usage_type === 'Staging' ||
            this.groupTemplate.mgmt.usage_type === 'Test'
          )
            valid = true;
        }
      }
      else {
        if (cdc === 'Allstate SPOD' ||
          cdc === 'Allstate SPHC' ||
          cdc === 'Allstate SPSC Windows' ||
          cdc === 'Allstate HPHC'
        ) {
          // The only valid values for this cdc is 
          // env_type should be Development, Test, Pre-Production and SMS_USAGE_TYPE should be
          // Dev, Non-Production, Pre-Production, Staging, Test
          if (this.groupTemplate.env_type === 'Production') {
            valid = true;
          }
        }
      }
      // this cdc is valid for all environments.
      if (cdc === 'Allstate DMZ Staging')
        valid = true;
      if (!valid) {
        let message = "";
        if (this.groupTemplate.env_type === 'Production')
          message = " Invalid CDC Selected for Production Environment. Please select a Valid CDC for Production Windows. Valid CDCs are Allstate SPOD, Allstate SPHC, Allstate SPSC Windows, Allstate HPHC and Allstate DMZ Staging.";
        else
          message = " Invalid CDC Selected for Non Production Envrionment. Valid CDCs are Allstate NON Prod SPSC Windows, Allstate NON Prod SPOD or Allstate DMZ Staging.";
        this.dialogService
          .ok("Invalid CDC Selected", message)
          .subscribe(res => this.result = res);
      }
    }
  }


  showRemoveNas(currIndex: number): boolean {
    if (currIndex >= 0) {
      if (this.groupTemplate.nas.length > 0) return true;
      else return false;
    } else {
      return false;
    }
  }

  showRemovePhysical(currIndex: number): boolean {
    if (currIndex >= 0) {
      if (this.groupTemplate.phys.length > 0) return true;
      else return false;
    } else {
      return false;
    }
  }

  validatePriUser(event: any) {
    this.dialogService
      .ok('Validate Primary Contact', 'Please Validate this ID with ContactID field in Aware(CMDB). Please Make sure to remove any leading and trailing spaces. Incorrect Entries will cause the build to FAIL!',
        "https://cmdb.allstate.com/contact/cct_search.asp?go=yes")
      .subscribe(res => this.result = res);
  }

  clearPriUser() {
    console.log('Clearing user');
  }

  validateSecUser(event: any) {
    this.dialogService
      .ok('Validate Secondary Contact', 'Please Validate this ID with ContactID field in Aware(CMDB). Please Make sure to remove any leading and trailing spaces. Incorrect Entries will cause the build to FAIL!',
        "https://cmdb.allstate.com/contact/cct_search.asp?go=yes")
      .subscribe(res => this.result = res);
  }

  clearSecUser() {
    console.log('Clearing user');
  }

  validateUser(event: any) {
    if (event.target.value.indexOf('@') < 0)
      this._linuxService
        .getUser(event.target.value)
        .catch(this.handleError.bind(this))
        .then(this.userResults.bind(this));
    else {
      this.invContact = true;
      this.errorMessage = '@allstate.com is not allowed.';
    }
  }

  userResults(response: any) {
    console.log('Got User:', response);
    if (response.status === 'Not Found') {
      this.invContact = true;
      this.errorMessage = 'Not a Valid ID or a Group.';
    } else this.invContact = false;
  }

  clearUser() {
    console.log('Clearing user');
    this.invContact = false;
  }

  addNewNas() {
    console.log('Adding Nas..');
    let newNas = this.groupTemplate.addNas();
    this.currGroup = this.groupIndex;
  }

  removeNas(currIndex) {
    console.log('Removing Jvm from index..', currIndex);
    this.currGroup = this.groupIndex;
    this.groupTemplate.removeNas(currIndex);
  }

  addNewPhysical() {
    console.log('Adding Physical..');
    let newPhysical = this.groupTemplate.addPhysical();
    this.currGroup = this.groupIndex;
  }

  removePhysical(currIndex) {
    console.log('Removing Physical..', currIndex);
    this.currGroup = this.groupIndex;
    this.groupTemplate.removePhysical(currIndex);
  }

  isLinux(): boolean {
    return this.groupTemplate.osType === 'lin';
  }

  isWindows(): boolean {
    return this.groupTemplate.osType === 'win';
  }

  isCustom(): boolean {
    return this.groupTemplate.local_dasd.dasd_spec === 'cst';
  }

  showCloud(): boolean {
    if (this.groupTemplate.server.type === 'cloud') return true;
    else return false;
  }

  showPhysical(): boolean {
    if (this.groupTemplate.server.type === 'physical') return true;
    else return false;
  }

  onEccRestoreSelection(eccSelected: boolean) {
    if (eccSelected) {
      this.groupTemplate.mgmt.ecc_restore = 'yes';
    } else this.groupTemplate.mgmt.ecc_restore = 'no';
  }

  getDesignLoc(event: any) {
    this.networkCodes = this._linuxService.queryNetworkLocations(event);
    if (event.startsWith('DMZ')) {
      this.groupTemplate.server.network_code = '9';
    } else {
      this.groupTemplate.server.network_code = '0';
    }
  }

  getVirtualHostOptions(event: any) {
    this.virtHostOptions = this._linuxService.queryVirtHostOptions(event);
  }

  getSMSUsageTypeOptions(event: any) {
    this.smsUsageTypeOptions = this._linuxService.querySMSUsageOptions(event);
  }

  getOsOfferings(event: any) {
    this.osOfferings = this._linuxService.queryOsOptions(
      event,
      this.groupTemplate.osType
    );
  }

  getPrimaryServerFunctions(event: any) {
    this.primaryServerFunctions = this._linuxService.queryPrimaryServerFunctions(
      event
    );
  }
}
