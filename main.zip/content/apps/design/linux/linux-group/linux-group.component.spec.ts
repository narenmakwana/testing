import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinuxGroupComponent } from './linux-group.component';

describe('LinuxGroupComponent', () => {
  let component: LinuxGroupComponent;
  let fixture: ComponentFixture<LinuxGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinuxGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinuxGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
