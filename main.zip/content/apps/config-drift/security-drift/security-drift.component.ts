import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-security-drift',
  templateUrl: './security-drift.component.html',
  styleUrls: ['./security-drift.component.scss']
})
export class SecurityDriftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
