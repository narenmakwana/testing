import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecurityDriftComponent } from './security-drift.component';

describe('SecurityDriftComponent', () => {
  let component: SecurityDriftComponent;
  let fixture: ComponentFixture<SecurityDriftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecurityDriftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityDriftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
