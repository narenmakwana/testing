import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {Observable} from 'rxjs';
import {ResponseResult} from '../../../shared/models/response-result';
import {Subject, BehaviorSubject} from 'rxjs';
import {Constants} from '../../../shared/config/constants';
import { UditUtils } from '../../../../core/uditUtils';
import {AuthenticationService} from '../../pages/authentication/authentication.service';

@Injectable()
export class ConfigDriftService {

  _responseResults: ResponseResult;

  constructor(private http: HttpClient, private _authenticationService: AuthenticationService ) {
  }

  public getDriftReports() : Promise<any> { 
      const httpParams = new HttpParams().set("limit", "1");

      return this.http.get(Constants.getConfigDriftUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.getReportDetails)
                    .catch(this.handleError);
  }

  getReportDetails (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

}
