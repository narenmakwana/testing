import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'c-ais-drift-item',
  templateUrl: './ais-drift-item.component.html',
  styleUrls: ['./ais-drift-item.component.scss']
})
export class AisDriftItemComponent implements OnInit {

  @Input() serverData : any;

  constructor() { }

  ngOnInit() {
  }

  formatDelta = function(delta){
      // return this._diffService.generateHtml(delta, {});
  };

}
