import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AisDriftItemComponent } from './ais-drift-item.component';

describe('AisDriftItemComponent', () => {
  let component: AisDriftItemComponent;
  let fixture: ComponentFixture<AisDriftItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AisDriftItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AisDriftItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
