import { Component, OnInit, Output } from '@angular/core';
import {ConfigDriftService} from '../config-drift.service';
import {Router, ActivatedRoute } from '@angular/router';
import {Response} from '@angular/http';
import { ResponseResult } from '../../../../shared/models/response-result';

@Component({
  selector: 'c-ais-drift',
  templateUrl: './ais-drift.component.html',
  styleUrls: ['./ais-drift.component.scss']
})
export class  AisDriftComponent implements OnInit {

  responseResults: ResponseResult;
  serverData = [];

  private params: string[];
  private limit: number = 1;
  private offset: number = 0;
  private trim: string;

  p: number = 1;
  total: number = 0;
  loading: boolean = false;

  constructor(protected _router: Router, private _activeRoute: ActivatedRoute, private _configDriftService: ConfigDriftService) {
    this.responseResults = new ResponseResult();
  }

  ngOnInit() {
    this.getPage(1);
  }

  search(limit: number, page: number) {
    // calculate the offset based on page number and limit.
    var offset = (page - 1) * limit;
    this._configDriftService.getDriftReports()
                          .catch(err => console.log('Error Encountered..', err))
                          .then((data)=>{
                            this.responseResults = data;
                            this.serverData = this.responseResults.items;
                            this.total = this.responseResults.total;
                            this.p = page;
                            this.loading = false;
                          });
  }

  getPage(page: number) {
    this.loading = true;
    if (page === 1) {
      this.serverData = [];
      this.search(this.limit, page);
    } else {
      this.p = page;
      this.serverData = [];
      this.search(this.limit, page);
    }
  }

}
