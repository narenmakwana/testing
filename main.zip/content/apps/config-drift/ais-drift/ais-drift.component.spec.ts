import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AisDriftComponent } from './ais-drift.component';

describe('AisDriftComponent', () => {
  let component: AisDriftComponent;
  let fixture: ComponentFixture<AisDriftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AisDriftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AisDriftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
