import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AisDriftItemDetailsComponent } from './ais-drift-item-details.component';

describe('AisDriftItemComponent', () => {
  let component: AisDriftItemDetailsComponent;
  let fixture: ComponentFixture<AisDriftItemDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AisDriftItemDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AisDriftItemDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
