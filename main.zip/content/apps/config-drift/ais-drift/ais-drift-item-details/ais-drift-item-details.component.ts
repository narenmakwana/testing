import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'c-ais-drift-item-details',
  templateUrl: './ais-drift-item-details.component.html',
  styleUrls: ['./ais-drift-item-details.component.scss']
})
export class AisDriftItemDetailsComponent implements OnInit {

  showDetails : boolean = true;

  @Input() cell : any;

  constructor() {
    this.showDetails = true;
   }

  ngOnInit() {
      console.log("Got server data..");
      console.log(this.cell);
  }

  myEvent(event) {
    console.log(event);
    console.log("Clicked the cell " + this.showDetails);
  
    this.showDetails = !this.showDetails;

    console.log("Clicked the cell " + this.showDetails);

    return false;
  }

  formatDelta = function(delta){
      // return this._diffService.generateHtml(delta, {});
  };

}
