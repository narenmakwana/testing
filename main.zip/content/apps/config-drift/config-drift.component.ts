import { Component, OnInit, Output } from '@angular/core';
import {ConfigDriftService} from './config-drift.service';
import {Router, ActivatedRoute } from '@angular/router';
import {Response} from '@angular/http';

@Component({
  selector: 'c-config-drift',
  templateUrl: './config-drift.component.html'
})
export class ConfigDriftComponent implements OnInit {

  constructor(protected _router: Router, private _activeRoute: ActivatedRoute, private _configDriftService: ConfigDriftService) { }

  ngOnInit() {
  }

  getConfigDriftReports(): void {
    this._configDriftService.getDriftReports().catch(this.handleSaveError.bind(this))
                                              .then(this.handleSaveSuccess.bind(this));
  }

  handleSaveError(error: string){
      console.log("Error Encountered..", error);
  }

  handleSaveSuccess(resp: Response) {
     this._router.navigate(['apps/configdrift/aisdrift', 
          { limit: 1
          }]);
  }


}
