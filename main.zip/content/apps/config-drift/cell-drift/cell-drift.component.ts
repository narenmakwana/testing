import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cell-drift',
  templateUrl: './cell-drift.component.html',
  styleUrls: ['./cell-drift.component.scss']
})
export class CellDriftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
