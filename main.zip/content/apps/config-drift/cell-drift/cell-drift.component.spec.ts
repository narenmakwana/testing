import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CellDriftComponent } from './cell-drift.component';

describe('CellDriftComponent', () => {
  let component: CellDriftComponent;
  let fixture: ComponentFixture<CellDriftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CellDriftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CellDriftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
