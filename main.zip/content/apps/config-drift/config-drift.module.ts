import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { AisDriftComponent } from './ais-drift/ais-drift.component';
import { AisDriftItemComponent } from './ais-drift/ais-drift-item/ais-drift-item.component';
import { AisDriftItemDetailsComponent } from './ais-drift/ais-drift-item-details/ais-drift-item-details.component';
import { CellDriftComponent } from './cell-drift/cell-drift.component';
import { SecurityDriftComponent } from './security-drift/security-drift.component';
import { ConfigDriftService } from './config-drift.service';
import {AuthenticationService} from '../../pages/authentication/authentication.service';
import {ConfigDriftComponent } from './config-drift.component';

//
const routes: Routes = [
  {
    path     : 'configdrift/aisdrift',
    component: AisDriftComponent
  },  
  {
      path     : 'configdrift/celldrift',
      component: CellDriftComponent
  },
  {
      path     : 'configdrift/securitydrift',
      component: SecurityDriftComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    NgxPaginationModule,
    RouterModule.forChild(routes)
  ],
  declarations: [AisDriftComponent, AisDriftItemComponent, AisDriftItemDetailsComponent, ConfigDriftComponent, CellDriftComponent, SecurityDriftComponent],
  providers: [ConfigDriftService, AuthenticationService
  ]
})
export class ConfigDriftModule { }
