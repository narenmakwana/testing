import { Dcio } from './../../manage/applications/tci-codes/tci-codes.model';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectionStrategy, OnInit, OnDestroy, Component, Input } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ReportService } from '../../../../shared/services/reports.service';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { ResponseResult } from '../../../../shared/models/response-result';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DcioService } from '../../manage/applications/dcio/dcio.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { colorSets } from '@swimlane/ngx-charts/release/utils/color-sets';
import { formatLabel } from '@swimlane/ngx-charts/release/common/label.helper';

@Component({
  selector: 'app-jdk',
  templateUrl: './jdk.component.html',
  styleUrls: ['./jdk.component.scss'],
})

export class JdkComponent implements OnInit {
  initialData: any[];
  chartData: any[];
  dcioData: any[];
  exportData: any[] = [];
  cellData: any[];
  tciData: any[];
  view: any[];
  width: number = 1000;
  height: number = 500;
  filteredReport = '';
  // loading: boolean = false;

  // options
  gradient = false;
  showLegend = true;
  legendTitle = 'DCIO';
  showXAxisLabel = true;
  tooltipDisabled = false;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;

  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;
  arcWidth = 0.25;

  colorSets: any;
  colorScheme: any;
  selectedColorScheme: string;

  sdklist: any[] = [];
  jdklist: any[] = [];
  dcios: any[] = [];
  dcioOptions: any[] = [];
  busUnitOptions: any[] = [];
  tciOptions: any[] = [];
  loading: boolean = false;
  reportForm: FormGroup;
  searchDcio: string = "";
  searchBusUnit: string = "";
  searchTci: string = "";
  searchVersion1: string = "";
  jdkVersion: string = "";
  searchVersion: string = "";
  searchVersion2: string = "";
  filterlist: boolean = false;
  javaVersion8: boolean = false;
  javaVersionOptions: string[] = [null, "6.0", "7.0", "7.1", "8.0"];

  constructor(protected _reportsService: ReportService, protected _inventoryService: InventoryService, protected _dcio: DcioService, private formBuilder: FormBuilder) {
    this.view = [this.width, this.height];
    Object.assign(this, {
      colorSets
    });
    this.setColorScheme('picnic');
  }

  ngOnInit() {
    this.reportForm = this.formBuilder.group({
      searchDcio: [''],
      searchBusUnit: [''],
      searchTci: [''],
      searchVersion1: ['']
    });
    this.getReport();
  }

  getReport() {
    var self = this;
    this.loading = true;
    this._inventoryService.getWasSummaryInventory(HttpParams)
      .then((data) => {
        console.log(data.items);
        self.formatGraphData(data.items);
        self.formatExportData(data.items);
        //self.sdklist = data.items;
        self.jdklist = this.sdklist;
        //self.exportData = this.sdklist;
        self.loading = false;
        self.initialData = self.getCounts(this.sdklist);
        self.chartData = self.initialData;

        this._dcio.getDcios()
          .then((dciodata) => {
            this.dcios = dciodata.items;
            this.buildDropdowns(this.dcios, function () {
            });
          });
      });
  }

  formatGraphData(data) {
    data.forEach(cell => {
      var obj = {
        dcio: cell.dcio,
        supportingOrg: cell.supportingOrg,
        tciCode: cell.tciCode,
        cellName: cell.cellName,
        productEdition: cell.productType,
        productVersion: cell.wasVersion,
        nodes: cell.nodes,
        libertyJavaVersion: 'N/A',
        nodeJavaVersion: cell.nodeSDK,
        profileJavaVersion: cell.profileSDK,
        serverJavaVersion: cell.serverSDK,
        ihsVersion: cell.ihsVersion || 'N/A',
      }
      this.sdklist.push(obj);
    });
    return this.sdklist;
  }

  formatExportData(data) {
    data.forEach(cell => {
      cell.nodes.forEach(node => {
        var obj = {
          dcio: cell.dcio,
          supportingOrg: cell.supportingOrg,
          tciCode: cell.tciCode,
          cellName: cell.cellName,
          hostName: node.hostName,
          productEdition: cell.productType,
          productVersion: cell.wasVersion,
          libertyJavaVersion: 'N/A',
          nodeName: node.nodeName,
          nodeJavaVersion: cell.nodeSDK,
          profileJavaVersion: cell.profileSDK,
          serverJavaVersion: cell.serverSDK,
          ihsVersion: cell.ihsVersion || 'N/A',
        }
        this.exportData.push(obj);
      })

    });
    return this.exportData;
  }

  reformatExportData(data) {
    this.exportData = [];
    data.forEach(cell => {
      cell.nodes.forEach(node => {
        var obj = {
          dcio: cell.dcio,
          supportingOrg: cell.supportingOrg,
          tciCode: cell.tciCode,
          cellName: cell.cellName,
          hostName: node.hostName,
          productEdition: cell.productEdition,
          productVersion: cell.productVersion,
          libertyJavaVersion: 'N/A',
          nodeName: node.nodeName,
          nodeJavaVersion: cell.nodeJavaVersion,
          profileJavaVersion: cell.profileJavaVersion,
          serverJavaVersion: cell.serverJavaVersion,
          ihsVersion: cell.ihsVersion || 'N/A',
        }
        this.exportData.push(obj);
      })

    });
    return this.exportData;
  }

  getCounts(data) {
    var cells = [];
    var finalData = [];
    var javaVersion6 = {};
    var javaVersion7 = {};
    var javaVersion7_1 = {};
    var javaVersion8 = {};
    this.legendTitle = "JDK Versions"
    javaVersion6['name'] = "6.0"
    javaVersion6['value'] = 0;
    javaVersion6['cells'] = [];
    javaVersion7['name'] = "7.0"
    javaVersion7['value'] = 0;
    javaVersion7['cells'] = [];
    javaVersion7_1['name'] = "7.1"
    javaVersion7_1['value'] = 0;
    javaVersion7_1['cells'] = [];
    javaVersion8['name'] = "8.0"
    javaVersion8['value'] = 0;
    javaVersion8['cells'] = [];

    cells = data;
    for (var i = 0; i < cells.length; i++) {
      if (cells[i].nodeJavaVersion == "1.6_64" || cells[i].profileJavaVersion == "1.6_64" || cells[i].serverJavaVersion == "1.6_64") {
        javaVersion6['value'] += 1;
        javaVersion6['cells'].push(cells[i]);
      }
      else if (cells[i].nodeJavaVersion == "1.7_64" || cells[i].profileJavaVersion == "1.7_64" || cells[i].serverJavaVersion == "1.7_64") {
        javaVersion7['value'] += 1;
        javaVersion7['cells'].push(cells[i]);

      }
      else if (cells[i].nodeJavaVersion == "1.7.1_64" || cells[i].profileJavaVersion == "1.7.1_64" || cells[i].serverJavaVersion == "1.7.1_64") {
        javaVersion7_1['value'] += 1;
        javaVersion7_1['cells'].push(cells[i]);
      }
      else {
        javaVersion8['value'] += 1;
        javaVersion8['cells'].push(cells[i])
      }
    }
    finalData.push(javaVersion6);
    finalData.push(javaVersion7);
    finalData.push(javaVersion7_1);
    finalData.push(javaVersion8);
    return finalData;
  }

  getFilteredCounts(data) {
    var cells = [];
    var finalData = [];
    var javaVersion6 = {};
    var javaVersion7 = {};
    var javaVersion7_1 = {};
    var javaVersion8 = {};
    javaVersion6['name'] = "6.0"
    javaVersion6['value'] = 0;
    javaVersion6['cells'] = [];
    javaVersion7['name'] = "7.0"
    javaVersion7['value'] = 0;
    javaVersion7['cells'] = [];
    javaVersion7_1['name'] = "7.1"
    javaVersion7_1['value'] = 0;
    javaVersion7_1['cells'] = [];
    javaVersion8['name'] = "8.0"
    javaVersion8['value'] = 0;
    javaVersion8['cells'] = [];

    cells = data;
    for (var i = 0; i < cells.length; i++) {
      if (cells[i].nodeJavaVersion == "1.6_64" || cells[i].profileJavaVersion == "1.6_64" || cells[i].serverJavaVersion == "1.6_64") {
        javaVersion6['value'] += 1;
        javaVersion6['cells'].push(cells[i]);
      }
      else if (cells[i].nodeJavaVersion == "1.7_64" || cells[i].profileJavaVersion == "1.7_64" || cells[i].serverJavaVersion == "1.7_64") {
        javaVersion7['value'] += 1;
        javaVersion7['cells'].push(cells[i]);

      }
      else if (cells[i].nodeJavaVersion == "1.7.1_64" || cells[i].profileJavaVersion == "1.7.1_64" || cells[i].serverJavaVersion == "1.7.1_64") {
        javaVersion7_1['value'] += 1;
        javaVersion7_1['cells'].push(cells[i]);
      }
      else {
        javaVersion8['value'] += 1;
        javaVersion8['cells'].push(cells[i])
      }
    }
    finalData.push(javaVersion6);
    finalData.push(javaVersion7);
    finalData.push(javaVersion7_1);
    finalData.push(javaVersion8);
    return finalData;
  }


  select(data) {

    if (data.name === "6.0") {
      this.legendTitle = "DCIO : Version 6";
      this.setColorScheme('fire');
      // this.exportData = this.chartData[0].cells;
      this.exportData = this.reformatExportData(this.chartData[0].cells);
      this.chartData = this.getDcioCounts(this.chartData[0].cells);
    }
    else if (data.name === "7.0") {
      this.legendTitle = "DCIO : Version 7";
      this.setColorScheme('flame');
      // this.exportData = this.chartData[1].cells;
      this.exportData = this.reformatExportData(this.chartData[1].cells);
      this.chartData = this.getDcioCounts(this.chartData[1].cells);
    }
    else if (data.name === "7.1") {
      this.legendTitle = "DCIO : Version 7.1";
      this.setColorScheme('horizon');
      // this.exportData = this.chartData[2].cells;
      this.exportData = this.reformatExportData(this.chartData[2].cells);
      this.chartData = this.getDcioCounts(this.chartData[2].cells);
    }
    else if (data.name === "8.0") {
      this.legendTitle = "DCIO : Version 8";
      this.setColorScheme('cool');
      //this.exportData = this.chartData[3].cells;
      this.exportData = this.reformatExportData(this.chartData[3].cells);
      this.chartData = this.getDcioCounts(this.chartData[3].cells);
    }
    else if (this.legendTitle === "DCIO : Version 6" && data.name) {
      this.legendTitle = "TCI : Version 6";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (this.legendTitle === "DCIO : Version 7" && data.name) {
      this.legendTitle = "TCI : Version 7";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (this.legendTitle === "DCIO : Version 7.1" && data.name) {
      this.legendTitle = "TCI : Version 7.1";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (this.legendTitle === "DCIO : Version 8" && data.name) {
      this.legendTitle = "TCI : Version 8";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
  }

  setColorScheme(name) {
    this.selectedColorScheme = name;
    this.colorScheme = this.colorSets.find(s => s.name === name);
  }


  pieTooltipText({ data }) {
    const label = formatLabel(data.name);
    //const label = "Components";
    const val = formatLabel(data.value);

    return `
  <span class="tooltip-label">${label}</span>
  <span class="tooltip-val"># of Cells : ${val}</span>
`;
  }

  getDcioCounts(data) {
    var dcio = [];
    var cells = [];
    var newData = [];
    cells = data;
    for (var i = 0; i < cells.length; i++) {
      //var tci = cells[i].cell.split('-')[0];
      var tci = cells[i].tciCode;
      var cellObj = {}
      cellObj['name'] = cells[i].dcio;
      dcio.push(cellObj);

    }
    newData = dcio.map(item => item.name)
      .filter((value, index, self) => self.indexOf(value) === index);

    var finalData = [];

    for (var i = 0; i < newData.length; i++) {
      var obj = {};
      obj['name'] = newData[i];
      obj['value'] = 0;
      for (var j = 0; j < dcio.length; j++) {
        if (dcio[j].name === newData[i]) {
          obj['value'] += 1;
        }
      }
      finalData.push(obj);
    }
    return finalData;
  }

  getTciCounts(data, dcio) {
    var result = [];
    var newData = [];

    var tciCodes = data.map(cell => cell.tciCode)
      .filter((value, index, self) => self.indexOf(value) === index);

    for (var i = 0; i < data.length; i++) {
      if (data[i].dcio === dcio) {
        newData.push(data[i]);
      }
    }

    for (var j = 0; j < tciCodes.length; j++) {
      var resObj = {};
      resObj['name'] = "";
      resObj['value'] = 0;
      resObj['cells'] = [];
      resObj['name'] = tciCodes[j];
      for (var h = 0; h < newData.length; h++) {
        if (newData[h].tciCode === resObj['name']) {
          resObj['value'] += 1;
          resObj['cells'].push(newData[h]);
        }
      }
      result.push(resObj);
    }

    var finalResult = result.filter(tci => {
      return tci.value > 0;
    });

    return finalResult;
  }

  dblclick(event) {
    this.reset();
  }

  reset() {
    this.exportData = this.reformatExportData(this.sdklist);
    this.chartData = this.initialData;
    this.jdklist = this.sdklist;
    this.legendTitle = "JDK Version";
    this.setColorScheme('picnic');
    this.searchDcio = '';
    this.searchVersion1 = '';

  }

  selectDcio(_selectedDcio: string) {
    var self = this;
    this.searchDcio = _selectedDcio;
    if (!this.searchDcio) {
      this.selectBusUnit('');
      this.selectTci('');
      this.buildDropdowns(this.dcios)
    }
    else {
      this.refreshDropdowns(this.dcios);
    }
  }

  selectBusUnit(_selectedBusUnit: string) {
    this.searchBusUnit = _selectedBusUnit;

  }

  selectTci(_selectedTci: string) {
    this.searchTci = _selectedTci;
  }

  selectVersion(_selectedVersion: string) {
    if (_selectedVersion === "6.0") {
      this.searchVersion = "1.6_64"
      this.searchVersion2 = "";
    }
    else if (_selectedVersion === "7.0") {
      this.searchVersion = "1.7_64"
      this.searchVersion2 = "";

    }
    else if (_selectedVersion === "7.1") {
      this.searchVersion = "1.7.1_64"
      this.searchVersion2 = "";

    }
    else if (_selectedVersion === "8.0") {
      this.searchVersion = "1.8_64"
      this.searchVersion2 = "8.0_64"

    }
    else if (!_selectedVersion || _selectedVersion === "") {
      this.searchVersion = "";
      this.searchVersion2 = "";
    }
  }

  /* mapDcio(list, callback?) {
     var jdklist = [];
     this._dcio.getDcios()
       .then((dciodata) => {
         this.dcios = dciodata.items;
         this.buildDropdowns(this.dcios, function () {
           list.forEach(record => {
             var results = dciodata.items;
             results.forEach(item => {
               item.applications.forEach(application => {
                 if (application.tciCode === record.cell.split('-')[0]) {
                   jdklist.push({
                     dcio: item.dcio, busUnit: item.supportingOrg, tciCode: application.tciCode,
                     cell: record.cell, host: record.host, node: record.node, nodeSDK: record.nodeSDK,
                     profileSDK: record.profileSDK, server: record.server, serversdk: record.serversdk
                   });
                 };
               });
             });
           });
         });
         callback(jdklist);
       });
   }*/

  buildDropdowns(dcioList, callback?) {
    this.dcioOptions = [];
    this.busUnitOptions = [];
    this.tciOptions = [];
    this.dcioOptions.push('');
    this.busUnitOptions.push('');
    this.tciOptions.push('');
    dcioList.forEach(dcio => {
      this.dcioOptions.push({ dcio: dcio.dcio })
      this.busUnitOptions.push({ busUnit: dcio.supportingOrg })
    });
    dcioList.forEach(item => {
      item.applications.forEach(application => {
        this.tciOptions.push({ tciCode: application.tciCode })
      });
    });
    this.dcioOptions.sort((a, b) => a.dcio > b.dcio ? 1 : -1);
    this.busUnitOptions.sort((a, b) => a.busUnit > b.busUnit ? 1 : -1);
    this.tciOptions.sort((a, b) => a.tciCode > b.tciCode ? 1 : -1);
    if (callback) {
      callback();
    }
  }

  refreshDropdowns(dcioList) {
    this.busUnitOptions = [];
    this.tciOptions = [];
    this.busUnitOptions.push('');
    this.tciOptions.push('');
    dcioList.forEach(dcio => {
      if (this.searchDcio === dcio.dcio) {
        this.busUnitOptions.push({ busUnit: dcio.supportingOrg })
        dcioList.forEach(item => {
          item.applications.forEach(application => {
            if (this.searchDcio === item.dcio) {
              this.tciOptions.push({ tciCode: application.tciCode })
            }
          });
        });
      }
    });
  }

  getFilteredReport(callback) {
    this.jdklist = [];
    this.chartData = [];
    this.sdklist.forEach(record => {
      if (this.searchDcio && this.searchBusUnit && this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && this.searchBusUnit === record.supportingOrg
          && this.searchTci === record.tciCode
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "Java TCI"
        }
      }
      else if (this.searchDcio && this.searchBusUnit && this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && this.searchBusUnit === record.supportingOrg
          && this.searchTci === record.tciCode) {
          this.jdklist.push(record);
          this.filteredReport = "TCI"
        }
      }
      else if (this.searchDcio && this.searchBusUnit && !this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && this.searchBusUnit === record.supportingOrg) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (this.searchDcio && !this.searchBusUnit && !this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (this.searchDcio && this.searchBusUnit && !this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && this.searchBusUnit === record.supportingOrg
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (this.searchDcio && !this.searchBusUnit && this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && this.searchTci === record.tciCode) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (this.searchDcio && !this.searchBusUnit && !this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (this.searchDcio && !this.searchBusUnit && this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchDcio === record.dcio
          && (this.searchTci === record.tciCode)
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (!this.searchDcio && this.searchBusUnit && this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchBusUnit === record.supportingOrg
          && (this.searchTci === record.tciCode)
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (!this.searchDcio && this.searchBusUnit && this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchBusUnit === record.supportingOrg
          && this.searchTci === record.tciCode) {
          this.jdklist.push(record)
          this.filteredReport = "TCI"
        }
      }
      else if (!this.searchDcio && this.searchBusUnit && !this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchBusUnit === record.supportingOrg) {
          this.jdklist.push(record)
          this.filteredReport = "DCIO"
        }
      }
      else if (!this.searchDcio && this.searchBusUnit && !this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchBusUnit === record.supportingOrg
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record);
          this.filteredReport = "DCIO"
        }
      }
      else if (!this.searchDcio && !this.searchBusUnit && this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (this.searchTci === record.tciCode
          && (this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
          this.jdklist.push(record)
          this.filteredReport = "Java TCI"
        }
      }
      else if (!this.searchDcio && !this.searchBusUnit && this.searchTci && !(this.searchVersion || this.searchVersion2)) {
        if (this.searchTci === record.tciCode) {
          this.jdklist.push(record)
          this.filteredReport = "TCI"
        }
      }
      else if (!this.searchDcio && !this.searchBusUnit && !this.searchTci && (this.searchVersion || this.searchVersion2)) {
        if (record.nodeJavaVersion && record.profileJavaVersion && record.serverJavaVersion) {

          if ((this.searchVersion === record.nodeJavaVersion || this.searchVersion === record.serverJavaVersion || this.searchVersion === record.profileJavaVersion
            || this.searchVersion2 === record.nodeJavaVersion || this.searchVersion2 === record.serverJavaVersion || this.searchVersion2 === record.profileJavaVersion)) {
            this.jdklist.push(record)
            this.filteredReport = "TCI"
          }
        }
      }
      else if (!this.searchDcio && !this.searchBusUnit && !this.searchTci && (!this.searchVersion || !this.searchVersion2)) {
        this.jdklist.push(record);
      }
    });
    if (this.filteredReport === "Java TCI") {
      this.legendTitle = "TCI code by Version";
      //this.exportData = this.jdklist;
      this.exportData = this.reformatExportData(this.jdklist);
      this.chartData = this.getTciCounts(this.jdklist, this.searchDcio);
    }
    else if (this.filteredReport === "TCI") {
      this.legendTitle = "Versions by TCI Code";
      //this.exportData = this.jdklist;
      this.exportData = this.reformatExportData(this.jdklist);
      this.chartData = this.getFilteredCounts(this.jdklist);
    }
    else if (this.filteredReport === "DCIO") {
      this.legendTitle = "Versions by DCIO";
      //this.exportData = this.jdklist;
      this.exportData = this.reformatExportData(this.jdklist);
      this.chartData = this.getFilteredCounts(this.jdklist)

    }
    this.jdklist.sort((a, b) => (a.dcio > b.dcio || a.cell > b.cell) ? 1 : -1);
    if (callback) {
      callback();
    }
    this.select(this.jdklist);
  }
  sendDownloadRequest() {
    this.downloadFile(this.exportData)
  }

  downloadFile(report) {
    let headers = new Headers({
      'Content-Type': 'text/csv'
    });
    var options = {
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true,
      showTitle: false,
      useBom: true,
      noDownload: false,
      headers: ["DCIO", "Supporting Org", "TCI Code", "Cell", "Host", "Product Edition", "Product Version", "Liberty Java Version", "Node", "NodeSDK", "ProfileSDK", "ServerSDK", "IHS Version"]
    };
    new Angular5Csv(report, "JDK_Compliance", options)
  }
}
