/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { JDKComponent } from './jdk.component';

describe('JDKComponent', () => {
  let component: JDKComponent;
  let fixture: ComponentFixture<JDKComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JDKComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JDKComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
