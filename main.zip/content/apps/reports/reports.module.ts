import { NgModule } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AissecurityModule } from './aissecurity/aissecurity.module';
import { SharedModule } from '../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { PvucountComponent } from './pvucount/pvucount.component';
import { JdkComponent } from './jdk/jdk.component';
import { DciobreakdownComponent } from './dciobreakdown/dciobreakdown.component';
import { ReportService } from '../../../shared/services/reports.service'
import { OrgService } from '../../../shared/services/org.service';
import { InventoryService } from '../../../shared/services/inventory.service';

const routes: Routes = [
  {
    path: 'reports/pvucount',
    component: PvucountComponent
  },
  {
    path: 'reports/jdk',
    component: JdkComponent
  },
  {
    path: 'reports/dciobreakdown',
    component: DciobreakdownComponent
  },
];

@NgModule({
  imports: [
    SharedModule,
    AissecurityModule,
    NgxChartsModule,
    RouterModule.forChild(routes),
  ],
  providers: [
    ReportService,
    OrgService,
    InventoryService
  ],
  declarations: [PvucountComponent, JdkComponent, DciobreakdownComponent]
})
export class ReportsModule { }
