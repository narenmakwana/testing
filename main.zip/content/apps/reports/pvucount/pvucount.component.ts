import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pvucount',
  templateUrl: './pvucount.component.html',
  styleUrls: ['./pvucount.component.scss']
})
export class PvucountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
