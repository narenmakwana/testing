import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PvucountComponent } from './pvucount.component';

describe('PvucountComponent', () => {
  let component: PvucountComponent;
  let fixture: ComponentFixture<PvucountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PvucountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PvucountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
