import { Dcio } from './../../manage/applications/tci-codes/tci-codes.model';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectionStrategy, OnInit, OnDestroy, Component, Input } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ReportService } from '../../../../shared/services/reports.service';
import { InventoryService } from '../../../../shared/services/inventory.service';
import { ResponseResult } from '../../../../shared/models/response-result';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DcioService } from '../../manage/applications/dcio/dcio.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { colorSets } from '@swimlane/ngx-charts/release/utils/color-sets';
import { formatLabel } from '@swimlane/ngx-charts/release/common/label.helper';

@Component({
  selector: 'app-dciobreakdwon',
  templateUrl: './dciobreakdown.component.html',
  styleUrls: ['./dciobreakdown.component.scss'],
})

export class DciobreakdownComponent implements OnInit {
  initialData: any[];
  initialData2: any[];
  stackChartData: any[];
  footprintChartData: any[];
  chartData: any[];
  chartData2: any[] = [];
  exportData: any[];
  exportData2: any[];
  tciData: any[];
  view: any[];
  width: number = 850;
  height: number = 350;


  // options
  gradient = false;
  showLegend = true;
  legendTitle = 'Stack Footprint';
  legendTitleDCIO = 'DCIO Footprint';
  showXAxisLabel = true;
  tooltipDisabled = false;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;
  legendPosition: string = "left";

  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;
  arcWidth = 0.25;

  colorSets: any;
  colorScheme: any;
  colorScheme1: any;
  selectedColorScheme: string;

  newData: any[] = [];
  libertyData: any[] = [];
  twasData: any[] = [];
  loading: boolean = false;

  constructor(protected _reportsService: ReportService, protected _inventoryService: InventoryService, protected _dcio: DcioService, private formBuilder: FormBuilder) {
    this.view = [this.width, this.height];
    Object.assign(this, {
      colorSets
    });
    this.setColorScheme('picnic');
  }

  ngOnInit() {
    this.getReport();
  }

  getReport() {
    var self = this;
    this.loading = true;
    this._inventoryService.getWasSummaryInventory(HttpParams)
      .then((data) => {
        var returnedTwasData = self.formatTwasData(data.items);
        self._inventoryService.getWlpInventory('')
          .then((response) => {
            var returnedLibertyData = self.formatLibertyData(response.items);
            self.getStackCounts(returnedLibertyData, returnedTwasData, function (list) {
              self.initialData = list;
              self.exportData = self.newData;
              self.loading = false;
              self.chartData = self.initialData;
              self.initialData2 = self.getCounts(list);
              self.chartData2 = self.initialData2;
              self.exportData2 = self.newData;

            });
          });
      });
  }

  formatLibertyData(data) {
    data.forEach(cell => {
      var obj = {
        dcio: cell.dcio,
        supportingOrg: cell.supportingOrg,
        tciCode: cell.tciCode,
        cellName: cell.cellName,
        productEdition: cell.productEdition,
        productVersion: cell.wlpVersion,
        libertyJavaVersion: cell.javaVersion,
        nodeJavaVersion: 'N/A',
        profileJavaVersion: 'N/A',
        serverJavaVersion: 'N/A',
        ihsVersion: cell.ihsVersion || 'N/A',
      }
      if (cell.productEdition === "ND") {
        obj.productEdition = "Liberty ND"
      }
      else if (cell.productEdition === "BASE") {
        obj.productEdition = "Liberty Base"
      }
      this.newData.push(obj);
    });

    return this.newData;
  }

  formatTwasData(data) {
    data.forEach(cell => {
      var obj = {
        dcio: cell.dcio,
        supportingOrg: cell.supportingOrg,
        tciCode: cell.tciCode,
        cellName: cell.cellName,
        productEdition: cell.productType,
        productVersion: cell.wasVersion,
        libertyJavaVersion: 'N/A',
        nodeJavaVersion: cell.nodeSDK,
        profileJavaVersion: cell.profileSDK,
        serverJavaVersion: cell.serverSDK,
        ihsVersion: cell.ihsVersion || 'N/A',
      }
      this.newData.push(obj);
    });

    return this.newData;
  }

  getStackCounts(libertyData, twasData, callback?) {

    var libertyCells = [];
    var twasCells = [];
    var finalData = [];
    var libCore = {};
    var libBase = {};
    var libND = {};
    var twasND = {};
    var twasBase = {};

    libCore['name'] = "Liberty Core"
    libCore['value'] = 0;
    libCore['cells'] = [];

    libBase['name'] = "Liberty Base"
    libBase['value'] = 0;
    libBase['cells'] = [];

    libND['name'] = "Liberty ND"
    libND['value'] = 0;
    libND['cells'] = [];

    twasND['name'] = "WAS ND"
    twasND['value'] = 0;
    twasND['cells'] = [];

    twasBase['name'] = "WAS BASE"
    twasBase['value'] = 0;
    twasBase['cells'] = [];

    libertyCells = libertyData;
    twasCells = twasData;

    for (var i = 0; i < libertyCells.length; i++) {
      if (libertyCells[i].productEdition == "LIBERTY_CORE") {
        libCore['value'] += 1;
        libCore['cells'].push(libertyCells[i]);
      }
      else if (libertyCells[i].productEdition == "Liberty Base") {
        libBase['value'] += 1;
        libBase['cells'].push(libertyCells[i]);
      }
      else if (libertyCells[i].productEdition == "Liberty ND") {
        libND['value'] += 1;
        libND['cells'].push(libertyCells[i]);
      }
    }

    for (var i = 0; i < twasCells.length; i++) {
      if (twasCells[i].productEdition == "ND") {
        twasND['value'] += 1;
        twasND['cells'].push(twasCells[i]);
      }
      else if (twasCells[i].productEdition == "BASE") {
        twasBase['value'] += 1;
        twasBase['cells'].push(twasCells[i]);
      }
    }
    finalData.push(libCore);
    finalData.push(libBase);
    finalData.push(libND);
    finalData.push(twasND);
    finalData.push(twasBase);

    callback(finalData)
  }

  select(data) {

    if (data.name === "Liberty Core") {
      this.legendTitle = "DCIO : Liberty Core";
      this.setColorScheme('fire');
      this.exportData = this.chartData[0].cells;
      this.chartData = this.getDcioCounts(this.chartData[0].cells);
    }
    else if (this.legendTitle === "DCIO : Liberty Core" && data.name) {
      this.legendTitle = "TCI : Liberty Core";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (data.name === "Liberty Base") {
      this.legendTitle = "DCIO : Liberty Base";
      this.setColorScheme('fire');
      this.exportData = this.chartData[1].cells;
      this.chartData = this.getDcioCounts(this.chartData[1].cells);

    }
    else if (this.legendTitle === "DCIO : Liberty Base" && data.name) {
      this.legendTitle = "TCI : Liberty Base";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (data.name === "Liberty ND") {
      this.legendTitle = "DCIO : Liberty ND";
      this.setColorScheme('fire');
      this.exportData = this.chartData[2].cells;
      this.chartData = this.getDcioCounts(this.chartData[2].cells);

    }
    else if (this.legendTitle === "DCIO : Liberty ND" && data.name) {
      this.legendTitle = "TCI : Liberty ND";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (data.name === "WAS ND") {
      this.legendTitle = "DCIO : WAS ND";
      this.setColorScheme('fire');
      this.exportData = this.chartData[3].cells;
      this.chartData = this.getDcioCounts(this.chartData[3].cells);

    }
    else if (this.legendTitle === "DCIO : WAS ND" && data.name) {
      this.legendTitle = "TCI : WAS ND";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
    else if (data.name === "WAS BASE") {
      this.legendTitle = "DCIO : WAS BASE";
      this.setColorScheme('fire');
      this.exportData = this.chartData[4].cells;
      this.chartData = this.getDcioCounts(this.chartData[4].cells);

    }
    else if (this.legendTitle === "DCIO : WAS BASE" && data.name) {
      this.legendTitle = "TCI : WAS BASE";
      this.setColorScheme('natural');
      this.tciData = this.getTciCounts(this.exportData, data.name);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.chartData = this.tciData;

    }
  }
  dblclick(event) {
    this.reset();
  }

  dblclick1(event) {
    this.reset2();
  }

  select1(data) {
    var finalData = [];
    var exportableData = [];
    var libCore = {};
    var libND = {};
    var libBase = {};
    var libND = {};
    var twasND = {};
    var twasBase = {};
    var matchResult = false;


    libCore['name'] = "Liberty Core"
    libCore['value'] = 0;
    libCore['cells'] = [];

    libND['name'] = "Liberty ND"
    libND['value'] = 0;
    libND['cells'] = [];

    libBase['name'] = "Liberty Base"
    libBase['value'] = 0;
    libBase['cells'] = [];

    twasND['name'] = "WAS ND"
    twasND['value'] = 0;
    twasND['cells'] = [];

    twasBase['name'] = "WAS BASE"
    twasBase['value'] = 0;
    twasBase['cells'] = [];

    this.legendTitleDCIO = "DCIO :" + data.name;
    this.setColorScheme('fire');

    if (data.name === "UNKNOWN") {
      data.name = undefined;
    }

    this.newData.forEach(record => {

      if (record.supportingOrg === data.name && record.productEdition === "LIBERTY_CORE") {
        matchResult = true;
        libCore['value'] += 1;
        exportableData.push(record);
      }
      else if (record.supportingOrg === data.name && record.productEdition === "Liberty ND") {
        matchResult = true;
        libND['value'] += 1;
        exportableData.push(record);

      }
      else if (record.supportingOrg === data.name && record.productEdition === "Liberty Base") {
        matchResult = true;
        libND['value'] += 1;
        exportableData.push(record);

      }
      else if (record.supportingOrg === data.name && record.productEdition === "ND") {
        matchResult = true;
        twasND['value'] += 1;
        exportableData.push(record);

      }
      else if (record.supportingOrg === data.name && record.productEdition === "BASE") {
        matchResult = true;
        twasBase['value'] += 1;
        exportableData.push(record);
      }

    })
    if (matchResult) {
      finalData.push(libCore);
      finalData.push(libND);
      finalData.push(twasND);
      finalData.push(twasBase);
      this.chartData2 = finalData;
      this.exportData2 = exportableData;
      matchResult = false;
    }

  }

  setColorScheme(name) {
    this.selectedColorScheme = name;
    this.colorScheme = this.colorSets.find(s => s.name === name);
    this.colorScheme1 = 'picnic';
  }

  pieTooltipText({ data }) {
    const label = formatLabel(data.name);
    const val = formatLabel(data.value);

    return `
      <span class="tooltip-label">${label}</span>
      <span class="tooltip-val"># of Cells : ${val}</span>
    `;
  }

  getCounts(data) {
    var dcio = [];
    var cells = [];
    var stacks = [];
    var newData = [];
    stacks = data;
    for (var i = 0; i < stacks.length; i++) {
      for (var x = 0; x < stacks[i].cells.length; x++) {
        var cellObj = {}
        //cellObj['name'] = stacks[i].cells[x].dcio;
        if (stacks[i].cells[x].supportingOrg === undefined) {

          cellObj['name'] = "UNKNOWN";
        }
        else {
          cellObj['name'] = stacks[i].cells[x].supportingOrg;

        }
        dcio.push(cellObj);
      }
    }
    newData = dcio.map(item => item.name)
      .filter((value, index, self) => self.indexOf(value) === index);

    var finalData = [];
    for (var i = 0; i < newData.length; i++) {
      var obj = {};
      obj['name'] = newData[i];
      obj['value'] = 0;
      for (var j = 0; j < dcio.length; j++) {
        if (dcio[j].name === newData[i]) {
          obj['value'] += 1;
        }
      }
      finalData.push(obj);
    }
    return finalData;
  }

  getDcioCounts(data) {
    var dcio = [];
    var cells = [];
    var newData = [];
    cells = data;
    for (var i = 0; i < cells.length; i++) {
      var cellObj = {}
      cellObj['name'] = cells[i].dcio;
      dcio.push(cellObj);
    }
    newData = dcio.map(item => item.name)
      .filter((value, index, self) => self.indexOf(value) === index);

    var finalData = [];

    for (var i = 0; i < newData.length; i++) {
      var obj = {};
      obj['name'] = newData[i];
      obj['value'] = 0;
      for (var j = 0; j < dcio.length; j++) {
        if (dcio[j].name === newData[i]) {
          obj['value'] += 1;
        }
      }
      finalData.push(obj);
    }
    return finalData;
  }

  getTciCounts(data, dcio) {
    var result = [];
    var newData = [];

    var tciCodes = data.map(cell => cell.tciCode)
      .filter((value, index, self) => self.indexOf(value) === index);

    for (var i = 0; i < data.length; i++) {
      if (data[i].dcio === dcio) {
        newData.push(data[i]);
      }
    }

    for (var j = 0; j < tciCodes.length; j++) {
      var resObj = {};
      resObj['name'] = "";
      resObj['value'] = 0;
      resObj['cells'] = [];
      resObj['name'] = tciCodes[j];
      for (var h = 0; h < newData.length; h++) {
        if (newData[h].tciCode === resObj['name']) {
          resObj['value'] += 1;
          resObj['cells'].push(newData[h]);
        }
      }
      result.push(resObj);
    }

    var finalResult = result.filter(tci => {
      return tci.value > 0;
    });

    return finalResult;
  }
  reset() {
    this.exportData = this.newData;
    this.chartData = this.initialData;
    this.legendTitle = "Stack Footprint";
  }
  reset2() {
    this.exportData2 = this.newData;
    this.chartData2 = this.initialData2;
    this.legendTitleDCIO = 'DCIO Footprint';
  }
  sendDownloadRequest() {
    this.downloadFile(this.exportData)
  }
  sendDownloadRequest2() {
    this.downloadFile(this.exportData2)
  }
  downloadFile(report) {
    let headers = new Headers({
      'Content-Type': 'text/csv'
    });
    var options = {
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true,
      showTitle: false,
      useBom: true,
      noDownload: false,
      headers: ["DCIO", "Supporting Org", "TCI Code", "Cell", "STACK", "Product Version", "Liberty JDK Version", "Node JDK", "Profile JDK", "Server JDK", "IHS Version"]
    };
    new Angular5Csv(report, "Footprint", options)
  }
}
