import { Component, OnInit, ViewEncapsulation, EventEmitter } from '@angular/core';
import { colorSets } from '@swimlane/ngx-charts/release/utils/color-sets';
import { formatLabel } from '@swimlane/ngx-charts/release/common/label.helper';
import { AissecurityService } from './../aissecurity.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-compliance-overview',
  templateUrl: './compliance-overview.component.html',
  styleUrls: ['./compliance-overview.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class ComplianceOverviewComponent implements OnInit {

  chartData: any[];
  dcioData: any[];
  exportData: any[];
  cellData: any[];
  tciData: any[];
  versions: any[];
  dcioChip : boolean  = true;
  versionChip : boolean = false;
  view: any[];
  width: number = 1150;
  height: number = 525;


  // options
  gradient = false;
  showLegend = true;
  legendTitle = '';
  showXAxisLabel = true;
  tooltipDisabled = false;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;


  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;
  arcWidth = 0.25;

  colorSets: any;
  colorScheme: any;
  selectedColorScheme: string;


  constructor(private route: ActivatedRoute, private router: Router, public dataService: AissecurityService) {

    this.view = [this.width, this.height];

    Object.assign(this, {
      colorSets
    });

    //this.setColorScheme('picnic');
    this.colorScheme = {
      domain: ['#FF0000', '#5AA454']
    };
  }

  ngOnInit() {
    if (this.dataService.breadcrumbs.length === 0) {
      this.dataService.breadcrumbs.push({ url: this.router.url, label: 'Overview' })
    }
    else {
      this.dataService.breadcrumbs = this.dataService.breadcrumbs.slice(0, 1);
    }
    if (this.dataService.overviewData) {
      this.chartData = this.dataService.overviewData.chartData;
      this.legendTitle = "WAS Environments"
    }
    else {
      this.dataService.getAllInventory().then(
        () => { this.chartData = this.dataService.overviewData.chartData; this.legendTitle = "WAS Environments" },
        () => console.log("Error!"),
      );
    }
  }

  select(data) {
    if (data === "Compliant" || data.name === "Compliant") {
      this.router.navigate(['./compliant/dcio'], { relativeTo: this.route });
    }
    else if (data === "Non-Compliant" || data.name === "Non-Compliant") {
      this.router.navigate(['./non-compliant/dcio'], { relativeTo: this.route });
    }
  }

  setColorScheme(name) {
    this.selectedColorScheme = name;
    this.colorScheme = this.colorSets.find(s => s.name === name);
  }


  pieTooltipText({ data }) {
    const label = formatLabel(data.name);
    const val = formatLabel(data.value);

    return `
      <span class="tooltip-label">${label}</span>
      <span class="tooltip-val"># of Cells : ${val}</span>
    `;
  }

  byDcio(){
    if (this.dcioChip){
      return;
    }
    else{
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      this.dataService.overviewData.byVersion = false;
    }
  }


  byVersion(){
    if (this.versionChip){
      return;
    }
    else{
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      this.dataService.overviewData.byVersion = true;
    }

  }
}
