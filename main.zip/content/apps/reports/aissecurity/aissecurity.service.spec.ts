import { TestBed, inject } from '@angular/core/testing';

import { AissecurityService } from './aissecurity.service';

describe('AissecurityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AissecurityService]
    });
  });

  it('should be created', inject([AissecurityService], (service: AissecurityService) => {
    expect(service).toBeTruthy();
  }));
});
