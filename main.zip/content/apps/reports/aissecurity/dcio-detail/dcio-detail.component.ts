import { Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { AissecurityService } from '../aissecurity.service';
import { colorSets } from '@swimlane/ngx-charts/release/utils/color-sets';
import { formatLabel } from '@swimlane/ngx-charts/release/common/label.helper';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { TciSummaryComponent } from '../tci-summary/tci-summary.component';

@Component({
  selector: 'app-dcio-detail',
  templateUrl: './dcio-detail.component.html',
  styleUrls: ['./dcio-detail.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class DcioDetailComponent implements OnInit {

  chartData: any[];
  exportData: any[];
  was85ChartData: any[];
  was85ExportData: any[];
  was9ChartData: any[];
  was9ExportData: any[];
  wlpChartData: any[];
  wlpExportData: any[];
  view: any[];
  width: number = 1150;
  height: number = 525;
  dcioChip: boolean = true;
  versionChip: boolean = false;
  compliance: boolean = false;
  nonCompliance: boolean = false;
  dialogRef: any;

  // options
  gradient = false;
  showLegend = true;
  legendTitle = "";
  showXAxisLabel = true;
  tooltipDisabled = false;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;

  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;
  arcWidth = 0.25;

  colorSets: any;
  colorScheme: any;
  selectedColorScheme: string;


  constructor(public dataService: AissecurityService, private route: ActivatedRoute,
    private router: Router, public dialog: MatDialog) {
    this.view = [this.width, this.height];
    Object.assign(this, {
      colorSets
    });
  }

  ngOnInit() {
    // If a user comes to this URL directly without providing the DCIO, route one page back (compliant or non-compliant)
    if (this.dataService.selectedDcio.length === 0) {
      this.router.navigate(['../'], { relativeTo: this.route });
    }

    else if (this.dataService.breadcrumbs.length === 2) {
      this.dataService.breadcrumbs.push({ url: this.router.url, label: this.dataService.selectedDcio })
    }
    else {
      this.dataService.breadcrumbs = this.dataService.breadcrumbs.slice(0, 3);
    }

    if (this.route.routeConfig.path.includes('non-compliant')) {
      this.legendTitle = "TCI: Non-Compliant";
      this.setColorScheme('fire');
      this.nonCompliance = true;
      this.exportData = this.dataService.tciNonCompliantData['exportData'];
      this.chartData = this.dataService.tciNonCompliantData['chartData'];
      this.was85ChartData = this.dataService.tciNonCompliantData.versionData.was85['chartData'];
      this.was85ExportData = this.dataService.tciNonCompliantData.versionData.was85['exportData'];
      this.was9ChartData = this.dataService.tciNonCompliantData.versionData.was9['chartData'];
      this.was9ExportData = this.dataService.tciNonCompliantData.versionData.was9['exportData'];
      this.wlpChartData = this.dataService.tciNonCompliantData.versionData.wlp['chartData'];
      this.wlpExportData = this.dataService.tciNonCompliantData.versionData.wlp['exportData'];

    }
    else if (this.route.routeConfig.path.includes('/compliant/')) {
      this.legendTitle = "TCI: Compliant";
      this.setColorScheme('natural');
      this.compliance = true;
      this.exportData = this.dataService.tciCompliantData['exportData'];
      this.chartData = this.dataService.tciCompliantData['chartData'];
      this.was85ChartData = this.dataService.tciCompliantData.versionData.was85['chartData'];
      this.was85ExportData = this.dataService.tciCompliantData.versionData.was85['exportData'];
      this.was9ChartData = this.dataService.tciCompliantData.versionData.was9['chartData'];
      this.was9ExportData = this.dataService.tciCompliantData.versionData.was9['exportData'];
      this.wlpChartData = this.dataService.tciCompliantData.versionData.wlp['chartData'];
      this.wlpExportData = this.dataService.tciCompliantData.versionData.wlp['exportData'];
    }
  }

  select(data, version) {
    let tci;
    if (data.name) {
      tci = data.name;
    }
    else {
      tci = data;
    }

    var cellDetails = [];

    if (version) {
      let v = version;
      if (v === '9.0') {
        cellDetails = this.was9ExportData.filter(cell => cell.tciCode === tci);
      }
      else if (v === '8.5') {
        cellDetails = this.was85ExportData.filter(cell => cell.tciCode === tci);
      }
      else {
        cellDetails = this.wlpExportData.filter(cell => cell.tciCode === tci);
      }
    }
    else {
      cellDetails = this.exportData.filter(cell => cell.tciCode === tci);
    }

    if (tci && cellDetails.length > 0) {
      this.dialogRef = this.dialog.open(TciSummaryComponent, {
        width: '850px',
        data: { cellDetails: cellDetails, tci: tci }
      });
      this.dialogRef.afterClosed()
        .subscribe(response => {
          console.log(response);
        });
    }
  }

  setColorScheme(name) {
    this.selectedColorScheme = name;
    this.colorScheme = this.colorSets.find(s => s.name === name);
  }


  pieTooltipText({ data }) {
    const label = formatLabel(data.name);
    const val = formatLabel(data.value);

    return `
      <span class="tooltip-label">${label}</span>
      <span class="tooltip-val"># of Cells : ${val}</span>
    `;
  }

  byDcio() {
    if (this.dcioChip) {
      return;
    }
    else {
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      if (this.compliance) {
        this.dataService.tciCompliantData.byVersion = false;

      }
      else {
        this.dataService.tciNonCompliantData.byVersion = false;

      }
    }
  }


  byVersion() {
    if (this.versionChip) {
      return;
    }
    else {
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      if (this.compliance) {
        this.dataService.tciCompliantData.byVersion = true;

      }
      else {
        this.dataService.tciNonCompliantData.byVersion = true;

      }
    }

  }

}
