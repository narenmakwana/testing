import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcioDetailComponent } from './dcio-detail.component';

describe('DcioDetailComponent', () => {
  let component: DcioDetailComponent;
  let fixture: ComponentFixture<DcioDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcioDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcioDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
