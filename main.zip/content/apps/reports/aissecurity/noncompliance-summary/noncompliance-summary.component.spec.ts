import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoncomplianceSummaryComponent } from './noncompliance-summary.component';

describe('NoncomplianceSummaryComponent', () => {
  let component: NoncomplianceSummaryComponent;
  let fixture: ComponentFixture<NoncomplianceSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoncomplianceSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoncomplianceSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
