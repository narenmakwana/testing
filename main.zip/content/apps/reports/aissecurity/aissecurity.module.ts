import { NgModule } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { AissecurityComponent } from './aissecurity.component';
import { ComplianceOverviewComponent } from './compliance-overview/compliance-overview.component';
import { DcioDetailComponent } from './dcio-detail/dcio-detail.component';
import { AissecurityService } from './aissecurity.service';
import { TciSummaryComponent } from './tci-summary/tci-summary.component';
import { ComplianceSummaryComponent } from './compliance-summary/compliance-summary.component';
import { NoncomplianceSummaryComponent } from './noncompliance-summary/noncompliance-summary.component';

// Routes for AIS Security Compliance report navigation
const routes: Routes = [
  {
    path: 'reports/aissecurity',
    component: AissecurityComponent,
    children: [
      { path: 'overview', component: ComplianceOverviewComponent },
      { path: 'overview/compliant/dcio', component: ComplianceSummaryComponent},
      { path: 'overview/compliant/dcio/:id', component: DcioDetailComponent},
      { path: 'overview/non-compliant/dcio', component: NoncomplianceSummaryComponent},
      { path: 'overview/non-compliant/dcio/:id', component: DcioDetailComponent},
      { path: '', redirectTo: 'overview' },
    ]
  },
];

@NgModule({
  imports: [
    SharedModule,
    NgxChartsModule,
    RouterModule.forChild(routes),
  ],
  declarations: [
    AissecurityComponent,
    ComplianceOverviewComponent,
    DcioDetailComponent,
    TciSummaryComponent,
    ComplianceSummaryComponent,
    NoncomplianceSummaryComponent
  ],
  providers: [
    AissecurityService
  ],
  entryComponents: [TciSummaryComponent]
})
export class AissecurityModule { }
