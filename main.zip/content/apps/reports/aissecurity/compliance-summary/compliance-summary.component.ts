import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AissecurityService } from '../aissecurity.service';
import { colorSets } from '@swimlane/ngx-charts/release/utils/color-sets';
import { formatLabel } from '@swimlane/ngx-charts/release/common/label.helper';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-compliance-summary',
  templateUrl: './compliance-summary.component.html',
  styleUrls: ['./compliance-summary.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class ComplianceSummaryComponent implements OnInit {

  chartData: any[];
  tciData: any[];
  exportData: any[];
  view: any[];
  width: number = 1150;
  height: number = 525;
  dcioChip : boolean  = true;
  versionChip : boolean = false;
  
  // options
  gradient = false;
  showLegend = true;
  legendTitle = "";
  showXAxisLabel = true;
  tooltipDisabled = false;
  showSeriesOnHover = true;
  roundEdges: boolean = true;
  animations: boolean = true;

  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;
  arcWidth = 0.25;

  colorSets: any;
  colorScheme: any;
  selectedColorScheme: string;


  constructor(public dataService: AissecurityService, private route: ActivatedRoute,
    private router: Router) {
    this.view = [this.width, this.height];

    Object.assign(this, {
      colorSets
    });

  }

  ngOnInit() {

    if (this.dataService.breadcrumbs.length === 1){
      this.dataService.breadcrumbs.push({url: this.router.url, label: 'Compliant'})
    }
    else {
      this.dataService.breadcrumbs = this.dataService.breadcrumbs.slice(0,2);
    }

    if (this.dataService.complianceData) {
      this.legendTitle = "DCIO : Compliant";
      this.setColorScheme('vivid');
      this.exportData = this.dataService.complianceData['exportData'];
      this.chartData = this.dataService.complianceData['chartData'];
    }
    else {
      this.dataService.getAllInventory().then(
        () => {
          this.legendTitle = "DCIO : Compliant";
          this.setColorScheme('vivid');
          this.exportData = this.dataService.complianceData['exportData'];
          this.chartData = this.dataService.complianceData['chartData'];
        },
        () => console.log("Error!"),
      );
    }
  }

  select(data) {
    let dcio;
    if (data.name){
      dcio = data.name;
    }
    else{
      dcio = data;
    }

    if (this.legendTitle === "DCIO : Compliant" && dcio) {
      this.dataService.selectedDcio = dcio;
      this.tciData = this.dataService.getTciCounts(this.exportData, dcio);
      this.exportData = [].concat.apply([], (this.tciData.map(tci => tci.cells)));
      this.dataService.tciCompliantData = { chartData: this.tciData, exportData: this.exportData };

      let was85TciData = this.dataService.getTciCounts(this.dataService.complianceData.versionData.was85.exportData, dcio);
      let was9TciData = this.dataService.getTciCounts(this.dataService.complianceData.versionData.was9.exportData, dcio);
      let wlpTciData = this.dataService.getTciCounts(this.dataService.complianceData.versionData.wlp.exportData, dcio);
      this.dataService.tciCompliantData = {
        chartData: this.tciData, exportData: this.exportData,
        versionData: {
          wlp: { chartData: wlpTciData, exportData: [].concat.apply([], (wlpTciData.map(tci => tci.cells))) },
          was85: { chartData: was85TciData, exportData: [].concat.apply([], (was85TciData.map(tci => tci.cells))) },
          was9: { chartData: was9TciData, exportData: [].concat.apply([], (was9TciData.map(tci => tci.cells))) }
        }
      };

      this.router.navigate(['./' + dcio], { relativeTo: this.route });
    }
  }

  setColorScheme(name) {
    this.selectedColorScheme = name;
    this.colorScheme = this.colorSets.find(s => s.name === name);
  }

  pieTooltipText({ data }) {
    const label = formatLabel(data.name);
    const val = formatLabel(data.value);

    return `
      <span class="tooltip-label">${label}</span>
      <span class="tooltip-val"># of Cells : ${val}</span>
    `;
  }


  byDcio(){
    if (this.dcioChip){
      return;
    }
    else{
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      this.dataService.complianceData.byVersion = false;
    }
  }


  byVersion(){
    if (this.versionChip){
      return;
    }
    else{
      this.dcioChip = !this.dcioChip;
      this.versionChip = !this.versionChip;
      this.dataService.complianceData.byVersion = true;
    }

  }
}
