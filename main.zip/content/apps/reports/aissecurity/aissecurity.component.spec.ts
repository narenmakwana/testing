import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AissecurityComponent } from './aissecurity.component';

describe('AissecurityComponent', () => {
  let component: AissecurityComponent;
  let fixture: ComponentFixture<AissecurityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AissecurityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AissecurityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
