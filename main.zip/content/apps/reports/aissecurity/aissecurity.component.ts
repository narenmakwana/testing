import { Component, OnInit, ViewEncapsulation, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { AissecurityService } from './aissecurity.service';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-aissecurity',
  templateUrl: './aissecurity.component.html',
  styleUrls: ['./aissecurity.component.scss'],
  encapsulation: ViewEncapsulation.None

})

export class AissecurityComponent implements OnInit {

  _dataService: any;

  constructor(private router: Router, private route: ActivatedRoute, private dataService: AissecurityService, private cdRef: ChangeDetectorRef) {
    this._dataService = dataService;
  }

  ngOnInit() {
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  ngOnDestroy() {
    this.dataService.overviewData = null;
    this.dataService.breadcrumbs = [];
  }

  /** This function will determine based on the current route/URL which data to export from
   *  the data service as a CSV
  */
  sendDownloadRequest() {
    let headers = new Headers({
      'Content-Type': 'text/csv'
    });
    var url = this.router.url;
    var urlSegements = this.router.url.split('/');
    var currentPath = urlSegements[urlSegements.length - 1];
    if (currentPath === 'overview') {
      if (this.dataService.overviewData.byVersion) {
        this.downloadFile(this.dataService.overviewData.versionData.wlp.exportData, "Liberty_FP_Compliance_Summary");
        this.downloadFile(this.dataService.overviewData.versionData.was85.exportData, "WAS_8.5_FP_Compliance_Summary");
        this.downloadFile(this.dataService.overviewData.versionData.was9.exportData, "WAS_9_FP_Compliance_Summary");
      }
      else {
        this.downloadFile(this.dataService.overviewData.exportData, "WAS_FP_Compliance_Summary");
      }
    }
    else if (currentPath === 'dcio' && url.includes('/compliant')) {
      if (this.dataService.complianceData.byVersion) {
        this.downloadFile(this.dataService.complianceData.versionData.wlp.exportData, "Liberty_FP_Compliance_Summary");
        this.downloadFile(this.dataService.complianceData.versionData.was85.exportData, "WAS_8.5_FP_Compliance_Summary");
        this.downloadFile(this.dataService.complianceData.versionData.was9.exportData, "WAS_9_FP_Compliance_Summary");
      }
      else {
        this.downloadFile(this.dataService.complianceData.exportData, "WAS_FP_Compliance");
      }
    }
    else if (currentPath === 'dcio' && url.includes('/non-compliant')) {
      if (this.dataService.nonComplianceData.byVersion) {
        this.downloadFile(this.dataService.nonComplianceData.versionData.wlp.exportData, "Liberty_FP_Non_Compliance_Summary");
        this.downloadFile(this.dataService.nonComplianceData.versionData.was85.exportData, "WAS_8.5_FP_Non_Compliance_Summary");
        this.downloadFile(this.dataService.nonComplianceData.versionData.was9.exportData, "WAS_9_FP_Non_Compliance_Summary");
      }
      else {
        this.downloadFile(this.dataService.nonComplianceData.exportData, "WAS_FP_Non_Compliance");
      }
    }
    else if (currentPath !== 'dcio' && url.includes('/compliant') && this.dataService.selectedDcio) {
      if (this.dataService.tciCompliantData.byVersion) {
        this.downloadFile(this.dataService.tciCompliantData.versionData.wlp.exportData, "Liberty_FP_" + this.dataService.selectedDcio + "_Compliance_Summary");
        this.downloadFile(this.dataService.tciCompliantData.versionData.was85.exportData, "WAS_8.5_FP_" + this.dataService.selectedDcio + "_Compliance_Summary");
        this.downloadFile(this.dataService.tciCompliantData.versionData.was9.exportData, "WAS_9_FP_" + this.dataService.selectedDcio + "_Compliance_Summary");
      }
      else {
        this.downloadFile(this.dataService.tciCompliantData.exportData, "WAS_FP_" + this.dataService.selectedDcio + "_Compliance");
      }
    }
    else if (currentPath !== 'dcio' && url.includes('/non-compliant') && this.dataService.selectedDcio) {
      if (this.dataService.tciNonCompliantData.byVersion) {
        this.downloadFile(this.dataService.tciNonCompliantData.versionData.wlp.exportData, "Liberty_FP_" + this.dataService.selectedDcio + "_Non_Compliance_Summary");
        this.downloadFile(this.dataService.tciNonCompliantData.versionData.was85.exportData, "WAS_8.5_FP_" + this.dataService.selectedDcio + "_Non_Compliance_Summary");
        this.downloadFile(this.dataService.tciNonCompliantData.versionData.was9.exportData, "WAS_9_FP_" + this.dataService.selectedDcio + "_Non_Compliance_Summary");
      }
      else {
        this.downloadFile(this.dataService.tciNonCompliantData.exportData, "WAS_FP_" + this.dataService.selectedDcio + "_Non_Compliance");
      }
    }
  }

  downloadFile(report, title) {
    if (report.length > 0) {
      var options = {
        fieldSeparator: ',',
        quoteStrings: '"',
        decimalseparator: '.',
        showLabels: true,
        showTitle: false,
        useBom: true,
        noDownload: false,
        headers: ["DCIO", "Supporting Org", "Application Name", "TCI", "Cell", "WAS Version", "Java Version", "IHS Version", "Compliance Deadline", "Compliant?"]
      };
      new Angular5Csv(report, title, options)
    }
    else {
      console.log("No Export Data Available");
    }
  }
}
