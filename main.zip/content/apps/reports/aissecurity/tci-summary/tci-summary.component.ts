import { Component, Inject, OnInit, ViewEncapsulation, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatTableDataSource, MAT_DIALOG_DATA, MatDialogRef, MatTable } from '@angular/material';
import { DataSource } from '@angular/cdk/collections';


@Component({
  selector: 'app-tci-summary',
  templateUrl: './tci-summary.component.html',
  styleUrls: ['./tci-summary.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TciSummaryComponent implements OnInit {

  displayedColumns = ['appName', 'cellName', 'wasVersion', 'ihsVersion', 'complianceDeadline'];
  dataSource : any;

  dialogTitle: string;
  action: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    public dialogRef: MatDialogRef<TciSummaryComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any, private cdRef: ChangeDetectorRef
  ) {
    this.data = data;
  }

  ngOnInit() { }

  ngAfterViewInit() {
    this.dataSource = new MatTableDataSource<{}>(this.data.cellDetails);
    this.dataSource.paginator = this.paginator;
    this.cdRef.detectChanges();

  }
}
