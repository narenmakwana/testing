import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TciSummaryComponent } from './tci-summary.component';

describe('TciSummaryComponent', () => {
  let component: TciSummaryComponent;
  let fixture: ComponentFixture<TciSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TciSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TciSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
