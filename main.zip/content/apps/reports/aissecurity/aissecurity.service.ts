import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { UditUtils } from '../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';
import { Constants } from '../../../../shared/config/constants';
import { OptionsService } from '../../../../shared/services/options.service';
import { OrgService } from './../../../../shared/services/org.service';
import { InventoryService } from '../../../../shared/services/inventory.service';

@Injectable()
export class AissecurityService {

    breadcrumbs: Array<object> = [];
    wlpInventory = [];
    wasInventory = [];
    tciInventory = [];
    wlpData: any;
    was85Data: any;
    was9Data: any;
    overviewData: any;
    complianceData: any;
    nonComplianceData: any;
    tciCompliantData: any;
    tciNonCompliantData: any;
    wlpVersions: any;
    wasVersions: any;
    loading: boolean = false;
    latestWlpVersion = '';
    latestWas85Version = '';
    latestWas9Version = '';
    selectedDcio = '';


    constructor(private _inventoryService: InventoryService, private _optionsService: OptionsService,
        private _orgService: OrgService) { }

    /** 
     * Function that will retrieve Liberty Versions, WAS Versions, DCIO Data,
     * Liberty inventory, and WAS summary inventory in parallel then initialize report data
     */
    getAllInventory() {
        return new Promise((resolve, reject) => {
            this.loading = true;
            Promise.all([
                this._optionsService.getWlpVersions(),
                this._optionsService.getWasVersions(null, Constants.INSTALL_TYPES.ND.value),
                this._inventoryService.getWlpInventory(''),
                this._inventoryService.getWasSummaryInventory(HttpParams),
                this._orgService.getTciCodes()
            ]).then(data => {
                this.wlpVersions = data[0];
                this.wasVersions = data[1];
                this.wlpInventory = data[2].items;
                this.wasInventory = data[3].items;
                this.tciInventory = data[4].items;
                this.wlpData = this.formatWlpData(this.wlpInventory);
                this.was85Data = this.formatWasData(this.wasInventory.filter(inv => inv.wasVersion.startsWith('8.5')));
                this.was9Data = this.formatWasData(this.wasInventory.filter(inv => inv.wasVersion.startsWith('9.0')));
                let totalData = this.wlpData.concat(this.was85Data, this.was9Data);
                this.setOverviewData(totalData);
                this.setNonComplianceData(this.overviewData)
                this.setComplianceData(this.overviewData);
                this.loading = false;
                resolve();
            })
                .catch(err => console.log(err));
        })

    }

    /**
     * Function that takes in a data array of cells and will capture counts
     * by DCIO for the DCIO drill down. Returns single series data,value
     */
    getDcioCounts(data) {
        var dcio = [];
        var cells = [];
        var newData = [];
        cells = data;
        for (var i = 0; i < cells.length; i++) {
            var tci = cells[i].cellName.split('-')[0];
            var cellObj = {}
            cellObj['name'] = cells[i].dcio;
            dcio.push(cellObj);

        }
        newData = dcio.map(item => item.name)
            .filter((value, index, self) => self.indexOf(value) === index);

        var finalData = [];

        for (var i = 0; i < newData.length; i++) {
            var obj = {};
            obj['name'] = newData[i];
            obj['value'] = 0;
            for (var j = 0; j < dcio.length; j++) {
                if (dcio[j].name === newData[i]) {
                    obj['value'] += 1;
                }
            }
            finalData.push(obj);
        }
        return finalData;
    }

    /**
     * Function that takes in a data array of cells and will capture counts
     * of cells that are compliant vs non-compliant and returns data set
     */
    getCounts(data) {
        var cells = [];
        var finalData = [];
        var compliant = {};
        var nonCompliant = {};
        compliant['name'] = "Compliant"
        compliant['value'] = 0;
        compliant['cells'] = [];
        nonCompliant['name'] = "Non-Compliant"
        nonCompliant['value'] = 0;
        nonCompliant['cells'] = [];
        cells = data;

        for (var i = 0; i < cells.length; i++) {
            if (!cells[i].compliant) {
                nonCompliant['value'] += 1;
                nonCompliant['cells'].push(cells[i]);
            }
            else {
                compliant['value'] += 1;
                compliant['cells'].push(cells[i])
            }
        }
        finalData.push(nonCompliant);
        finalData.push(compliant);
        return finalData;
    }

    /**
     * Function that takes in a data array of cells and the DCIO name to 
     * create a list of all TCI codes with associate counts
     */
    getTciCounts(data, dcio) {
        var result = [];
        var newData = [];

        var tciCodes = data.map(cell => cell.tciCode)
            .filter((value, index, self) => self.indexOf(value) === index);

        for (var i = 0; i < data.length; i++) {
            if (data[i].dcio === dcio) {
                newData.push(data[i]);
            }
        }

        for (var j = 0; j < tciCodes.length; j++) {
            var resObj = {};
            resObj['name'] = "";
            resObj['value'] = 0;
            resObj['cells'] = [];
            resObj['name'] = tciCodes[j];
            for (var h = 0; h < newData.length; h++) {
                if (newData[h].tciCode === resObj['name']) {
                    resObj['value'] += 1;
                    resObj['cells'].push(newData[h]);
                }
            }
            result.push(resObj);
        }

        var finalResult = result.filter(tci => {
            return tci.value > 0;
        });

        return finalResult;
    }


    /**
     * Function that takes in a data array of liberty cells and will format
     * the data to be used for exporting in the CSV
     */
    formatWlpData(data) {
        var newData = [];
        data.forEach(cell => {

            var appName;
            var supportingOrg;
            var dcio;

            // Set DCIO, Supporting Org, and app name data by checking against the DCIO inventory
            this.tciInventory.forEach(item => {
                item.applications.forEach(app => {
                    if (app.tciCode === cell.tciCode) {
                        appName = app.appName;
                        supportingOrg = item.supportingOrg;
                        dcio = item.dcio;
                    }
                });
            });

            var obj = {
                dcio: dcio || 'N/A',
                supportingOrg: supportingOrg || 'N/A',
                appName: appName || 'N/A',
                tciCode: cell.tciCode || 'N/A',
                cellName: cell.cellName || 'N/A',
                wasVersion: cell.wlpVersion || 'N/A',
                javaVersion: cell.javaVersion || 'N/A',
                ihsVersion: cell.ihsVersion || 'N/A',
                complianceDeadline: '',
                compliant: false
            }

            // Determine fix pack compliance by checking WAS and IHS version against all versions
            this.wlpVersions.forEach(version => {
                if (obj.wasVersion === version.wlp) {
                    obj.complianceDeadline = version.deadline;
                    obj.compliant = this.checkWlpCompliance(obj.wasVersion);
                    if (obj.ihsVersion !== 'N/A') {
                        obj.compliant = this.checkWasCompliance(obj.ihsVersion);
                    }
                }
            });
            newData.push(obj);
        });

        return newData;
    }

    /**
     * Function that takes in a data array of liberty cells and will format
     * the data to be used for exporting in the CSV
     */
    formatWasData(data) {
        var newData = [];
        data.forEach(cell => {

            var appName;
            var supportingOrg;
            var dcio;

            // Set DCIO, Supporting Org, and app name data by checking against the DCIO inventory
            this.tciInventory.forEach(item => {
                item.applications.forEach(app => {
                    if (app.tciCode === cell.tciCode) {
                        appName = app.appName;
                        supportingOrg = item.supportingOrg;
                        dcio = item.dcio;
                    }
                });
            });

            var obj = {
                dcio: dcio || 'N/A',
                supportingOrg: supportingOrg || 'N/A',
                appName: appName || 'N/A',
                tciCode: cell.tciCode || 'N/A',
                cellName: cell.cellName || 'N/A',
                wasVersion: cell.wasVersion || 'N/A',
                javaVersion: cell.javaVersion || 'N/A',
                ihsVersion: cell.ihsVersion || 'N/A',
                complianceDeadline: '',
                compliant: false
            }

            // Determine fix pack compliance by checking WAS and IHS version against all versions
            this.wasVersions.forEach(version => {
                if (obj.wasVersion === version.was) {
                    obj.complianceDeadline = version.deadline;
                    obj.compliant = this.checkWasCompliance(obj.wasVersion);
                    if (obj.ihsVersion !== 'N/A') {
                        obj.compliant = this.checkWasCompliance(obj.ihsVersion);
                    }
                }
            });
            newData.push(obj);
        });

        return newData;
    }

    /** Function that takes in a fix pack version and will determine fix pack compliance
     *  by checking today's date against the compliance deadline
     *  captured from the Versions inventory
     */
    checkWlpCompliance(version) {
        var today = new Date().toISOString();
        var fixPacks = [];
        var compliant = false;
        var latest = this.getWlpLatestVersion(this.wlpVersions);
        latest.deadline = new Date(Date.parse(latest.deadline)).toISOString();
        for (var i = 0; i < this.wlpVersions.length; i++) {
            var deadline = new Date(Date.parse(this.wlpVersions[i].deadline)).toISOString();
            // Fix pack is compliant if its not passed the deadline yet
            if (today <= deadline) {
                fixPacks.push(this.wlpVersions[i].wlp);
            }
            // Fix pack is compliant if it is the latest/last fix pack available and passed the deadline
            else if (deadline < today && this.wlpVersions[i].wlp === latest.version) {
                fixPacks.push(this.wlpVersions[i].wlp);
            }
            // Fix pack is compliant if its passed its compliance deadline but one patch cycle before the latest version
            // and the latest version's compliance deadline has not been reached
            else if (this.wlpVersions[i + 1]) {
                if (this.wlpVersions[i + 1].wlp === latest.version && deadline <= latest.deadline && latest.deadline > today) {
                    fixPacks.push(this.wlpVersions[i].wlp);
                }
            }
        }

        // Check if version passed into this function is in the compliant fix pack's array and return true/false
        fixPacks.forEach(fp => {
            if (version === fp) {
                compliant = true;
            }
        });

        return compliant;
    }

    /** Function that takes in a fix pack version and will determine fix pack compliance
     *  by checking today's date against the compliance deadline
     *  captured from the Versions inventory
     */
    checkWasCompliance(version) {
        var today = new Date().toISOString();
        var fixPacks = [];
        var compliant = false;
        var wasVersions = this.wasVersions.filter(fp => fp.was.startsWith(version.slice(0, 3)));
        var latest = this.getWasLatestVersion(wasVersions);
        latest.deadline = new Date(Date.parse(latest.deadline)).toISOString();
        for (var i = 0; i < wasVersions.length; i++) {
            var deadline = new Date(Date.parse(wasVersions[i].deadline)).toISOString();
            // Fix pack is compliant if its not passed the deadline yet
            if (today <= deadline) {
                fixPacks.push(wasVersions[i].was);
            }
            // Fix pack is compliant if it is the latest/last fix pack available and passed the deadline
            else if (deadline < today && wasVersions[i].was === latest.version) {
                fixPacks.push(wasVersions[i].was);
            }
            // Fix pack is compliant if its passed its compliance deadline but one patch cycle before the latest version
            // and the latest version's compliance deadline has not been reached
            else if (wasVersions[i + 1]) {
                if (wasVersions[i + 1].was === latest.version && deadline <= latest.deadline && latest.deadline > today) {
                    fixPacks.push(wasVersions[i].was);
                }
            }
        }

        // Check if version passed into this function is in the compliant fix pack's array and return true/false
        fixPacks.forEach(fp => {
            if (version === fp) {
                compliant = true;
            }
        });

        return compliant;
    }

    /** Function that will find the latest Liberty Version from all the available Liberty
     *  versions in the inventory
     */
    getWlpLatestVersion(versions) {
        var today = new Date().toISOString();
        var latest = { version: null, deadline: null };
        versions.forEach((version) => {
            var deadline = new Date(Date.parse(version.deadline)).toISOString();
            if (deadline >= today) {
                latest.version = version.wlp;
                latest.deadline = deadline;
            }
        });
        if (!latest.version) {
            latest.version = versions[versions.length - 1].wlp;
            latest.deadline = versions[versions.length - 1].deadline;
        }
        return latest;
    }


    /** Function that will find the latest WAS Version from all the available Liberty
    *  versions in the inventory
    */
    getWasLatestVersion(versions) {
        var today = new Date().toISOString();
        var latest = { version: null, deadline: null };
        versions.forEach((version) => {
            var deadline = new Date(Date.parse(version.deadline)).toISOString();
            if (deadline >= today) {
                latest.version = version.was;
                latest.deadline = deadline;
            }
        });
        if (!latest.version) {
            latest.version = versions[versions.length - 1].was;
            latest.deadline = versions[versions.length - 1].deadline;
        }
        return latest;

    }

    // Function that sets all the compliance array data for the charts and to export
    setComplianceData(data) {
        this.complianceData = {
            chartData: [], exportData: [],
            versionData: {
                wlp: { chartData: [], exportData: [] },
                was85: { chartData: [], exportData: [] },
                was9: { chartData: [], exportData: [] }
            }
        };
        this.complianceData.chartData = this.getDcioCounts(data.chartData[1].cells);
        this.complianceData.exportData = data.chartData[1].cells;
        this.complianceData.versionData.wlp.chartData = this.getDcioCounts(data.versionData.wlp.chartData[1].cells);
        this.complianceData.versionData.wlp.exportData = data.versionData.wlp.chartData[1].cells;
        this.complianceData.versionData.was85.chartData = this.getDcioCounts(data.versionData.was85.chartData[1].cells);
        this.complianceData.versionData.was85.exportData = data.versionData.was85.chartData[1].cells;
        this.complianceData.versionData.was9.chartData = this.getDcioCounts(data.versionData.was9.chartData[1].cells);
        this.complianceData.versionData.was9.exportData = data.versionData.was9.chartData[1].cells;

    }

    // Function that sets all the non-compliance array data for the charts and to export
    setNonComplianceData(data) {
        this.nonComplianceData = {
            chartData: [], exportData: [],
            versionData: {
                wlp: { chartData: [], exportData: [] },
                was85: { chartData: [], exportData: [] },
                was9: { chartData: [], exportData: [] }
            }
        };
        this.nonComplianceData.chartData = this.getDcioCounts(data.chartData[0].cells);
        this.nonComplianceData.exportData = data.chartData[0].cells;
        this.nonComplianceData.versionData.wlp.chartData = this.getDcioCounts(data.versionData.wlp.chartData[0].cells);
        this.nonComplianceData.versionData.wlp.exportData = data.versionData.wlp.chartData[0].cells;
        this.nonComplianceData.versionData.was85.chartData = this.getDcioCounts(data.versionData.was85.chartData[0].cells);
        this.nonComplianceData.versionData.was85.exportData = data.versionData.was85.chartData[0].cells;
        this.nonComplianceData.versionData.was9.chartData = this.getDcioCounts(data.versionData.was9.chartData[0].cells);
        this.nonComplianceData.versionData.was9.exportData = data.versionData.was9.chartData[0].cells;


    }

    // Function that sets all the compliance summary array data for the charts and to export
    setOverviewData(data) {
        this.overviewData = {
            chartData: [], exportData: [],
            versionData: {
                wlp: { chartData: [], exportData: [] },
                was85: { chartData: [], exportData: [] },
                was9: { chartData: [], exportData: [] }
            }
        };
        this.overviewData.chartData = this.getCounts(data);
        this.overviewData.exportData = data.sort(this.sortByTci);
        this.overviewData.versionData.wlp.chartData = this.getCounts(this.wlpData);
        this.overviewData.versionData.wlp.exportData = this.wlpData.sort(this.sortByTci);
        this.overviewData.versionData.was85.chartData = this.getCounts(this.was85Data);
        this.overviewData.versionData.was85.exportData = this.was85Data.sort(this.sortByTci);
        this.overviewData.versionData.was9.chartData = this.getCounts(this.was9Data);
        this.overviewData.versionData.was9.exportData = this.was9Data.sort(this.sortByTci);


    }

    // Function to sort an Array or Collection by DCIO
    sortByDcio(a, b) {
        var aName = a.dcio.toLowerCase();
        var bName = b.dcio.toLowerCase();
        return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
    }

    // Function to sort an Array or Collection by TCI Code
    sortByTci(a, b) {
        var aName = a.tciCode.toLowerCase();
        var bName = b.tciCode.toLowerCase();
        return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
    }
}
