import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasversionsComponent } from './wasversions.component';

describe('WasversionsComponent', () => {
  let component: WasversionsComponent;
  let fixture: ComponentFixture<WasversionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasversionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasversionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
