import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { WasVersion, WasFixPack } from './wasversions.model';
import { UditUtils } from '../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';
import { Constants } from '../../../../shared/config/constants';

@Injectable()
export class WasVersionsService implements Resolve<any>
{
    onWasVersionsChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSelectedWasVersionsChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSearchTextChanged: Subject<any> = new Subject();
    onFilterChanged: Subject<any> = new Subject();

    wasVersions: WasVersion[];
    selectedWasVersions: string[] = [];

    searchText: string;
    filterBy: string;

    constructor(private http: HttpClient)
    {
    }

    /**
     * The WasVersions App Main Resolver
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {
        return new Promise((resolve, reject) => {

            Promise.all([
                this.getWasVersions()
            ]).then(
                ([files]) => {

                    this.onSearchTextChanged.subscribe(searchText => {
                        this.searchText = searchText;
                        this.getWasVersions();
                    });

                    this.onFilterChanged.subscribe(filter => {
                        this.filterBy = filter;
                        this.getWasVersions();
                    });

                    resolve();

                },
                reject
            );
        });
    }

    getWasVersions(): Promise<any>
    {
        return new Promise((resolve, reject) => {
                this.http.get(Constants.getWasPackagesUrl())
                    .subscribe((response: any) => {
                        this.wasVersions = response.items.map(wasVersion => {
                            return new WasVersion(wasVersion);
                        });

                        if ( this.searchText && this.searchText !== '' )
                        {
                            this.wasVersions = UditUtils.filterArrayByString(this.wasVersions, this.searchText);
                        }

                        this.onWasVersionsChanged.next(this.wasVersions);
                        resolve(this.wasVersions);
                    }, reject);
            }
        );
    }

    /**
     * Toggle selected wasVersion by id
     * @param id
     */
    toggleSelectedWasVersion(id)
    {
        // First, check if we already have that todo as selected...
        if ( this.selectedWasVersions.length > 0 )
        {
            const index = this.selectedWasVersions.indexOf(id);

            if ( index !== -1 )
            {
                this.selectedWasVersions.splice(index, 1);

                // Trigger the next event
                this.onSelectedWasVersionsChanged.next(this.selectedWasVersions);

                // Return
                return;
            }
        }

        // If we don't have it, push as selected
        this.selectedWasVersions.push(id);

        // Trigger the next event
        this.onSelectedWasVersionsChanged.next(this.selectedWasVersions);
    }

    /**
     * Toggle select all
     */
    toggleSelectAll()
    {
        if ( this.selectedWasVersions.length > 0 )
        {
            this.deselectWasVersions();
        }
        else
        {
            this.selectWasVersions();
        }
    }

    selectWasVersions(filterParameter?, filterValue?)
    {
        this.selectedWasVersions = [];

        // If there is no filter, select all todos
        if ( filterParameter === undefined || filterValue === undefined )
        {
            this.selectedWasVersions = [];
            this.wasVersions.map(wasVersion => {
                this.selectedWasVersions.push(wasVersion._id);
            });
        }

        // Trigger the next event
        this.onSelectedWasVersionsChanged.next(this.selectedWasVersions);
    }

    updateWasVersion(wasVersion)
    {
        let id = wasVersion._id;
        // remove the id to allow the update.
        delete wasVersion._id;
        return new Promise((resolve, reject) => {

            this.http.put(Constants.getWasPackagesUrl() + "/" + id, {...wasVersion})
                .subscribe(response => {
                    this.getWasVersions();
                    resolve(response);
                });
        });
    }

    createWasVersion(wasVersion)
    {
        // We want to remove the ID's if any because we want Mongo to assign one.
        if(wasVersion._id)
            delete wasVersion._id;
        return new Promise((resolve, reject) => {

            this.http.post(Constants.getWasPackagesUrl(), {...wasVersion})
                .subscribe(response => {
                    this.getWasVersions();
                    resolve(response);
                });
        });
    }

    removeWasVersion(wasVersion)
    {
        let id = wasVersion._id;
        // remove the id to allow the update.
        delete wasVersion._id;
        return new Promise((resolve, reject) => {

            this.http.delete(Constants.getWasPackagesUrl() + "/" + id, {...wasVersion})
                .subscribe(response => {
                    this.getWasVersions();
                    resolve(response);
                });
        });
    }

    deselectWasVersions()
    {
        this.selectedWasVersions = [];

        // Trigger the next event
        this.onSelectedWasVersionsChanged.next(this.selectedWasVersions);
    }

    deleteWasVersion(wasVersion)
    {
        const wasVersionIndex = this.wasVersions.indexOf(wasVersion);
        this.wasVersions.splice(wasVersionIndex, 1);
        this.removeWasVersion(wasVersion);
        this.onWasVersionsChanged.next(this.wasVersions);
    }

    deleteSelectedWasVersions()
    {
        for ( const wasVersionId of this.selectedWasVersions )
        {
            const wasVersion = this.wasVersions.find(_wasVersion => {
                return _wasVersion._id === wasVersionId;
            });
            const wasVersionIndex = this.wasVersions.indexOf(wasVersion);
            this.wasVersions.splice(wasVersionIndex, 1);
            this.removeWasVersion(wasVersion);
        }
        this.onWasVersionsChanged.next(this.wasVersions);
        this.deselectWasVersions();
    }

}
