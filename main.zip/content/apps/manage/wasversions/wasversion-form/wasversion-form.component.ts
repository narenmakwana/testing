import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CalendarEvent } from 'angular-calendar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WasVersion } from '../wasversions.model';

@Component({
  selector: 'app-wasversion-form',
  templateUrl: './wasversion-form.component.html',
  styleUrls: ['./wasversion-form.component.scss']
})
export class WasversionDialogFormComponent implements OnInit {

  dialogTitle: string;
  wasVersionForm: FormGroup;
  action: string;
  wasVersion: WasVersion;

  constructor(
      public dialogRef: MatDialogRef<WasversionDialogFormComponent>,
      @Inject(MAT_DIALOG_DATA) private data: any,
      private formBuilder: FormBuilder
  )
  {
    if ( this.data.action === 'edit' )
    {
        this.dialogTitle = 'Edit Version';
        this.wasVersion = this.data.wasversion;
    }
    else
    {
        this.dialogTitle = 'New Version';
        this.wasVersion = new WasVersion();
    }

    this.wasVersionForm = this.createWasVersionForm();
  }

  ngOnInit()
  {
  }

  createWasVersionForm()
  {
      return this.formBuilder.group({
          _id          : [this.wasVersion._id],
          install_id    : [this.wasVersion.install_id],
          install_type  : [this.wasVersion.install_type],
          name         : [this.wasVersion.name],
          version      : [this.wasVersion.version],
          releaseDate : [this.wasVersion.releaseDate],
          location : [this.wasVersion.location],
          fixpacks : [this.wasVersion.fixpacks]
      });
  }

}
