import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasversionFormComponent } from './wasversion-form.component';

describe('WasversionFormComponent', () => {
  let component: WasversionFormComponent;
  let fixture: ComponentFixture<WasversionFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasversionFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasversionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
