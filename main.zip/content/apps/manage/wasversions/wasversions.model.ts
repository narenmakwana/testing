import { UditUtils } from '../../../../../core/uditUtils';
import { WasIhsTemplate } from '../../../../shared/models/was-ihs-template';

export class WasVersion
{
    _id: string;
    install_id: string;
    install_type: string;
    location: string;
    name: string;
    version: string;
    releaseDate: string;
    fixpacks: string[];

    constructor(wasversion? : any)
    {
        if (wasversion)
        {
            if(wasversion._id)
                this._id = wasversion._id;
                
            this.install_id = wasversion.install_id || '';
            this.install_type = wasversion.install_type || '';
            this.location = wasversion.location || '';
            this.name = wasversion.name || '';
            this.version = wasversion.version || '';
            this.releaseDate = wasversion.releaseDate || '';
            this.fixpacks = wasversion.fixpacks;
        }
        else {
            this.install_id = "";
            this.install_type = "";
            this.location = '';
            this.name = '';
            this.version = '';
            this.releaseDate = '';
            this.fixpacks = [];
        }
    }
}

export class WasFixPack
{
    _id: string;
    fixpackId: string;
    fixpackName: string;
    complianceDeadline: string;
    location: string;
    ifix: WasiFix[] = [];

    constructor(initData?)
    {
        if(initData) {
            this._id = initData._id;
            this.fixpackId = initData.fixpackId || "";
            this.fixpackName = initData.fixpackName || "";
            this.complianceDeadline= initData.complianceDeadline || "";
            this.location = initData.location || ""; 
            this.ifix = initData.ifix || [];           
        }
        else {
            this._id = "";
            this.fixpackId = "";
            this.fixpackName = "";
            this.complianceDeadline = "";
            this.location = "";
            this.ifix = [];
        }
    }
}


export class WasiFixType {
    ifixId: string;
    description : string;

    constructor(initData?){
        if(initData){
            this.ifixId = initData.ifixId;
            this.description = initData.description;
        }
        else {
            this.ifixId = "";
            this.description = "";
        }
    }
}


export class WasiFix {
    ifixName: string;
    ifixesIncluded: WasiFixType[];

    constructor(initData?){
        if(initData){
            this.ifixName = initData.ifixName;
            this.ifixesIncluded = initData.ifixesIncluded;
        }
        else {
            this.ifixName = "";
            this.ifixesIncluded = [];
        }
    }
}


