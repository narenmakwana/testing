import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { WasversionsComponent } from './wasversions.component';
import { WasVersionsService } from './wasversions.service';
import { FixPacksService } from './was-fixpack/was-fixpack.service';
import { WasversionListComponent } from './wasversion-list/wasversion-list.component';
import { WasFixpackComponent } from './was-fixpack/was-fixpack.component';
import { WasFixpackListComponent } from './was-fixpack/was-fixpack-list/was-fixpack-list.component';
import { WasFixpackFormComponent } from './was-fixpack/was-fixpack-form/was-fixpack-form.component';
import { WasversionDialogFormComponent } from './wasversion-form/wasversion-form.component';
import { WasIfixComponent } from './was-ifix/was-ifix.component';
import { WasIfixListComponent } from './was-ifix/was-ifix-list/was-ifix-list.component';
import { WasFixFormComponent } from './was-ifix/was-fix-form/was-fix-form.component';

const routes: Routes = [
  {
      path     : 'manage/wasversions',
      component: WasversionsComponent,
      resolve  : {
        data: WasVersionsService
    }
  },
  {
    path     : 'manage/wasversions/:id',
    component: WasFixpackComponent,
    resolve  : {
      data: FixPacksService
  }
}

];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    WasversionsComponent,
    WasversionListComponent,
    WasFixpackComponent,
    WasFixpackListComponent,
    WasFixpackFormComponent,
    WasversionDialogFormComponent,
    WasIfixComponent,
    WasIfixListComponent,
    WasFixFormComponent, 
  ],
  providers      : [
    WasVersionsService, FixPacksService
  ],
  entryComponents: [WasFixpackFormComponent, WasversionDialogFormComponent]
})
export class WasversionsModule { }
