import { Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { FixPacksService } from '../was-fixpack.service';
import { Observable } from 'rxjs/Observable';
import { WasFixpackFormComponent } from '../../was-fixpack/was-fixpack-form/was-fixpack-form.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import { UditConfirmDialogComponent } from '../../../../../../../core/components/confirm-dialog/confirm-dialog.component';
import { FormGroup } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';
import { uditAnimations } from '../../../../../../../core/animations';
import { Subscription } from 'rxjs/Subscription';
import { WasFixPack } from '../../wasversions.model';
import { Constants } from '../../../../../../shared/config/constants';

@Component({
  selector: 'app-was-fixpack-list',
  templateUrl: './was-fixpack-list.component.html',
  styleUrls: ['./was-fixpack-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WasFixpackListComponent implements OnInit, OnDestroy {

  @ViewChild('dialogContent') dialogContent: TemplateRef<any>;

  fixpack: any;
  dataSource: FilesDataSource | null;
  displayedColumns = ['checkbox', 'fixpackId', 'fixpackName', 'releaseDate', 'ifix', 'buttons'];
  selectedFixpacks: any[];
  checkboxes: {};

  onFixpacksChangedSubscription: Subscription;
  onSelectedFixPacksChangedSubscription: Subscription;

  dialogRef: any;

  confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

  constructor(
      private wasFixpacksService: FixPacksService,
      public dialog: MatDialog
  )
  {
      // This is where we get all the fixpack ID's. We need to retrieve all the fixpack objects here.
      this.onFixpacksChangedSubscription =
          this.wasFixpacksService.onFixPacksChanged.subscribe(fixpack => {
              this.fixpack = fixpack;
              this.checkboxes = {};
              fixpack.map(fp => {
                  this.checkboxes[fp._id] = false;
              });
          });

      this.onSelectedFixPacksChangedSubscription =
          this.wasFixpacksService.onSelectedFixPacksChanged.subscribe(selectedFixpacks => {
              for ( const selectedFixpacks in this.checkboxes )
              {
                  if ( !this.checkboxes.hasOwnProperty(selectedFixpacks) )
                  {
                      continue;
                  }

                  this.checkboxes[selectedFixpacks] = selectedFixpacks.includes(selectedFixpacks);
              }
              this.selectedFixpacks = selectedFixpacks;
          });

  }

  ngOnInit()
  {
      this.dataSource = new FilesDataSource(this.wasFixpacksService);
  }

  ngOnDestroy()
  {
      this.onFixpacksChangedSubscription.unsubscribe();
      this.onSelectedFixPacksChangedSubscription.unsubscribe();
  }

  editFixPack(fixpack)
  {
    this.dialogRef = this.dialog.open(WasFixpackFormComponent, {
      panelClass: 'was-fixpack-form-dialog',
      data      : {
          fixpack: fixpack,
          action : 'edit'
      }
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
          if ( !response )
          {
              return;
          }
          // Get the new value and save it.
          this.wasFixpacksService.saveWasFixPack(response.getRawValue()).then((response) => {
              this.wasFixpacksService.getWasFixpacks();          
          });
      });     
  }

  /**
   * Delete TCI Code
   */
  deleteFixPack(fixpack)
  {
      this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
          if ( result )
          {
              this.wasFixpacksService.deleteFixPack(fixpack);
          }
          this.confirmDialogRef = null;
      });

  }

  onSelectedChange(fixpack)
  {
 //     this.wasFixpacksService.toggleSelectedTciCode(tcicode);
  }

  toggleStar(fixpack)
  {
  }

}

export class FilesDataSource extends DataSource<any>
{
  constructor(private wasFixpacksService: FixPacksService)
  {
      super();
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<any[]>
  {
      return this.wasFixpacksService.onFixPacksChanged;
  }

  disconnect()
  {
  }

}

