import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FixPacksService } from './was-fixpack.service';
import { WasVersionsService } from '../wasversions.service';
import { uditAnimations } from '../../../../../../core/animations';
import { FormControl, FormGroup } from '@angular/forms';
import { WasFixpackFormComponent } from './was-fixpack-form/was-fixpack-form.component';
import { MatDialog} from '@angular/material';
import 'rxjs/add/operator/distinctUntilChanged';
import "rxjs/add/operator/debounceTime";
import { Subscription } from 'rxjs/Subscription';
import { WasVersion, WasFixPack } from '../wasversions.model';

@Component({
  selector: 'app-was-fixpack',
  templateUrl: './was-fixpack.component.html',
  styleUrls: ['./was-fixpack.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WasFixpackComponent implements OnInit {

  wasversion = new WasVersion();
 // onWasVersionChanged: Subscription;
  hasSelectedFixpack: boolean;
//  searchInput: FormControl;
  dialogRef: any;
  onSelectedFixpackChangedSubscription: Subscription;

  constructor(
  //    private wasVersionsService: WasVersionsService,
      private wasFixpacksService: FixPacksService,
      public dialog: MatDialog
  )
  {
 //     this.searchInput = new FormControl('');
  }

  newFixPack()
  {
      this.dialogRef = this.dialog.open(WasFixpackFormComponent, {
          panelClass: 'was-fixpack-form-dialog',
          data      : {
              action: 'new'
          }
      });

      this.dialogRef.afterClosed()
          .subscribe((response: FormGroup) => {
              if ( !response )
              {
                  return;
              }

              this.wasFixpacksService.createWasFixpack(response.getRawValue())
                                  .then((response : WasFixPack) => {
                                       // Was Fixpack Created. Now Save this to the current was version
                                       this.wasFixpacksService.addWasFixpackToVersion(response);
                                  })
                                  .catch(err => {
                                      console.log("Got Error");
                                  })

          });

  }

  ngOnInit()
  {
        // Subscribe to update order on changes
        /*
        this.onWasVersionChanged =
        this.wasVersionsService.onWasVersionsChanged
            .subscribe(version => {
                this.wasversion = new WasVersion(version);
            });
*/
      this.wasversion = this.wasFixpacksService.wasversion;
      this.onSelectedFixpackChangedSubscription =
          this.wasFixpacksService.onSelectedFixPacksChanged
              .subscribe(selectedFixpack => {
                  this.hasSelectedFixpack = selectedFixpack.length > 0;
              });
  }


  ngOnDestroy()
  {
      this.onSelectedFixpackChangedSubscription.unsubscribe();
     // this.onWasVersionChanged.unsubscribe();
  }

}
