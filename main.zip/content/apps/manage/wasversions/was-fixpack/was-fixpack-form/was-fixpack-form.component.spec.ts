import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasFixpackFormComponent } from './was-fixpack-form.component';

describe('WasFixpackFormComponent', () => {
  let component: WasFixpackFormComponent;
  let fixture: ComponentFixture<WasFixpackFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasFixpackFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasFixpackFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
