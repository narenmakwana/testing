import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CalendarEvent } from 'angular-calendar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WasFixPack } from '../../wasversions.model';


@Component({
  selector: 'app-was-fixpack-form',
  templateUrl: './was-fixpack-form.component.html',
  styleUrls: ['./was-fixpack-form.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class WasFixpackFormComponent implements OnInit {

  dialogTitle: string;
  wasFixPackForm: FormGroup;
  action: string;
  wasFixPack: WasFixPack;
  dateRegex = '(January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2},\\s+\\d{4}';

  constructor(
      public dialogRef: MatDialogRef<WasFixpackFormComponent>,
      @Inject(MAT_DIALOG_DATA) private data: any,
      private formBuilder: FormBuilder
  )
  {
    if ( this.data.action === 'edit' )
    {
        this.dialogTitle = 'Edit FixPack';
        this.wasFixPack = this.data.fixpack;
    }
    else
    {
        this.dialogTitle = 'New FixPack';
        this.wasFixPack = new WasFixPack();
    }

    this.wasFixPackForm = this.createWasFixPackForm();
  }

  ngOnInit()
  {
  }

  createWasFixPackForm()
  {
      return this.formBuilder.group({
          _id          : [this.wasFixPack._id],
          fixpackId    : [this.wasFixPack.fixpackId],
          fixpackName  : [this.wasFixPack.fixpackName],
          complianceDeadline : [this.wasFixPack.complianceDeadline],
          location : [this.wasFixPack.location],
          ifix: [this.wasFixPack.ifix]
      });
  }

}
