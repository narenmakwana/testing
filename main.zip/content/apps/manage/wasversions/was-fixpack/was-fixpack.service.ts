import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Constants } from '../../../../../shared/config/constants';
import { WasFixPack } from '../wasversions.model';
import { UditUtils } from '../../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class FixPacksService implements Resolve<any>
{
    routeParams: any;
    wasversion: any;
 //   onWasVersionChanged: BehaviorSubject<any> = new BehaviorSubject({});
    onFixPacksChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSelectedFixPacksChanged: BehaviorSubject<any> = new BehaviorSubject([]);
   // onSearchTextChanged: Subject<any> = new Subject();
   // onFilterChanged: Subject<any> = new Subject();

    wasFixpacks: WasFixPack[];
    selectedFixPacks: string[] = [];

    searchText: string;
    filterBy: string;

    constructor(
        private http: HttpClient
    )
    {
    }

    /**
     * Resolve
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {
        this.routeParams = route.params;

        return new Promise((resolve, reject) => {

            Promise.all([
                this.getWasFixpacks()
            ]).then(
                ([files]) => {
                    resolve();
                },
                reject
            );
        });
    }

    getWasFixpacks(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getWasPackagesUrl() + "/" + this.routeParams.id)
                .subscribe((response: any) => {
                    this.wasversion = response;
                    // this.onWasVersionChanged.next(this.wasversion);

                    // this is the list of all fixpack ids
                    this.wasFixpacks = [];
                    this.wasversion.fixpacks.map(fixpack_id => {
                        // Retrieve the object from db.
                        this.getWasFixpackById(fixpack_id)
                            .then(response => {
                                // Got a response 
                                var fp = new WasFixPack(response);
                                this.wasFixpacks.push(fp);
                                this.onFixPacksChanged.next(this.wasFixpacks);
                            });              
                    });
                    resolve(this.wasFixpacks);
                }, reject);
        });
    }

    getWasFixpackById(id): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getWasFixpacksUrl() + "/" + id)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

    saveWasFixPack(fixpack)
    {
        let savewasfixpack =  Object.assign({}, fixpack);
        var id = savewasfixpack._id;
        delete savewasfixpack._id;
        return new Promise((resolve, reject) => {
            this.http.put(Constants.getWasFixpacksUrl() + "/" + id, savewasfixpack)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

    saveWasVersion(wasversion)
    {
        let savewasversion =  Object.assign({}, wasversion);
        var id = savewasversion._id;
        delete savewasversion._id;
        return new Promise((resolve, reject) => {
            this.http.put(Constants.getWasPackagesUrl() + "/" + id, savewasversion)
                .subscribe((response: any) => {
                    this.getWasFixpacks();
                    resolve(response);
                }, reject);
        });
    }

    addWasFixpackToVersion(wasfixpack)
    {        
        this.wasversion.fixpacks.push(wasfixpack._id);
        this.saveWasVersion(this.wasversion);
    }

    createWasFixpack(fixpack : any) {
        delete fixpack._id;
        return new Promise((resolve, reject) => {
            this.http.post(Constants.getWasFixpacksUrl(), fixpack)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

    deleteFixPack(fixpack : any) {
        var idx = 0;
        for(idx = 0; idx < this.wasversion.fixpacks.length; idx++)
        {
            if(this.wasversion.fixpacks[idx] === fixpack._id) {
                // found the element. delete it.
                this.wasversion.fixpacks.splice(idx, 1);
                break;
            }
        }
        this.saveWasVersion(this.wasversion);
    }

}
