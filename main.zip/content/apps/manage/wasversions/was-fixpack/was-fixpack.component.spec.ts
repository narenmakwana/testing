import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasFixpackComponent } from './was-fixpack.component';

describe('WasFixpackComponent', () => {
  let component: WasFixpackComponent;
  let fixture: ComponentFixture<WasFixpackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasFixpackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasFixpackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
