import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasIfixComponent } from './was-ifix.component';

describe('WasIfixComponent', () => {
  let component: WasIfixComponent;
  let fixture: ComponentFixture<WasIfixComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasIfixComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasIfixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
