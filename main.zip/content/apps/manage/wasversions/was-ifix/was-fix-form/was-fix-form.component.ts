import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-was-fix-form',
  templateUrl: './was-fix-form.component.html',
  styleUrls: ['./was-fix-form.component.scss']
})
export class WasFixFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
