import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasFixFormComponent } from './was-fix-form.component';

describe('WasFixFormComponent', () => {
  let component: WasFixFormComponent;
  let fixture: ComponentFixture<WasFixFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasFixFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasFixFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
