import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasIfixListComponent } from './was-ifix-list.component';

describe('WasIfixListComponent', () => {
  let component: WasIfixListComponent;
  let fixture: ComponentFixture<WasIfixListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasIfixListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasIfixListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
