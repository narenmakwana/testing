import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-was-ifix-list',
  templateUrl: './was-ifix-list.component.html',
  styleUrls: ['./was-ifix-list.component.scss']
})
export class WasIfixListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
