import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-was-ifix',
  templateUrl: './was-ifix.component.html',
  styleUrls: ['./was-ifix.component.scss']
})
export class WasIfixComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
