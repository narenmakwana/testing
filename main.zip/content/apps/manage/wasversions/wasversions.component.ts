import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { WasVersionsService } from './wasversions.service';
import { uditAnimations } from '../../../../../core/animations';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import 'rxjs/add/operator/distinctUntilChanged';
import "rxjs/add/operator/debounceTime";
import { Subscription } from 'rxjs/Subscription';
import { WasversionDialogFormComponent } from './wasversion-form/wasversion-form.component';

@Component({
  selector: 'manage-wasversions',
  templateUrl: './wasversions.component.html',
  styleUrls: ['./wasversions.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WasversionsComponent implements OnInit, OnDestroy {

  hasSelectedWasversions: boolean;
  searchInput: FormControl;
  dialogRef: any;
  onSelectedWasversionsChangedSubscription: Subscription;

  constructor(
      private wasVersionsService: WasVersionsService,
      public dialog: MatDialog
  )
  {
      this.searchInput = new FormControl('');
  }

  newWasVersion()
  {
      this.dialogRef = this.dialog.open(WasversionDialogFormComponent, {
          panelClass: 'wasversion-form-dialog',
          data      : {
              action: 'new'
          }
      });

      this.dialogRef.afterClosed()
          .subscribe((response: FormGroup) => {
              if ( !response )
              {
                  return;
              }

              this.wasVersionsService.createWasVersion(response.getRawValue());

          });
  }

  ngOnInit()
  {
      this.onSelectedWasversionsChangedSubscription =
          this.wasVersionsService.onSelectedWasVersionsChanged
              .subscribe(selectedWasversions => {
                  this.hasSelectedWasversions = selectedWasversions.length > 0;
              });

      this.searchInput.valueChanges
          .debounceTime(300)
          .distinctUntilChanged()
          .subscribe(searchText => {
              this.wasVersionsService.onSearchTextChanged.next(searchText);
          });
  }


  ngOnDestroy()
  {
      this.onSelectedWasversionsChangedSubscription.unsubscribe();
  }

}
