import { Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { WasVersionsService } from '../wasversions.service';
import { Observable } from 'rxjs/Observable';
import { MatDialog, MatDialogRef } from '@angular/material';
import { UditConfirmDialogComponent } from '../../../../../../core/components/confirm-dialog/confirm-dialog.component';
import { FormGroup } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';
import { uditAnimations } from '../../../../../../core/animations';
import { WasversionDialogFormComponent } from '../wasversion-form/wasversion-form.component';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'wasversions-wasversion-list',
  templateUrl: './wasversion-list.component.html',
  styleUrls: ['./wasversion-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WasversionListComponent implements OnInit, OnDestroy {

  @ViewChild('dialogContent') dialogContent: TemplateRef<any>;

  wasversions: any;
  // Data source is where the table is getting connected to.
  dataSource: FilesDataSource | null;
  displayedColumns = ['checkbox', 'fixpackId', 'fixpackName', 'version', 'releaseDate', 'location', 'buttons'];
  selectedWasversions: any[];
  checkboxes: {};

  onWasversionsChangedSubscription: Subscription;
  onSelectedWasversionsChangedSubscription: Subscription;

  dialogRef: any;

  confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

  constructor(
      private wasversionsService: WasVersionsService,
      public dialog: MatDialog
  )
  {
      this.onWasversionsChangedSubscription =
          this.wasversionsService.onWasVersionsChanged.subscribe(wasversions => {

              this.wasversions = wasversions;

              this.checkboxes = {};
              wasversions.map(wasversion => {
                  this.checkboxes[wasversion.id] = false;
              });
          });

      this.onSelectedWasversionsChangedSubscription =
          this.wasversionsService.onSelectedWasVersionsChanged.subscribe(selectedWasversions => {
              for ( const id in this.checkboxes )
              {
                  if ( !this.checkboxes.hasOwnProperty(id) )
                  {
                      continue;
                  }

                  this.checkboxes[id] = selectedWasversions.includes(id);
              }
              this.selectedWasversions = selectedWasversions;
          });

  }

  ngOnInit()
  {
      this.dataSource = new FilesDataSource(this.wasversionsService);
  }

  ngOnDestroy()
  {
      this.onWasversionsChangedSubscription.unsubscribe();
      this.onSelectedWasversionsChangedSubscription.unsubscribe();
  }

  editWasversion(wasversion)
  {
      this.dialogRef = this.dialog.open(WasversionDialogFormComponent, {
          panelClass: 'wasversion-form-dialog',
          data      : {
              wasversion: wasversion,
              action : 'edit'
          }
      });

      this.dialogRef.afterClosed()
      .subscribe(response => {
          if ( !response )
          {
              return;
          }
          // Get the new value and save it.
          this.wasversionsService.updateWasVersion(response.getRawValue());
      });    
  }

  /**
   * Delete Wasversion
   */
  deleteWasversion(wasversion)
  {
      this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
          if ( result )
          {
              this.wasversionsService.deleteWasVersion(wasversion);
          }
          this.confirmDialogRef = null;
      });

  }

  onSelectedChange(wasversionId)
  {
      this.wasversionsService.toggleSelectedWasVersion(wasversionId);
  }

  toggleStar(wasversionId)
  {
  }

}

export class FilesDataSource extends DataSource<any>
{
  constructor(private wasversionsService: WasVersionsService)
  {
      super();
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<any[]>
  {
      return this.wasversionsService.onWasVersionsChanged;
  }

  disconnect()
  {
  }

}
