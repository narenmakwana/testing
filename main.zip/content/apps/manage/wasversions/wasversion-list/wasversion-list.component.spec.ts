import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasversionListComponent } from './wasversion-list.component';

describe('WasversionListComponent', () => {
  let component: WasversionListComponent;
  let fixture: ComponentFixture<WasversionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasversionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasversionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
