import { Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { WlpVersionsService } from '../wlpversions.service';
import { Observable } from 'rxjs/Observable';
import { WlpversionFormDialogComponent } from '../wlpversion-form/wlpversion-form.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import { UditConfirmDialogComponent } from '../../../../../../core/components/confirm-dialog/confirm-dialog.component';
import { FormGroup } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';
import { uditAnimations } from '../../../../../../core/animations';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'wlpversions-wlpversion-list',
  templateUrl: './wlpversion-list.component.html',
  styleUrls: ['./wlpversion-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WlpversionListComponent implements OnInit, OnDestroy {

  @ViewChild('dialogContent') dialogContent: TemplateRef<any>;

  wlpversions: any;
  dataSource: FilesDataSource | null;
  displayedColumns = ['checkbox', 'fixpackId', 'fixpackName', 'java', 'complianceDeadline', 'location', 'buttons'];
  selectedWlpversions: any[];
  checkboxes: {};

  onWlpversionsChangedSubscription: Subscription;
  onSelectedWlpversionsChangedSubscription: Subscription;

  dialogRef: any;

  confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

  constructor(
      private wlpversionsService: WlpVersionsService,
      public dialog: MatDialog
  )
  {
      this.onWlpversionsChangedSubscription =
          this.wlpversionsService.onWlpVersionsChanged.subscribe(wlpversions => {

              this.wlpversions = wlpversions;

              this.checkboxes = {};
              wlpversions.map(wlpversion => {
                  this.checkboxes[wlpversion.id] = false;
              });
          });

      this.onSelectedWlpversionsChangedSubscription =
          this.wlpversionsService.onSelectedWlpVersionsChanged.subscribe(selectedWlpversions => {
              for ( const id in this.checkboxes )
              {
                  if ( !this.checkboxes.hasOwnProperty(id) )
                  {
                      continue;
                  }

                  this.checkboxes[id] = selectedWlpversions.includes(id);
              }
              this.selectedWlpversions = selectedWlpversions;
          });

  }

  ngOnInit()
  {
      this.dataSource = new FilesDataSource(this.wlpversionsService);
  }

  ngOnDestroy()
  {
      this.onWlpversionsChangedSubscription.unsubscribe();
      this.onSelectedWlpversionsChangedSubscription.unsubscribe();
  }

  editWlpversion(wlpversion)
  {
      this.dialogRef = this.dialog.open(WlpversionFormDialogComponent, {
          panelClass: 'wlpversion-form-dialog',
          data      : {
              wlpversion: wlpversion,
              action : 'edit'
          }
      });

      this.dialogRef.afterClosed()
          .subscribe(response => {
              if ( !response )
              {
                  return;
              }
              const actionType: string = response[0];
              const formData: FormGroup = response[1];
              switch ( actionType )
              {
                  /**
                   * Save
                   */
                  case 'save':

                      this.wlpversionsService.updateWlpVersion(formData.getRawValue());

                      break;
                  /**
                   * Delete
                   */
                  case 'delete':

                      this.deleteWlpversion(wlpversion);

                      break;
              }
          });
  }

  /**
   * Delete Wlpversion
   */
  deleteWlpversion(wlpversion)
  {
      this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
          if ( result )
          {
              this.wlpversionsService.deleteWlpVersion(wlpversion);
          }
          this.confirmDialogRef = null;
      });

  }

  onSelectedChange(wlpversionId)
  {
      this.wlpversionsService.toggleSelectedWlpVersion(wlpversionId);
  }

  toggleStar(wlpversionId)
  {
  }

}

export class FilesDataSource extends DataSource<any>
{
  constructor(private wlpversionsService: WlpVersionsService)
  {
      super();
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<any[]>
  {
      return this.wlpversionsService.onWlpVersionsChanged;
  }

  disconnect()
  {
  }

}
