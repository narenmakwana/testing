import { UditUtils } from '../../../../../core/uditUtils';

export class WlpVersion
{
    id: string;
    fixpackId: string;
    fixpackName: string;
    complianceDeadline: string;
    location: string;
    java: string;

    constructor(wlpversion)
    {
        {
            if(wlpversion._id)
                this.id = wlpversion._id;
            else
                this.id = wlpversion.id || UditUtils.generateGUID();
                
            this.fixpackId = wlpversion.fixpackId || '';
            this.fixpackName = wlpversion.fixpackName || '';
            this.complianceDeadline = wlpversion.complianceDeadline || '';
            this.location = wlpversion.location || '';
            this.java = wlpversion.java || '';
        }
    }
}
