import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { WlpVersion } from './wlpversions.model';
import { UditUtils } from '../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';
import { Constants } from '../../../../shared/config/constants';

@Injectable()
export class WlpVersionsService implements Resolve<any>
{
    onWlpVersionsChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSelectedWlpVersionsChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSearchTextChanged: Subject<any> = new Subject();
    onFilterChanged: Subject<any> = new Subject();

    wlpVersions: WlpVersion[];
    selectedWlpVersions: string[] = [];

    searchText: string;
    filterBy: string;

    constructor(private http: HttpClient)
    {
    }

    /**
     * The WlpVersions App Main Resolver
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {
        return new Promise((resolve, reject) => {

            Promise.all([
                this.getWlpVersions()
            ]).then(
                ([files]) => {

                    this.onSearchTextChanged.subscribe(searchText => {
                        this.searchText = searchText;
                        this.getWlpVersions();
                    });

                    this.onFilterChanged.subscribe(filter => {
                        this.filterBy = filter;
                        this.getWlpVersions();
                    });

                    resolve();

                },
                reject
            );
        });
    }

    getWlpVersions(): Promise<any>
    {
        return new Promise((resolve, reject) => {
                this.http.get(Constants.getWlpVersionsUrl())
                    .subscribe((response: any) => {

                        this.wlpVersions = response.items.map(wlpVersion => {
                            return new WlpVersion(wlpVersion);
                        });

                        if ( this.searchText && this.searchText !== '' )
                        {
                            this.wlpVersions = UditUtils.filterArrayByString(this.wlpVersions, this.searchText);
                        }

                        this.onWlpVersionsChanged.next(this.wlpVersions);
                        resolve(this.wlpVersions);
                    }, reject);
            }
        );
    }

    /**
     * Toggle selected wlpVersion by id
     * @param id
     */
    toggleSelectedWlpVersion(id)
    {
        // First, check if we already have that todo as selected...
        if ( this.selectedWlpVersions.length > 0 )
        {
            const index = this.selectedWlpVersions.indexOf(id);

            if ( index !== -1 )
            {
                this.selectedWlpVersions.splice(index, 1);

                // Trigger the next event
                this.onSelectedWlpVersionsChanged.next(this.selectedWlpVersions);

                // Return
                return;
            }
        }

        // If we don't have it, push as selected
        this.selectedWlpVersions.push(id);

        // Trigger the next event
        this.onSelectedWlpVersionsChanged.next(this.selectedWlpVersions);
    }

    /**
     * Toggle select all
     */
    toggleSelectAll()
    {
        if ( this.selectedWlpVersions.length > 0 )
        {
            this.deselectWlpVersions();
        }
        else
        {
            this.selectWlpVersions();
        }
    }

    selectWlpVersions(filterParameter?, filterValue?)
    {
        this.selectedWlpVersions = [];

        // If there is no filter, select all todos
        if ( filterParameter === undefined || filterValue === undefined )
        {
            this.selectedWlpVersions = [];
            this.wlpVersions.map(wlpVersion => {
                this.selectedWlpVersions.push(wlpVersion.id);
            });
        }

        // Trigger the next event
        this.onSelectedWlpVersionsChanged.next(this.selectedWlpVersions);
    }

    updateWlpVersion(wlpVersion)
    {
        let id = wlpVersion.id;
        // remove the id to allow the update.
        delete wlpVersion.id;
        return new Promise((resolve, reject) => {

            this.http.put(Constants.getWlpVersionsUrl() + id, {...wlpVersion})
                .subscribe(response => {
                    this.getWlpVersions();
                    resolve(response);
                });
        });
    }

    createWlpVersion(wlpVersion)
    {
        // We want to remove the ID's if any because we want Mongo to assign one.
        if(wlpVersion.id)
            delete wlpVersion.id;
        return new Promise((resolve, reject) => {

            this.http.post(Constants.getWlpVersionsUrl(), {...wlpVersion})
                .subscribe(response => {
                    this.getWlpVersions();
                    resolve(response);
                });
        });
    }

    removeWlpVersion(wlpVersion)
    {
        let id = wlpVersion.id;
        // remove the id to allow the update.
        delete wlpVersion.id;
        return new Promise((resolve, reject) => {

            this.http.delete(Constants.getWlpVersionsUrl() + id, {...wlpVersion})
                .subscribe(response => {
                    this.getWlpVersions();
                    resolve(response);
                });
        });
    }

    deselectWlpVersions()
    {
        this.selectedWlpVersions = [];

        // Trigger the next event
        this.onSelectedWlpVersionsChanged.next(this.selectedWlpVersions);
    }

    deleteWlpVersion(wlpVersion)
    {
        const wlpVersionIndex = this.wlpVersions.indexOf(wlpVersion);
        this.wlpVersions.splice(wlpVersionIndex, 1);
        this.removeWlpVersion(wlpVersion);
        this.onWlpVersionsChanged.next(this.wlpVersions);
    }

    deleteSelectedWlpVersions()
    {
        for ( const wlpVersionId of this.selectedWlpVersions )
        {
            const wlpVersion = this.wlpVersions.find(_wlpVersion => {
                return _wlpVersion.id === wlpVersionId;
            });
            const wlpVersionIndex = this.wlpVersions.indexOf(wlpVersion);
            this.wlpVersions.splice(wlpVersionIndex, 1);
            this.removeWlpVersion(wlpVersion);
        }
        this.onWlpVersionsChanged.next(this.wlpVersions);
        this.deselectWlpVersions();
    }

}
