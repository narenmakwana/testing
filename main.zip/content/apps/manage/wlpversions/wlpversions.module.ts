import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { WlpversionsComponent } from './wlpversions.component';
import { WlpversionFormDialogComponent } from './wlpversion-form/wlpversion-form.component';
import { WlpversionListComponent } from './wlpversion-list/wlpversion-list.component';
import { WlpVersionsSelectedBarComponent } from './selected-bar/selected-bar.component';
import { WlpVersionsService } from './wlpversions.service';

const routes: Routes = [
  {
      path     : 'manage/wlpversions',
      component: WlpversionsComponent,
      resolve  : {
          contacts: WlpVersionsService
      }
  }
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    WlpversionsComponent, 
    WlpversionFormDialogComponent, 
    WlpversionListComponent, 
    WlpVersionsSelectedBarComponent
  ],
  providers      : [
    WlpVersionsService
  ],
  entryComponents: [WlpversionFormDialogComponent]
})
export class WlpversionsModule { }
