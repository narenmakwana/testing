import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CalendarEvent } from 'angular-calendar';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { WlpVersion } from '../wlpversions.model';

@Component({
    selector: 'manage-wlpversion-form',
    templateUrl: './wlpversion-form.component.html',
    styleUrls: ['./wlpversion-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class WlpversionFormDialogComponent implements OnInit {

    event: CalendarEvent;
    dialogTitle: string;
    wlpVersionForm: FormGroup;
    action: string;
    wlpversion: WlpVersion;
    dateRegex = '(January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2},\\s+\\d{4}';

    constructor(
        public dialogRef: MatDialogRef<WlpversionFormDialogComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private formBuilder: FormBuilder
    ) {
        this.action = data.action;

        if (this.action === 'edit') {
            this.dialogTitle = 'Edit Liberty Version';
            this.wlpversion = data.wlpversion;
        }
        else {
            this.dialogTitle = 'New Liberty Version';
            this.wlpversion = new WlpVersion({});
        }

        this.wlpVersionForm = this.createWlpVersionForm();
    }

    ngOnInit() {
    }

    createWlpVersionForm() {
        return this.formBuilder.group({
            id: [this.wlpversion.id],
            fixpackId: [this.wlpversion.fixpackId],
            fixpackName: [this.wlpversion.fixpackName],
            complianceDeadline: [this.wlpversion.complianceDeadline],
            location: [this.wlpversion.location],
            java: [this.wlpversion.java]
        });
    }
}
