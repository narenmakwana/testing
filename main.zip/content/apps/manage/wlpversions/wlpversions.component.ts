import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { WlpVersionsService } from './wlpversions.service';
import { uditAnimations } from '../../../../../core/animations';
import { FormControl, FormGroup } from '@angular/forms';
import { WlpversionFormDialogComponent } from './wlpversion-form/wlpversion-form.component';
import { MatDialog } from '@angular/material';
import 'rxjs/add/operator/distinctUntilChanged';
import "rxjs/add/operator/debounceTime";
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'manage-wlpversions',
  templateUrl: './wlpversions.component.html',
  styleUrls: ['./wlpversions.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class WlpversionsComponent implements OnInit, OnDestroy {

  hasSelectedWlpversions: boolean;
  searchInput: FormControl;
  dialogRef: any;
  onSelectedWlpversionsChangedSubscription: Subscription;

  constructor(
      private wlpVersionsService: WlpVersionsService,
      public dialog: MatDialog
  )
  {
      this.searchInput = new FormControl('');
  }

  newWlpVersion()
  {
      this.dialogRef = this.dialog.open(WlpversionFormDialogComponent, {
          panelClass: 'wlpversion-form-dialog',
          data      : {
              action: 'new'
          }
      });

      this.dialogRef.afterClosed()
          .subscribe((response: FormGroup) => {
              if ( !response )
              {
                  return;
              }

              this.wlpVersionsService.createWlpVersion(response.getRawValue());

          });

  }

  ngOnInit()
  {
      this.onSelectedWlpversionsChangedSubscription =
          this.wlpVersionsService.onSelectedWlpVersionsChanged
              .subscribe(selectedWlpversions => {
                  this.hasSelectedWlpversions = selectedWlpversions.length > 0;
              });

      this.searchInput.valueChanges
          .debounceTime(300)
          .distinctUntilChanged()
          .subscribe(searchText => {
              this.wlpVersionsService.onSearchTextChanged.next(searchText);
          });
  }


  ngOnDestroy()
  {
      this.onSelectedWlpversionsChangedSubscription.unsubscribe();
  }

}
