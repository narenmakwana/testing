import { Component, OnInit } from '@angular/core';
import { WlpVersionsService } from '../wlpversions.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { UditConfirmDialogComponent } from '../../../../../../core/components/confirm-dialog/confirm-dialog.component';


@Component({
  selector: 'wlpversions-selected-bar',
  templateUrl: './selected-bar.component.html',
  styleUrls: ['./selected-bar.component.scss']
})
export class WlpVersionsSelectedBarComponent implements OnInit {

  selectedWlpVersions: string[];
  hasSelectedWlpVersions: boolean;
  isIndeterminate: boolean;
  confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

  constructor(
      private wlpVersionsService: WlpVersionsService,
      public dialog: MatDialog
  )
  {
      this.wlpVersionsService.onSelectedWlpVersionsChanged
          .subscribe(selectedWlpVersions => {
              this.selectedWlpVersions = selectedWlpVersions;
              setTimeout(() => {
                  this.hasSelectedWlpVersions = selectedWlpVersions.length > 0;
                  this.isIndeterminate = (selectedWlpVersions.length !== this.wlpVersionsService.wlpVersions.length && selectedWlpVersions.length > 0);
              }, 0);
          });

  }

  ngOnInit()
  {
  }

  selectAll()
  {
      this.wlpVersionsService.selectWlpVersions();
  }

  deselectAll()
  {
      this.wlpVersionsService.deselectWlpVersions();
  }

  deleteSelectedWlpVersions()
  {
      this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete all selected versions?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
          if ( result )
          {
              this.wlpVersionsService.deleteSelectedWlpVersions();
          }
          this.confirmDialogRef = null;
      });
  }

}
