import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { TciCodesService } from './tci-codes.service';
import { uditAnimations } from '../../../../../../core/animations';
import { FormControl, FormGroup } from '@angular/forms';
import { TciCodesFormDialogComponent } from './tci-codes-form/tci-codes-form.component';
import { MatDialog } from '@angular/material';
import 'rxjs/add/operator/distinctUntilChanged';
import "rxjs/add/operator/debounceTime";
import { Subscription } from 'rxjs/Subscription';
import { Dcio } from './tci-codes.model';
import { DcioService } from '../dcio/dcio.service';


@Component({
  selector: 'manage-tcicodes',
  templateUrl: './tci-codes.component.html',
  styleUrls: ['./tci-codes.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : uditAnimations
})
export class TcicodesComponent implements OnInit, OnDestroy {

  dcio = new Dcio();
  onDcioChanged: Subscription;
  hasSelectedTcicodes: boolean;
  searchInput: FormControl;
  dialogRef: any;
  onSelectedTcicodesChangedSubscription: Subscription;

  constructor(
      private tciCodesService: TciCodesService,
      private dcioService: DcioService,
      public dialog: MatDialog
  )
  {
      this.searchInput = new FormControl('');
  }

  newTciCode()
  {
      this.dialogRef = this.dialog.open(TciCodesFormDialogComponent, {
          panelClass: 'tci-form-dialog',
          data      : {
              action: 'new'
          }
      });

      this.dialogRef.afterClosed()
          .subscribe((response: FormGroup) => {
              if ( !response )
              {
                  return;
              }

              this.tciCodesService.createTciCodes(response.getRawValue());

          });

  }

  ngOnInit()
  {
        // Subscribe to update order on changes
        this.onDcioChanged =
        this.tciCodesService.onDcioChanged
            .subscribe(dcio => {
                this.dcio = new Dcio(dcio);
            });

      this.onSelectedTcicodesChangedSubscription =
          this.tciCodesService.onSelectedTciCodesChanged
              .subscribe(selectedTcicodes => {
                  this.hasSelectedTcicodes = selectedTcicodes.length > 0;
              });

      this.searchInput.valueChanges
          .debounceTime(300)
          .distinctUntilChanged()
          .subscribe(searchText => {
              this.tciCodesService.onSearchTextChanged.next(searchText);
          });
  }


  ngOnDestroy()
  {
      this.onSelectedTcicodesChangedSubscription.unsubscribe();
      this.onDcioChanged.unsubscribe();
  }

}
