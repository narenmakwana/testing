import { UditUtils } from '../../../../../../core/uditUtils';

export class Dcio
{
    _id: string;
    dcio: string;
    supportingOrg: string;
    applications: any[];

    constructor(initData?)
    {
        if(initData) {
            this._id = initData._id;
            this.dcio = initData.dcio;
            this.supportingOrg = initData.supportingOrg;
            this.applications = initData.applications;            
        }
        else {
            this.dcio = "";
            this.supportingOrg = "";
            this.applications = [];
        }
    }
}

export class TciCode
{
    tciCode: string;
    busUnit: string;
    description: string;
    contactEmail: string;
    contactGroupEmail: string;
    contactName: string;
    appName: string;

    constructor(initData?) {
        if(initData){
            this.tciCode = (initData.tciCode) ? initData.tciCode : "" ;
            this.description = (initData.description) ? initData.description : "";
            this.contactEmail = (initData.contactEmail) ? initData.contactEmail : "";
            this.contactGroupEmail = (initData.contactGroupEmail) ? initData.contactGroupEmail : "";
            this.contactName = (initData.contactName)? initData.contactName : "";
            this.appName = (initData.appName)? initData.appName : "";
            this.busUnit = (initData.busUnit)? initData.busUnit : "";
        }
        else {
            this.tciCode = "";
            this.description = "";
            this.contactEmail = "";
            this.contactGroupEmail = "";
            this.contactName = "";
            this.appName = "";
            this.busUnit = "";
        }
    }
}
