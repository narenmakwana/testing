import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TciCodesListComponent } from './tci-codes-list.component';

describe('TciCodesListComponent', () => {
  let component: TciCodesListComponent;
  let fixture: ComponentFixture<TciCodesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TciCodesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TciCodesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
