import { Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { TciCodesService } from '../tci-codes.service';
import { Observable } from 'rxjs/Observable';
import { TciCodesFormDialogComponent } from '../tci-codes-form/tci-codes-form.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import { UditConfirmDialogComponent } from '../../../../../../../core/components/confirm-dialog/confirm-dialog.component';
import { FormGroup } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';
import { uditAnimations } from '../../../../../../../core/animations';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'app-tci-codes-list',
    templateUrl: './tci-codes-list.component.html',
    styleUrls: ['./tci-codes-list.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations: uditAnimations
})
export class TciCodesListComponent implements OnInit, OnDestroy {

    @ViewChild('dialogContent') dialogContent: TemplateRef<any>;

    tcicodes: any;
    dataSource: FilesDataSource | null;
    displayedColumns = ['checkbox', 'tciCode', 'busUnit', 'contactName', 'appName', 'contactEmail', 'contactGroupEmail', 'buttons'];
    selectedTcicodes: any[];
    checkboxes: {};

    onTciCodesChangedSubscription: Subscription;
    onSelectedTciCodesChangedSubscription: Subscription;

    dialogRef: any;

    confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

    constructor(
        private tcicodesService: TciCodesService,
        public dialog: MatDialog
    ) {
        this.onTciCodesChangedSubscription =
            this.tcicodesService.onTciCodesChanged.subscribe(tcicodes => {

                this.tcicodes = tcicodes;

                this.checkboxes = {};
                tcicodes.map(tcicodes => {
                    this.checkboxes[tcicodes.tciCode] = false;
                });
            });

        this.onSelectedTciCodesChangedSubscription =
            this.tcicodesService.onSelectedTciCodesChanged.subscribe(selectedTcicodes => {
                for (const tciCode in this.checkboxes) {
                    if (!this.checkboxes.hasOwnProperty(tciCode)) {
                        continue;
                    }

                    this.checkboxes[tciCode] = selectedTcicodes.includes(tciCode);
                }
                this.selectedTcicodes = selectedTcicodes;
            });

    }

    ngOnInit() {
        this.dataSource = new FilesDataSource(this.tcicodesService);
    }

    ngOnDestroy() {
        this.onTciCodesChangedSubscription.unsubscribe();
        this.onSelectedTciCodesChangedSubscription.unsubscribe();
    }

    editTcicode(tcicode) {
        this.dialogRef = this.dialog.open(TciCodesFormDialogComponent, {
            panelClass: 'tci-form-dialog',
            data: {
                tcicode: tcicode,
                action: 'edit'
            }
        });

        this.dialogRef.afterClosed()
            .subscribe(response => {
                if (!response) {
                    return;
                }
                // Get the new value and save it.
                this.tcicodesService.updateTciCode(response.getRawValue());
            });
    }

    /**
     * Delete TCI Code
     */
    deleteTciCode(tcicode) {
        this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.tcicodesService.deleteTciCode(tcicode);
            }
            this.confirmDialogRef = null;
        });

    }

    onSelectedChange(tcicode) {
        //     this.tcicodesService.toggleSelectedTciCode(tcicode);
    }

    toggleStar(tcicode) {
    }

}

export class FilesDataSource extends DataSource<any>
{
    constructor(private tcicodesService: TciCodesService) {
        super();
    }

    /** Connect function called by the table to retrieve one stream containing the data to render. */
    connect(): Observable<any[]> {
        return this.tcicodesService.onTciCodesChanged;
    }

    disconnect() {
    }

}

