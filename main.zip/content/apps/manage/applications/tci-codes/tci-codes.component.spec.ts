import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TciCodesComponent } from './tci-codes.component';

describe('TciCodesComponent', () => {
  let component: TciCodesComponent;
  let fixture: ComponentFixture<TciCodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TciCodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TciCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
