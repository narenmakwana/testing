import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CalendarEvent } from 'angular-calendar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TciCode } from '../../tci-codes/tci-codes.model';
import { DcioService } from '../../dcio/dcio.service';


@Component({
    selector: 'app-tci-codes-form',
    templateUrl: './tci-codes-form.component.html',
    styleUrls: ['./tci-codes-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TciCodesFormDialogComponent implements OnInit {

    dialogTitle: string;
    tciCodeForm: FormGroup;
    action: string;
    tciCode: TciCode;
    appName: string;
    busUnits: string[];
    busApps: string[];

    constructor(
        public dialogRef: MatDialogRef<TciCodesFormDialogComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private formBuilder: FormBuilder,
        private dcioService: DcioService
    ) {
        if (this.data.action === 'edit') {
            this.dialogTitle = 'Edit TCI Code';
            this.tciCode = this.data.tcicode;
        }
        else {
            this.dialogTitle = 'New TCI Code';
            this.tciCode = new TciCode({});
        }
        this.busUnits = this.dcioService.busUnits;
        this.tciCodeForm = this.createTciCodeForm();
    }

    ngOnInit() {
        this.busUnits = this.dcioService.busUnits;
    }

    _createFilterFor = function (query) {
        return function filterFn(state) {
            return (('' + state).toLowerCase().match(query.toLowerCase()));
        }
    }

    createTciCodeForm() {
        return this.formBuilder.group({
            tciCode: [this.tciCode.tciCode],
            description: [this.tciCode.description],
            contactName: [this.tciCode.contactName],
            contactEmail: [this.tciCode.contactEmail],
            contactGroupEmail: [this.tciCode.contactGroupEmail],
            appName: [this.tciCode.appName],
            busUnit: [this.tciCode.busUnit]
        });
    }

}
