import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Constants } from '../../../../../shared/config/constants';
import { TciCode } from './tci-codes.model';
import { UditUtils } from '../../../../../../core/uditUtils';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class TciCodesService implements Resolve<any>
{
    routeParams: any;
    dcio: any;
    onDcioChanged: BehaviorSubject<any> = new BehaviorSubject({});
    onTciCodesChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSelectedTciCodesChanged: BehaviorSubject<any> = new BehaviorSubject([]);
    onSearchTextChanged: Subject<any> = new Subject();
    onFilterChanged: Subject<any> = new Subject();

    tciCodes: TciCode[];
    selectedTciCodes: string[] = [];

    searchText: string;
    filterBy: string;

    constructor(
        private http: HttpClient
    )
    {
    }

    /**
     * Resolve
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {

        this.routeParams = route.params;

        return new Promise((resolve, reject) => {

            Promise.all([
                this.getDcio()
            ]).then(
                () => {
                    resolve();
                },
                reject
            );
        });
    }

    getDcio(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getDcioUrl() + "/" + this.routeParams.id)
                .subscribe((response: any) => {
                    this.dcio = response;
                    this.onDcioChanged.next(this.dcio);
                    this.onTciCodesChanged.next(this.dcio.applications);
                    resolve(response);
                }, reject);
        });
    }

    saveDcio(dcio)
    {
        let savedcio =  Object.assign({}, dcio);
        var id = savedcio._id;
        delete savedcio._id;
        return new Promise((resolve, reject) => {
            this.http.put(Constants.getDcioUrl() + "/" + id, savedcio)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

    addDcio(dcio)
    {        
        return new Promise((resolve, reject) => {
            this.http.post(Constants.getDcioUrl(), dcio)
                .subscribe((response: any) => {
                    resolve(response);
                }, reject);
        });
    }

    createTciCodes(tciCode : any) {
       this.dcio.applications.push(tciCode);
       this.saveDcio(this.dcio);
       this.onTciCodesChanged.next(this.dcio.applications);
    }

    updateTciCode(tciCode : any) {
        var idx = 0;
        for(idx = 0; idx < this.dcio.applications.length; idx++)
        {
            if(this.dcio.applications[idx].tciCode === tciCode.tciCode) {
                // found the element. update it.
                this.dcio.applications[idx] = tciCode;
            }
        }
        this.saveDcio(this.dcio);
        this.onTciCodesChanged.next(this.dcio.applications);
    }

    deleteTciCode(tciCode : any) {
        var idx = 0;
        for(idx = 0; idx < this.dcio.applications.length; idx++)
        {
            if(this.dcio.applications[idx].tciCode === tciCode.tciCode) {
                // found the element. delete it.
                this.dcio.applications.splice(idx, 1);
                break;
            }
        }
        this.saveDcio(this.dcio);
        this.onTciCodesChanged.next(this.dcio.applications);
    }

}
