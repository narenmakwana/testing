import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Constants } from '../../../../../shared/config/constants';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DcioService {

  dcios: any[];
  busDcios: string[];
  busSuppOrgs: string[];
  busApps: string[];
  busUnits: string[] = [];
  onDciosChanged: BehaviorSubject<any> = new BehaviorSubject({});

  constructor(private http: HttpClient) { }

      /**
     * Resolve
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @returns {Observable<any> | Promise<any> | any}
     */
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any
    {

        return new Promise((resolve, reject) => {

            Promise.all([
                this.getDcios()
            ]).then(
                () => {
                    this.getBusDcios().then((resp) => {
                        this.busDcios = resp;
                    });
                    this.getBusSuppOrgs().then((resp) => {
                        this.busSuppOrgs = resp;
                    });
                    this.getBusUnits().then((resp) => {
                        this.busUnits = resp;
                    });
                    resolve();
                },
                reject
            );
        });
    }

    getDcios(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getDcioUrl())
                .subscribe((response: any) => {
                    this.dcios = response.items;
                    this.onDciosChanged.next(this.dcios);
                    resolve(response);
                }, reject);
        });
    }

    getBusDcios(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getBusDcioUrl())
                .subscribe((response: any) => {
                    var resp = JSON.parse(response);
                    var busDcios = [];
                    resp.result.forEach((item) => {
                        busDcios.push(item.u_name);
                    });
                    resolve(busDcios);
                }, reject);
        });
    }

    getBusUnits(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getBusUnitsUrl())
                .subscribe((response: any) => {
                    var resp = JSON.parse(response);
                    var busUnits = [];
                    resp.result.forEach((item) => {
                        busUnits.push(item.name);      
                    });
                    resolve(busUnits);
                }, reject);
        });
    }

    getBusSuppOrgs(): Promise<any>
    {
        return new Promise((resolve, reject) => {
            this.http.get(Constants.getBusSupportingOrgsUrl())
                .subscribe((response: any) => {
                    var resp = JSON.parse(response);
                    var busSuppOrgs = [];
                    resp.result.forEach((item) => {
                        busSuppOrgs.push(item.u_name);
                    });
                    resolve(busSuppOrgs);
                }, reject);
        });
    }

    updateDcio(dcio)
    {
        let savedcio =  Object.assign({}, dcio);
        var id = savedcio._id;
        delete savedcio._id;
        return new Promise((resolve, reject) => {

            this.http.put(Constants.getDcioUrl() + "/" + id, {...savedcio})
                .subscribe(response => {
                    this.getDcios();
                    resolve(response);
                });
        });
    }

    createDcio(dcio)
    {
        // We want to remove the ID's if any because we want Mongo to assign one.
        delete dcio._id;
        dcio.applications = [];
        return new Promise((resolve, reject) => {

            this.http.post(Constants.getDcioUrl(), {...dcio})
                .subscribe(response => {
                    this.getDcios();
                    resolve(response);
                });
        });
    }

    removeDcio(dcio)
    {
        let savedcio =  Object.assign({}, dcio);
        var id = savedcio._id;
        delete savedcio._id;
        return new Promise((resolve, reject) => {

            this.http.delete(Constants.getDcioUrl() + "/" + id, {...savedcio})
                .subscribe(response => {
                    this.getDcios();
                    resolve(response);
                });
        });
    }

    

}
