import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import { uditAnimations } from '../../../../../../core/animations';
import { MatPaginator, MatSort } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/observable/fromEvent';
import { UditUtils } from '../../../../../../core/uditUtils';
import { DcioService } from './dcio.service';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { DcioFormDialogComponent } from './dcio-form/dcio-form.component';
import { AuthenticationService } from '../../../../pages/authentication/authentication.service';
import { UditConfirmDialogComponent } from '../../../../../../core/components/confirm-dialog/confirm-dialog.component';


@Component({
  selector: 'app-dcio',
  templateUrl: './dcio.component.html',
  styleUrls: ['./dcio.component.scss'],
  animations : uditAnimations
})
export class DcioComponent implements OnInit
{
    dataSource: FilesDataSource | null;
    displayedColumns = ['dcio', 'supportingOrg', 'tciCodes', 'buttons'];
    dialogRef: any;
    confirmDialogRef: MatDialogRef<UditConfirmDialogComponent>;

    isAdmin : boolean = false;

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild('filter') filter: ElementRef;
    @ViewChild(MatSort) sort: MatSort;

    constructor(
        private dcioService: DcioService,
        private authService: AuthenticationService,
        public dialog: MatDialog
    )
    {
    }

    ngOnInit()
    {
        this.dataSource = new FilesDataSource(this.dcioService, this.paginator, this.sort);

        Observable.fromEvent(this.filter.nativeElement, 'keyup')
                  .debounceTime(150)
                  .distinctUntilChanged()
                  .subscribe(() => {
                      if ( !this.dataSource )
                      {
                          return;
                      }
                      this.dataSource.filter = this.filter.nativeElement.value;
                  });
        this.isAdmin = this.authService.isAdmin();
    }

    newDcio()
    {
        this.dialogRef = this.dialog.open(DcioFormDialogComponent, {
            panelClass: 'dcio-form-dialog',
            data      : {
                action: 'new'
            }
        });
  
        this.dialogRef.afterClosed()
            .subscribe((response: FormGroup) => {
                if ( !response )
                {
                    return;
                }
  
                this.dcioService.createDcio(response.getRawValue());
            });
  
    }

    editDcio(dcio)
    {
        this.dialogRef = this.dialog.open(DcioFormDialogComponent, {
            panelClass: 'dcio-form-dialog',
            data      : {
                action: 'edit',
                application: dcio
            }
        });
  
        this.dialogRef.afterClosed()
            .subscribe((response: FormGroup) => {
                if ( !response )
                {
                    return;
                }
  
                this.dcioService.updateDcio(response[1].getRawValue());
            });
  
    }

      /**
        * Delete TCI Code
      */
    deleteDcio(dcio)
    {
      this.confirmDialogRef = this.dialog.open(UditConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
        if ( result )
        {
            this.dcioService.removeDcio(dcio);
        }
        this.confirmDialogRef = null;
      });

  }

}

export class FilesDataSource extends DataSource<any>
{
    _filterChange = new BehaviorSubject('');
    _filteredDataChange = new BehaviorSubject('');

    get filteredData(): any
    {
        return this._filteredDataChange.value;
    }

    set filteredData(value: any)
    {
        this._filteredDataChange.next(value);
    }

    get filter(): string
    {
        return this._filterChange.value;
    }

    set filter(filter: string)
    {
        this._filterChange.next(filter);
    }

    constructor(
        private dcioService: DcioService,
        private _paginator: MatPaginator,
        private _sort: MatSort
    )
    {
        super();
        this.filteredData = this.dcioService.dcios;
    }

    /** Connect function called by the table to retrieve one stream containing the data to render. */
    connect(): Observable<any[]>
    {
        const displayDataChanges = [
            this.dcioService.onDciosChanged,
            this._paginator.page,
            this._filterChange,
            this._sort.sortChange
        ];
        return Observable.merge(...displayDataChanges).map(() => {
            let data = this.dcioService.dcios.slice();

            data = this.filterData(data);

            this.filteredData = [...data];

            data = this.sortData(data).reverse();

            // Grab the page's slice of data.
            const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
            return data.splice(startIndex, this._paginator.pageSize);
        });

    }

    filterData(data)
    {
        if ( !this.filter )
        {
            return data;
        }
        return UditUtils.filterArrayByString(data, this.filter);
    }

    sortData(data): any[]
    {
        if ( !this._sort.active || this._sort.direction === '' )
        {
            return data;
        }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch ( this._sort.active )
            {
                case 'dcio':
                    [propertyA, propertyB] = [a.id, b.id];
                    break;
                case 'supportingOrg':
                    [propertyA, propertyB] = [a.reference, b.reference];
                    break;
            }

            const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
        });
    }

    disconnect()
    {
    }
}
