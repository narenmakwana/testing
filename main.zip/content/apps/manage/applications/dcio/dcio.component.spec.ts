import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcioComponent } from './dcio.component';

describe('DcioComponent', () => {
  let component: DcioComponent;
  let fixture: ComponentFixture<DcioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
