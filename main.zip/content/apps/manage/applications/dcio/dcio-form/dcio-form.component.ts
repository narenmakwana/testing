import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CalendarEvent } from 'angular-calendar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Dcio } from '../../tci-codes/tci-codes.model';
import { DcioService } from '../dcio.service';

@Component({
  selector: 'app-dcio-form',
  templateUrl: './dcio-form.component.html',
  styleUrls: ['./dcio-form.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DcioFormDialogComponent implements OnInit {

  event: CalendarEvent;
  dialogTitle: string;
  dcioForm: FormGroup;
  action: string;
  dcio: Dcio;
  busDcios : string[];
  busOrgs: string[];

  constructor(
      public dialogRef: MatDialogRef<DcioFormDialogComponent>,
      @Inject(MAT_DIALOG_DATA) private data: any,
      private formBuilder: FormBuilder,
      private dcioService : DcioService
  )
  {
      this.action = data.action;

      if ( this.action === 'edit' )
      {
          this.dialogTitle = 'Edit DCIO';
          this.dcio = data.application;
      }
      else
      {
          this.dialogTitle = 'New DCIO';
          this.dcio = new Dcio({});
      }

      this.dcioForm = this.createDcioForm();
  }

  ngOnInit()
  {
      this.busDcios = this.dcioService.busDcios;
      this.busOrgs = this.dcioService.busSuppOrgs;
  }

  createDcioForm()
  {
      return this.formBuilder.group({
          _id           : [this.dcio._id],
          dcio    : [this.dcio.dcio],
          supportingOrg  : [this.dcio.supportingOrg],
          applications: [this.dcio.applications]
      });
  }

}
