import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcioFormComponent } from './dcio-form.component';

describe('DcioFormComponent', () => {
  let component: DcioFormComponent;
  let fixture: ComponentFixture<DcioFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcioFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcioFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
