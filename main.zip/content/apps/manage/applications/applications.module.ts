import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../../core/modules/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { DcioComponent } from './dcio/dcio.component';
import { TcicodesComponent } from './tci-codes/tci-codes.component';
import { DcioService } from './dcio/dcio.service';
import { TciCodesService } from './tci-codes/tci-codes.service';
import { DcioFormDialogComponent } from './dcio/dcio-form/dcio-form.component';
import { TciCodesFormDialogComponent } from './tci-codes/tci-codes-form/tci-codes-form.component';
import { TciCodesListComponent } from './tci-codes/tci-codes-list/tci-codes-list.component';

const routes: Routes = [
  {
      path     : 'manage/applications',
      component: DcioComponent,
      resolve  : {
          data: DcioService
      }
  },
  {
    path     : 'manage/applications/:id',
    component: TcicodesComponent,
    resolve  : {
        data: TciCodesService
    }
}
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [DcioComponent, TcicodesComponent, DcioFormDialogComponent, TciCodesFormDialogComponent, TciCodesListComponent],
  providers      : [
    DcioService, TciCodesService
  ],
  entryComponents: [DcioFormDialogComponent, TciCodesFormDialogComponent]
})
export class ApplicationsModule { }
