import { NgModule } from '@angular/core';
import { AdvSearchModule } from './search/adv-search/adv-search.module';
import { SharedModule } from '../../../core/modules/shared.module';
import { TopologyModule } from './topology/topology.module';

// Load our modules here
import { DashboardsModule } from './dashboards/dashboards.module';
import { LibertyModule } from './design/liberty/liberty.module';
import { LinuxModule } from './design/linux/linux.module';
import { WasNdModule } from './design/was-nd/was-nd.module';
import { WlpversionsModule } from './manage/wlpversions/wlpversions.module';
import { WasversionsModule } from './manage/wasversions/wasversions.module';
import { ConfigDriftModule } from './config-drift/config-drift.module';
import { ApplicationsModule } from './manage/applications/applications.module';
import { ReportsModule } from './reports/reports.module';
import { ServersModule } from './patch/servers/servers.module';

@NgModule({
  imports: [
    AdvSearchModule,
    TopologyModule,
    SharedModule,
    DashboardsModule,
    LibertyModule,
    LinuxModule,
    WasNdModule,
    WlpversionsModule,
    ApplicationsModule,
    WasversionsModule,
    ConfigDriftModule,
    ReportsModule,
    ServersModule
  ],
  declarations: []
})
export class UditAppsModule { }

