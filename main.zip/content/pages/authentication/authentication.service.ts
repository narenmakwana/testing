import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { UditUtils } from '../../../../core/uditUtils';
import { TokenService } from './token.service';
import { Constants } from './../../../shared/config/constants';
import { JwtHelper } from 'angular2-jwt';


@Injectable()
export class AuthenticationService  {

    jwtHelper: JwtHelper = new JwtHelper();
    public isLoggedIn: boolean = false;

    constructor(private http: HttpClient, private tokenService: TokenService, private router: Router)
    {

    }

    public getToken(): string {
        return this.tokenService.getAuthToken();
    }

    authenticateUser(_username: string, _password: string): Promise<any>
    {
        return new Promise((resolve, reject) => {

            const userData = {
                username    : _username,
                password    : _password
            };
            this.http.post(Constants.getLoginUrl(), userData)
                .subscribe(response => {
                    this.isLoggedIn = true;
                    resolve(response);
                }, reject);
        });
    }

    public getUser(_username: string) : Promise<any> {
        return new Promise((resolve, reject) => {

            const userData = {
                username    : _username
            };
            this.http.post(Constants.getValidateUrl(), userData)
                .subscribe(response => {
                    resolve(response);
                }, reject);
        });
    }
 
    isAdmin(): boolean {
        var token = this.tokenService.getAuthToken();
        if (token) {
            var userDetails = this.jwtHelper.decodeToken(token);
            if (this.jwtHelper.isTokenExpired(token)) {
                // Token expired. Logout the user.
                this.logoutUser();
            }
            else if (userDetails.userRole === "admin") {
                return true;
            }
            else {
                return false;
            }

        }
    }


    public logoutUser() {
        this.isLoggedIn = false;
        this.tokenService.setAuthToken("");
        this.router.navigate(['pages/auth/login']);   
    }

}