import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UditConfigService } from '../../../../../core/services/config.service';
import { uditAnimations } from '../../../../../core/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { TokenService } from '../token.service';
import {DialogService} from '.././../../../shared/services/dialog.service';
import { UditSplashScreenService } from '../../../../../core/services/splash-screen.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations : uditAnimations
})
export class LoginComponent implements OnInit 
{

  settings: any;
  loginForm: FormGroup;
  loginFormErrors: any;

  constructor(
      private uditConfig: UditConfigService,
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private authService: AuthenticationService,
      private tokenService: TokenService,
      private dialogService: DialogService,
      private uditSpashScreenService: UditSplashScreenService
  )
  {
      this.uditConfig.onSettingsChanged.subscribe(
          (newSettings) => {
              this.settings = newSettings;
          }
      );
      this.uditConfig.setSettings({
          layout: {
              navigation: 'none',
              toolbar   : 'none',
              footer    : 'none'
          }
      });

      this.loginFormErrors = {
          ntid   : {},
          password: {}
      };
  }

  ngOnInit()
  {
      this.loginForm = this.formBuilder.group({
          ntid   : ['', [Validators.required]],
          password: ['', Validators.required]
      });

      this.loginForm.valueChanges.subscribe(() => {
          this.onLoginFormValuesChanged();
      });
  }

  onLoginFormValuesChanged()
  {
      for ( const field in this.loginFormErrors )
      {
          if ( !this.loginFormErrors.hasOwnProperty(field) )
          {
              continue;
          }

          // Clear previous errors
          this.loginFormErrors[field] = {};

          // Get the control
          const control = this.loginForm.get(field);

          if ( control && control.dirty && !control.valid )
          {
              this.loginFormErrors[field] = control.errors;
          }
      }
  }

  login() {
    // Route to home page.
    this.uditSpashScreenService.show();
    const ntid = this.loginForm.controls.ntid.value;
    const password = this.loginForm.controls.password.value;
    this.authService.authenticateUser(ntid, password)
    .then((data) => {
      this.tokenService.setAuthToken(data.token);
      this.tokenService.setUserId(ntid);
      this.authService.getUser(ntid)
        .then((userInfo) => {
            if(userInfo.item.user)
            {   // Save the complete userObject in memory and in token service
                this.uditConfig.setUserInfo(userInfo.item.user);
            }
        }) 
      this.router.navigate(['apps/dashboards/home']);
    })
    .catch((error) => {
      this.handleError(error);
    });
      
  }

  handleError(error) {
    this.uditSpashScreenService.hide();
    this.dialogService
      .ok('Login Error: ', "Invalid Username or Password! ")
  }
 
}
