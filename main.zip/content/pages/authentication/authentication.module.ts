import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../../core/modules/shared.module';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthenticationService } from './authentication.service';
import { TokenService } from './token.service';

const routes: Routes = [
    {
        path     : 'auth/login',
        component: LoginComponent
    },
    {
        path     : 'auth/logout',
        component: LogoutComponent
    },
];


@NgModule({
  declarations: [
    LoginComponent, 
    LogoutComponent, 
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  providers : [
    AuthenticationService, TokenService
  ]
})
export class AuthenticationModule { }
