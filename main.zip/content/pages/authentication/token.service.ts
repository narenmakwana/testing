import {Injectable} from '@angular/core';

@Injectable()
export class TokenService {

  private _tokenkey : string;
  private _userId : string;

  constructor() {
     this._tokenkey = 'allstate-token';
  }

  public setAuthToken(token : string) {
    if(!token){
		   sessionStorage.removeItem(this._tokenkey);
	  }
	  sessionStorage.setItem(this._tokenkey, token);
  }

  public getAuthToken() : string{
    return sessionStorage.getItem(this._tokenkey);        
  }
  
  public setUserId(userid : string) {
    if(!userid){
		   sessionStorage.removeItem(this._userId);
	  }
	  sessionStorage.setItem(this._userId, userid);
  }

  public getUserId() : string {
    return sessionStorage.getItem(this._userId);        
  }

}
