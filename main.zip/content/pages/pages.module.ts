import { NgModule } from '@angular/core';
import { SharedModule } from '../../../core/modules/shared.module';

import { AuthenticationModule } from './authentication/authentication.module';

@NgModule({
  imports: [
    SharedModule,
    AuthenticationModule
  ],
  declarations: []
})
export class UditPagesModule { }
