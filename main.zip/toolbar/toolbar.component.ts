import { Component } from '@angular/core';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { UditConfigService } from '../../core/services/config.service';
import { TranslateService } from '@ngx-translate/core';
import { AfterViewInit, OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { TokenService } from '../content/pages/authentication/token.service';
import { AuthenticationService } from '../content/pages/authentication/authentication.service';


@Component({
    selector   : 'udit-toolbar',
    templateUrl: './toolbar.component.html',
    styleUrls  : ['./toolbar.component.scss']
})

export class UditToolbarComponent implements AfterViewInit, OnInit
{
    userStatusOptions: any[];
    languages: any;
    selectedLanguage: any;
    showLoadingBar: boolean;
    horizontalNav: boolean;
    username: string = "";

    constructor(
        private router: Router,
        private uditConfig: UditConfigService,
        private translate: TranslateService,
        private tokenService: TokenService,
        private authService: AuthenticationService
    )
    {
        this.userStatusOptions = [
            {
                'title': 'Online',
                'icon' : 'icon-checkbox-marked-circle',
                'color': '#4CAF50'
            },
            {
                'title': 'Away',
                'icon' : 'icon-clock',
                'color': '#FFC107'
            },
            {
                'title': 'Do not Disturb',
                'icon' : 'icon-minus-circle',
                'color': '#F44336'
            },
            {
                'title': 'Invisible',
                'icon' : 'icon-checkbox-blank-circle-outline',
                'color': '#BDBDBD'
            },
            {
                'title': 'Offline',
                'icon' : 'icon-checkbox-blank-circle-outline',
                'color': '#616161'
            }
        ];

        this.languages = [
            {
                'id'   : 'en',
                'title': 'English',
                'flag' : 'us'
            },
            {
                'id'   : 'tr',
                'title': 'Turkish',
                'flag' : 'tr'
            }
        ];

        this.selectedLanguage = this.languages[0];

        router.events.subscribe(
            (event) => {
                if ( event instanceof NavigationStart )
                {
                    this.showLoadingBar = true;
                }
                if ( event instanceof NavigationEnd )
                {
                    this.showLoadingBar = false;
                }
            });

        this.uditConfig.onSettingsChanged.subscribe((settings) => {
            this.horizontalNav = settings.layout.navigation === 'top';
        });

        // Subscribe to the changes so we can update the username correctly.
        this.uditConfig.onUserInfoChanged.subscribe((usersettings) => {
            this.username = usersettings.displayName;
        });

    }

    ngAfterViewInit() {
        // The reason we have this logic to retrieve the userinformation
        // again in this function is because after a user is logged in and he refreshes
        // the browser, we use the token kept in the session, but the user information
        // is lost. This results in the display name not being shown. So this logic
        // allows us to retrieve that userinformation again and validate the user
        // which ensures that the token is still valid and allows us to take appropriate
        // action.
        let token = this.tokenService.getAuthToken();
        if(token) 
        {
             // Check if the username is filled in.
             if(this.username.length === 0) {
                 let user = this.tokenService.getUserId();
                 if(user) {
                    this.authService.getUser(user)
                    .then((userInfo) => {
                        if(userInfo.item.user)
                        {   // Save the complete userObject in memory and in token service
                            this.username = userInfo.item.user.displayName;
                        }
                    })
                    .catch((error => {
                        // Somehow the validation failed. So route the user to the login
                        // page to establish a new session.
                        this.authService.logoutUser();
                    })) 
                 }
             }
        }
        else {
            // There is no token in the session. We need to establish a new session.
            this.router.navigate(['pages/auth/login']);               
        }
    }

    ngOnInit() {
        
    }

    search(value)
    {
        // Do your search here...
    
    }

    setLanguage(lang)
    {
        // Set the selected language for toolbar
        this.selectedLanguage = lang;

        // Use the selected language for translations
        this.translate.use(lang.id);
    }

    logout()
    {
        // Route to logout component and let it handle logout.
        this.router.navigate(['pages/auth/logout']);
    }
}