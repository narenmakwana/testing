import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackagesService } from './services/packages.service';
import { OptionsService } from './services/options.service';
import { CellParseService } from './services/cell-parse.service';
import { DataFormatService } from './services/data-format.service';
import { DeployService } from './services/deploy.service';
import { DialogService } from './services/dialog.service';
import { InventoryService } from './services/inventory.service';
import { LibertyCellParseService } from './services/liberty-cell-parse.service';
import { LibertyDataTransformService } from './services/liberty-data-transform.service';
import { LibertyWorkflowService } from './services/liberty-workflow.service';
import { LinuxWorkflowService } from './services/linux-workflow.service';
import { OrgService } from './services/org.service';
import { WasDataTransformService } from './services/was-data-transform.service';
import { WasWorkflowService } from './services/was-workflow.service';
import { WorkflowService } from './services/workflow.service';
import { ReportService } from './services/reports.service';
import { SocketService } from './services/socket-service';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers      : [
    PackagesService, CellParseService, OptionsService, DataFormatService, DeployService,
     DialogService, InventoryService, LibertyCellParseService, LibertyDataTransformService,
     LibertyWorkflowService, LinuxWorkflowService, OrgService, WasDataTransformService,
     WasWorkflowService, WorkflowService, ReportService, SocketService
  ],
})
export class SharedModule { }
