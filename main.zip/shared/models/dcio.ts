import {TciCodes} from './tci-codes';

export class Dcio {
  constructor(
     public id: string,
     public dcio: string,
     public supportingOrg: string,
     public applications: TciCodes[]){
  }
}
