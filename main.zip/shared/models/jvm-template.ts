import {Constants} from '../config/constants';

export class JvmTemplate {
  
    public jvmName: string;

    public isClusterMember: boolean;
    public clusterName: string;

    public portBlock: number;

    public minHeap: string;
    public maxHeap: string;


    constructor( initData? : any){
        if( initData ){
            this.jvmName = initData.jvmName;
            this.isClusterMember = initData.isClusterMember;
            this.portBlock = initData.portBlock;
            this.clusterName = initData.clusterName;
            this.minHeap = initData.minHeap;
            this.maxHeap = initData.maxHeap;
        }
        else {
            this.jvmName = "";
            this.isClusterMember = false;
            this.portBlock = Constants.STARTING_JVM_PORT_BLOCK;
            this.clusterName = "";
            this.minHeap = "1024";
            this.maxHeap = "1024";
        }
    }

    setJvmName( tciCode: string, appName: string, envTypeCode: string, envNumber: string, index: number) : string{
        var _jvmName = tciCode +  "-" + appName + "-" + envTypeCode + envNumber + "-";
        if( index < 10) {
            // append a leading zero
            _jvmName += "0" + index.toString();
        }
        else {
            _jvmName += index.toString();
        }
        this.jvmName = _jvmName;
        return _jvmName;
    }

    validate() : boolean {
        return true;
    }
}
