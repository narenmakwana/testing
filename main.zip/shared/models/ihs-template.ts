import {Constants} from '../config/constants';

export class IhsTemplate {
  
    public ihsName: string = "";
    public hostName: string = "";
    public portBlock: number = Constants.STARTING_IHS_PORT_BLOCK;
    public installAsRoot: boolean = false;

    constructor( initData? : any){
        if (initData) {
            this.ihsName = initData.ihsName;
            this.hostName = initData.hostName;
            this.portBlock = initData.portBlock;
            this.installAsRoot = initData.installAsRoot;
        }
    }

    validate() : boolean {
        return true;
    }
}
