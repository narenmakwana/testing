import {Constants} from '../config/constants';

export class LinuxGroupVmware {
  
    virt_host_env_fldr: string = "";
    targetcluster: string = "";
    cdc: string = "";

    constructor( initData? : any){
        if( initData ) {
            this.virt_host_env_fldr = initData.virt_host_env_fldr;
            this.targetcluster = initData.targetcluster;
            this.cdc = initData.cdc;
        }
    }

    validate() : boolean {
        return true;
    }
}
