import {Constants} from '../config/constants';

export class WasIhsTemplate {
  
    public ihsName: string;
    public hostName: string;
    public portBlock: string;

    constructor( initData? : any){
        if (initData) {
            this.ihsName = initData.ihsName;
            this.hostName = initData.hostName;
            this.portBlock = initData.portBlock;
        }
        else {
            this.ihsName = "";
            this.hostName = "";
            this.portBlock = Constants.STARTING_IHS_PORT_BLOCK + '';            
        }
    }

    validate() : boolean {
        return true;
    }
}
