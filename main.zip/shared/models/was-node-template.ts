import { WasIhsTemplate } from './was-ihs-template';
import { WasJvmTemplate } from './was-jvm-template';
import { WasCell } from './was-cell';
import { Constants } from '../config/constants';

export class WasNodeTemplate {

    public hostName: string;
    public nodeName: string;
    public portBlock: string;

    public hasDmgr: boolean;

    numHttpServers: number = 0;
    public ihsTemplates: WasIhsTemplate[];

    numJvms: number = 0;
    public jvmTemplates: WasJvmTemplate[];

    constructor(initData?: any) {
        if (initData) {
            this.hostName = initData.hostName;
            this.nodeName = initData.nodeName;
            this.portBlock = initData.portBlock;
            this.hasDmgr = initData.hasDmgr;
            this.ihsTemplates = initData.ihsTemplates;
            this.jvmTemplates = initData.jvmTemplates;
        }
        else {
            this.hostName = "";
            this.nodeName = "";
            this.hasDmgr = false;
            this.portBlock = Constants.WAS_DEF_NODE_PORTBLOCK + '';
            this.ihsTemplates = [];
            this.jvmTemplates = [];
        }
    }

    addJvm(wasCell: WasCell, installType: string): WasJvmTemplate {
        var newJvm;

        var newPort;
        var lastPort = Constants.STARTING_JVM_PORT_BLOCK;
        if (this.numJvms > 0) {
            lastPort = Number(this.jvmTemplates[this.numJvms - 1].portBlock);
        }

        newPort = lastPort + 1;

        this.jvmTemplates[this.numJvms] = new WasJvmTemplate();
        newJvm = this.jvmTemplates[this.numJvms];
        // If the installType is WAS BASE, then set server name to just server1
        if (installType === Constants.INSTALL_WAS_BASE)
            this.jvmTemplates[this.numJvms].jvmName = "server1";

        newJvm.portBlock = newPort + ''; // convert to string.

        if (installType !== Constants.INSTALL_WAS_BASE)
            this.setNewJvmName(newJvm, wasCell.getTotalJvms())
        this.numJvms++;
        wasCell.totalJvms += 1;
        return newJvm;
    }

    setNewJvmName(newJvm: WasJvmTemplate, totalJvms: number): void {
        var jvmName = "";
        if (this.nodeName) {
            var name = this.nodeName;
            var tokens = name.split("-");
            var envInfo = "";
            if (tokens.length > 2)
                envInfo = tokens[tokens.length - 2];
            var envType = envInfo.substring(0, 2);
            var envNbr = envInfo.slice(2);  // extract the curr env nbr.
            var reg = new RegExp(/^\d+$/);
            if (reg.test(envNbr)) {  // Check to see if its a number
                jvmName = tokens[0] + "-app-" + tokens[2];
            }
            else {
                jvmName = this.nodeName;
            }
        }

        var idx = "";
        var index = totalJvms + 1;
        if (index < 10)
            idx = '0' + index.toString();
        else
            idx = index.toString();
        jvmName = jvmName + "-" + idx;
        newJvm.jvmName = jvmName;
    }

    addIhs(wasCell: WasCell): WasIhsTemplate {
        var newIhs;

        var newPort;
        var lastPort = Constants.STARTING_IHS_PORT_BLOCK;
        if (this.numHttpServers > 0) {
            lastPort = Number(this.ihsTemplates[this.numHttpServers - 1].portBlock);
        }

        newPort = lastPort + 1;

        this.ihsTemplates[this.numHttpServers] = new WasIhsTemplate();
        newIhs = this.ihsTemplates[this.numHttpServers];

        newIhs.portBlock = newPort + ''; // convert to string.

        this.setNewIhsName(newIhs, wasCell.getTotalIhs())
        this.numHttpServers++;
        wasCell.totalIhs += 1;
        return newIhs;
    }

    setNewIhsName(newIhs: WasIhsTemplate, totalIhs: number): void {
        var ihsName = "";
        if (this.nodeName) {
            // Assume that the node contains enough characters where we want to strip the last three
            var n = this.nodeName.lastIndexOf("-");
            if (n > -1) { // Found atleast one separator. 
                ihsName = this.nodeName.slice(0, n);
                // replace node with app.
                ihsName = ihsName.replace("-node", "-ihs");
            }
        }

        var idx = "";
        var index = totalIhs + 1;
        if (index < 10)
            idx = '0' + index.toString();
        else
            idx = index.toString();
        ihsName = ihsName + "-" + idx;
        newIhs.ihsName = ihsName;
    }

    setJvm(wasCell: WasCell, selectedJvm: number, _jvm: WasJvmTemplate) {
        this.jvmTemplates[selectedJvm] = _jvm;
    }

    setIhs(wasCell: WasCell, selectedIhs: number, _ihs: WasIhsTemplate) {
        this.ihsTemplates[selectedIhs] = _ihs;
    }

    updateJvmEnvNbr(newEnvNbr: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var name = this.jvmTemplates[i].jvmName;
            var tokens = name.split("-");
            var envInfo = "";
            var jvmName = "";
            if (tokens.length > 2)
                envInfo = tokens[tokens.length - 2];
            var envType = envInfo.substring(0, 2);
            var envNbr = envInfo.slice(2);  // extract the curr env nbr.
            var reg = new RegExp(/^\d+$/);
            if (reg.test(envNbr)) {  // Check to see if its a number
                for (var j = 0; j < tokens.length; j++) {
                    if (j === tokens.length - 1) // Last Token
                        jvmName = jvmName + tokens[j];
                    else
                        if (j === tokens.length - 2)
                            jvmName = jvmName + envType + newEnvNbr + "-";
                        else
                            jvmName = jvmName + tokens[j] + "-";
                }
            }
            else {
                jvmName = this.jvmTemplates[i].jvmName;
            }

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateJvmVerCode(oldStandards: boolean, verCode: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var tokens = this.jvmTemplates[i].jvmName.split("-");
            var jvmName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var tmp = tokens[1].slice(0, tokens[1].length - 2)
                var currversion = tokens[1].slice(-2);
                var reg = new RegExp(/^\d+$/);
                if (reg.test(currversion)) {
                    if (tmp === "jvm") { // we only want to change if the jvm name contains jvm
                        if (oldStandards) {
                            let newname = tokens[0] + "-" + tmp + verCode + "-" + tokens[2] + "-" + tokens[3];
                            jvmName = newname;
                        }
                        else {
                            let newname = tokens[0] + "-" + tmp + "-" + tokens[2] + "-" + tokens[3];
                            jvmName = newname;
                        }
                    }
                    else
                        jvmName = this.jvmTemplates[i].jvmName;
                }
                else
                    jvmName = this.jvmTemplates[i].jvmName;
            }
            else  // does not conform..so keep it the same.
                jvmName = this.jvmTemplates[i].jvmName;

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateJvmEnvType(envType: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var name = this.jvmTemplates[i].jvmName;
            var tokens = name.split("-");
            var envInfo = "";
            var jvmName = "";
            if (tokens.length > 2)
                envInfo = tokens[tokens.length - 2];
            var envNbr = envInfo.slice(2);
            var reg = new RegExp(/^\d+$/);
            if (reg.test(envNbr)) {  // Check to see if its a number
                for (var j = 0; j < tokens.length; j++) {
                    if (j === tokens.length - 1) // Last Token
                        jvmName = jvmName + tokens[j];
                    else
                        if (j === tokens.length - 2)
                            jvmName = jvmName + envType + envNbr + "-";
                        else
                            jvmName = jvmName + tokens[j] + "-";
                }
            }
            else {
                jvmName = this.jvmTemplates[i].jvmName;
            }

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateJvmTciCode(tciCode: string): void {
        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var name = this.jvmTemplates[i].jvmName;
            var jvmName = "";
            var res = name.indexOf("-");
            var tci = name.substring(0, res);
            var last = name.slice(res);
            if (tci) {  // Check to see if its valid
                jvmName = tciCode + last;
            }
            else {
                jvmName = this.jvmTemplates[i].jvmName;
            }

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    findDuplicateJvmPorts(): any {
        var ports = [];
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            ports.push(Number(this.jvmTemplates[i].portBlock));
        }
        var sortedNames = ports.slice().sort();
        var results = [];

        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }
        return results;
    }

    findDuplicateIhsPorts(): any {
        var ports = [];
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            ports.push(Number(this.ihsTemplates[i].portBlock));
        }
        var sortedNames = ports.slice().sort();
        var results = [];

        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }
        return results;
    }

    updateClusterEnvType(newEnvType: string): void {
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var clusName = "";
            // First Check to see if the names conform to our standards.
            var idx = this.jvmTemplates[i].clusterName.lastIndexOf("-");
            var name = this.jvmTemplates[i].clusterName.substr(0, idx);
            var tokens = this.jvmTemplates[i].clusterName.slice(idx + 1);
            var envType = "";
            var envNbr = "";
            if (tokens.length === 4) {  // assume the last token is correct format.
                envType = tokens.substr(0, 2);
                envNbr = tokens.substr(2, 2);
                clusName = name + "-" + newEnvType + envNbr;
            }
            else
                clusName = this.jvmTemplates[i].clusterName;

            this.jvmTemplates[i].clusterName = clusName;
        }
    }

    updateClusterTciCode(tciCode: string): void {
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var clusName = "";
            var name = this.jvmTemplates[i].clusterName;
            var res = name.indexOf("-");
            var tci = name.substring(0, res);
            var last = name.slice(res);
            if (tci) {  // assume the last token is correct format.
                clusName = tciCode + last;
            }
            else
                clusName = this.jvmTemplates[i].clusterName;

            this.jvmTemplates[i].clusterName = clusName;
        }
    }

    updateClusterEnvNbr(envNbr: string): void {
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var clusName = "";
            // First Check to see if the names conform to our standards.
            var idx = this.jvmTemplates[i].clusterName.lastIndexOf("-");
            var name = this.jvmTemplates[i].clusterName.substr(0, idx);
            var tokens = this.jvmTemplates[i].clusterName.slice(idx + 1);
            var envType = "";
            var env = "";
            if (tokens.length === 4) {
                envType = tokens.substr(0, 2);
                env = tokens.substr(2, 2);
            }
            var reg = new RegExp(/^\d+$/);
            if (reg.test(env)) {  // check to see if its a number.
                clusName = name + "-" + envType + envNbr;
            }
            else
                clusName = this.jvmTemplates[i].clusterName;

            this.jvmTemplates[i].clusterName = clusName;
        }
    }

    updateIhsEnvNbr(envNbr: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var currnbr = tokens[2].slice(-2);
                var reg = new RegExp(/^\d+$/);
                if (reg.test(currnbr)) {
                    var token3 = tokens[2].substr(0, 2) + envNbr;
                    ihsName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
                }
                else
                    ihsName = this.ihsTemplates[i].ihsName;
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    updateIhsVerCode(oldStandards: boolean, verCode: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                if (tokens[1].length > 3) {
                    // contains something more than just "ihs"
                    var tmp = tokens[1].slice(0, tokens[1].length - 2)
                    var currversion = tokens[1].slice(-2);
                    var reg = new RegExp(/^\d+$/);
                    if (reg.test(currversion)) {
                        if (tmp === "ihs") {
                            // We only want to change if it starts with ihs
                            if (oldStandards) {  // Don't update for 85 and before.
                                let newname = tokens[0] + "-" + tmp + verCode + "-" + tokens[2] + "-" + tokens[3];
                                ihsName = newname;
                            }
                            else {
                                let newname = tokens[0] + "-" + tmp + "-" + tokens[2] + "-" + tokens[3];
                                ihsName = newname;
                            }
                        }
                        else
                            ihsName = this.ihsTemplates[i].ihsName;
                    }
                    else
                        ihsName = this.ihsTemplates[i].ihsName;
                }
                else {
                    // Probably just contains ihs...
                    if (oldStandards) {  // Don't update for 85 and before.
                        let newname = tokens[0] + "-ihs" + verCode + "-" + tokens[2] + "-" + tokens[3];
                        ihsName = newname;
                    }
                    else
                        ihsName = this.ihsTemplates[i].ihsName;
                }
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    updateIhsEnvType(envType: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token3 = envType + tokens[2].substr(2, 2);
                ihsName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    updateIhsTciCode(tciCode: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var name = this.ihsTemplates[i].ihsName;
            var ihsName = "";
            var res = name.indexOf("-");
            var tci = name.substring(0, res);
            var last = name.slice(res);
            if (tci) {  // Check to see if its valid
                ihsName = tciCode + last;
            }
            else {
                ihsName = this.ihsTemplates[i].ihsName;
            }

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    getJvm(selectedJvm: number): WasJvmTemplate {
        // Make sure that we can access the node.
        if (selectedJvm < this.numJvms)
            return this.jvmTemplates[selectedJvm];
    }

    getIhs(selectedIhs: number): WasIhsTemplate {
        // Make sure that we can access the node.
        if (selectedIhs < this.numHttpServers)
            return this.ihsTemplates[selectedIhs];
    }

    get totalJvms(): number {
        return this.numJvms;
    }

    get totalIhs(): number {
        return this.numHttpServers;
    }

    removeJvm(wasCell: WasCell, selectedJvm: number): void {
        if (selectedJvm < this.numJvms) {
            this.jvmTemplates.splice(selectedJvm, 1);
            this.numJvms--;
            wasCell.totalJvms--;
        }
    }

    removeIhs(wasCell: WasCell, selectedIhs: number): void {
        if (selectedIhs < this.numHttpServers) {
            this.ihsTemplates.splice(selectedIhs, 1);
            this.numHttpServers--;
            wasCell.totalIhs--;
        }
    }

    setNodePort(index: number) {
        this.portBlock = index.toString();
    }

    getNodePort(): number {
        return parseInt(this.portBlock);
    }

    validate(): boolean {
        if (this.hostName.length !== Constants.MAX_HOSTNAME_LEN)
            return false;
        return true;
    }
}
