import {InstallManagerNode} from './install-manager-node';

export class InstallManager {

  public installNodes : InstallManagerNode[];

  constructor() {}

}