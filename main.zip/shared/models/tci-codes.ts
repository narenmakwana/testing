export class TciCodes {
  constructor(
     public tciCode: string,
     public description: string) {
  }
}