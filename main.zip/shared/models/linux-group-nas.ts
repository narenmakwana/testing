import {Constants} from '../config/constants';

export class LinuxGroupNas {
  
    perms: string = "ROOT";
    mode: string = "cmode";
    force: boolean = false;
    clean: boolean = false;
    filer_name: string = "";
    qt_name: string = "";
    vol_name: string = "";
    mountpoint: string = "";
    mount_type: string = "";
    nas_mount: string = "yes";

    constructor( initData? : any){
        if( initData ) {
            this.perms = initData.perms;
            this.mode = initData.mode;
            this.force = initData.force;
            this.clean = initData.clean;
            this.filer_name = initData.filer_name;
            this.qt_name = initData.qt_name;
            this.vol_name = initData.vol_name;
            this.mountpoint = initData.mountpoint;
            this.mount_type = initData.mount_type;
            this.nas_mount = initData.nas_mount;
        }
    }

    validate() : boolean {
        return true;
    }
}
