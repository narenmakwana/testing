export class ResponseResult {
  items: any[];
  total: number;
  offset: number;
  count: number;

  constructor(){
     this.items = [];
     this.total = 0;
     this.offset = 0;
     this.count = 0;
  }
}