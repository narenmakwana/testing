import {Constants} from '../config/constants';

export class LinuxGroupManagement {
  
    application_function: string = "";
    mgmt_level: string = "24x7 Enterprise";
    oper_hours: string = "24x7";
    usage_type: string = "";
    maint_day: string = "Sunday";
    maint_week: string = "2";
    maint_time: string = "22:00";
    emerg_maint_time: string = "22:00";
    ecc_restore: string = "no";
    exceptions: string = "";

    constructor( initData? : any){
        if( initData ) {
            this.application_function = initData.application_function;
            this.mgmt_level = initData.mgmt_level;
            this.oper_hours = initData.oper_hours;
            this.usage_type = initData.usage_type;
            this.maint_day = initData.maint_day;
            this.maint_week = initData.maint_week;
            this.maint_time = initData.maint_time;
            this.emerg_maint_time = initData.emerg_maint_time;
            this.ecc_restore = initData.ecc_restore;
            this.exceptions = initData.exceptions;
        }
    }

    validate() : boolean {
        return true;
    }
}
