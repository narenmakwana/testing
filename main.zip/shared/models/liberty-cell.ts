import {LibertyNodeTemplate} from './liberty-node-template';
import {JvmTemplate} from './jvm-template';
import {IhsTemplate} from './ihs-template';
import {Constants} from '../config/constants';

export class LibertyCell {
  
     _id: string = "";
    appName: string = "";
    tciCode: string = "";
    envNumber: string = Constants.STARTING_ENV_NUMBER;  
    cellname: string = "";

    envTypes: string[] = Constants.ENV_TYPES;
    selectedEnvType: string = Constants.DEF_ENV_TYPE;
    envTypeCode: string;

    ldapTypes: string[] = Constants.LDAP_TYPES; 
    selectedLdapType: string = Constants.DEF_LDAP_TYPE;

    productTypes: string[] = Constants.PRODUCT_TYPES; 
    selectedProductType: string = Constants.PRODUCT_TYPES[0];

    wlpVersions: string[] = Constants.WLP_VERSIONS;
    javaVersions: string [] = Constants.JAVA_VERSIONS;
    WLP_JAVA : any;
    ihsVersions: string[] = Constants.IHS_VERSIONS.reverse();
   
    selectedWlpVersion: string = "";
    selectedJavaVersion: string = Constants.DEF_WLP_JAVA_VERSION;
    javaVersion: string = Constants.JAVA_VERSIONS[0];
    wlpVersionCode: string;
    ihsVersionCode: string;
    selectedIhsVersion: string = "";

    ldapId : string = Constants.DEF_LDAP_ID;
    ldapBindId : string = Constants.DEF_BIND_ID;
    runasId: string = Constants.DEF_RUNAS_ID; 
    globalSecurityGroup: string = "";
    isCollectiveController: boolean;
    isCollectiveReplicaSet : boolean;
    
    numNodes: number = 0;
    totalJvms: number = 0;
    totalIhs: number = 0;

    nodeTemplates: LibertyNodeTemplate[] = [];
    status: any[] = [];

    constructor( initData? : any ){
        // If we are coming to edit a cell, then initialize the cell data from the database info.
        if( initData ) {
            this._id = initData._id;
            this.numNodes = initData.numNodes;
            this.cellname = initData.cellname;
            this.envNumber = initData.envNumber;
            this.tciCode = initData.tciCode;
            this.appName = initData.appName;
            this.ldapId = initData.ldapId;
            this.ldapBindId = initData.ldapBindId;
            this.runasId = initData.runasId;
            this.selectedEnvType = initData.selectedEnvType;
            this.selectedLdapType = initData.selectedLdapType;
            this.wlpVersions = initData.wlpVersions;
            this.selectedWlpVersion = initData.selectedWlpVersion;
            this.selectedJavaVersion = initData.selectedJavaVersion;
            this.selectedIhsVersion = initData.selectedIhsVersion;
            this.selectedProductType = initData.selectedProductType;
            this.envTypeCode = initData.envTypeCode;
            this.globalSecurityGroup = initData.globalSecurityGroup;
            this.isCollectiveController = initData.isCollectiveController;
            this.isCollectiveReplicaSet = initData.isCollectiveReplicaSet;
            this.status = initData.status || [];
            if( initData.numNodes > 0) {
                for (var i = 0; i < initData.numNodes; i++) {
                     this.nodeTemplates[i] = new LibertyNodeTemplate(initData.nodeTemplates[i]);
                     // For this node, initialize the jvms and http servers.
                     if(initData.nodeTemplates[i].numJvms) {
                         this.nodeTemplates[i].numJvms = initData.nodeTemplates[i].numJvms;
                         for (var j = 0; j < initData.nodeTemplates[i].numJvms; j++){
                             this.nodeTemplates[i].jvmTemplates[j] = new JvmTemplate(initData.nodeTemplates[i].jvmTemplates[j]);
                         }
                         this.totalJvms += this.nodeTemplates[i].numJvms;
                     }
                     if(initData.nodeTemplates[i].numHttpServers) {
                         this.nodeTemplates[i].numHttpServers = initData.nodeTemplates[i].numHttpServers;
                         for (var j = 0; j < initData.nodeTemplates[i].numHttpServers; j++){
                             this.nodeTemplates[i].ihsTemplates[j] = new IhsTemplate(initData.nodeTemplates[i].ihsTemplates[j]);
                         }
                         this.totalIhs += this.nodeTemplates[i].numHttpServers;
                     }
                }
            }
        }
        else {
            this.addNode(); // Start with one node.
            this.envTypeCode =  this.selectedEnvType.slice(0,2); // strip the first two characters for default
        }    
    } 

    setWlpVersions ( versions: any) {
        this.WLP_JAVA = versions;
        this.wlpVersions = versions.map(function(a) {return a.wlp;});
        // If version is not set, then set it to default.
        if (!this.selectedWlpVersion)
            this.selectedWlpVersion = this.wlpVersions[0];
        this.wlpVersionChanged(this.selectedWlpVersion);
    }

    setIhsVersions ( versions: any) {
        this.ihsVersions = versions;
        // If version is not set, then set it to default.
        if (!this.selectedIhsVersion)
            this.selectedIhsVersion = this.ihsVersions[0];
        this.ihsVersionChanged(this.selectedIhsVersion);
    }

    addNode() : void {
        this.numNodes++;

        // Lets say that we had 4 nodes and user removed a node. In this case we want to keep the data in the array and not
        // lose it. So check if the total nodes is less than the nodeTemplates Length.
        if (this.numNodes < this.nodeTemplates.length)
            this.nodeTemplates = this.nodeTemplates.slice(0, this.numNodes);
        else {
          for (var i = this.nodeTemplates.length; i < this.numNodes; i++) {
              if (this.nodeTemplates.length > 0){
                  this.nodeTemplates[i] = new LibertyNodeTemplate;
                  this.nodeTemplates[i].collAdminUser = this.nodeTemplates[i-1].collAdminUser;
                  this.nodeTemplates[i].collCellName = this.nodeTemplates[i-1].collCellName;
                  this.nodeTemplates[i].collControllerName = this.nodeTemplates[i-1].collControllerName;
                  this.nodeTemplates[i].collHostName = this.nodeTemplates[i-1].collHostName;
                  this.nodeTemplates[i].collJavaPath = this.nodeTemplates[i-1].collJavaPath;
                  this.nodeTemplates[i].collPortNumber = this.nodeTemplates[i-1].collPortNumber;
                  this.nodeTemplates[i].isCollectiveMember = this.nodeTemplates[i-1].isCollectiveMember;
              }
              else {
                   this.nodeTemplates[i] = new LibertyNodeTemplate();

              }   
          }
        }    
        this.updateNodeNames();
    }

    updateNodeNames() : void {
        for(var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }

    setNode( selectedNode: number, _node: LibertyNodeTemplate) {
        this.nodeTemplates[selectedNode] = _node;
    }

    getNode( selectedNode: number ) : LibertyNodeTemplate {
        // Make sure that we can access the node.
        if( selectedNode < this.numNodes )
            return this.nodeTemplates[selectedNode];
    }

    get totalNodes() : number {
        return this.numNodes;
    }

    removeNode( selectedNode: number ) : void {
        if (selectedNode < this.numNodes) {
            this.nodeTemplates[selectedNode].removeAllJvms(this);
            this.nodeTemplates[selectedNode].removeAllIhs(this);
            this.nodeTemplates.splice(selectedNode, 1);
            this.numNodes--;
        }
    }

    envNbrChanged(_envNbr: string) {
        this.envNumber = _envNbr;
        this.updateNames();
        this.updateJvmAndIhsEnvNbr(this.envNumber);
    }

    envTypeChanged(_envType: string) {
        // Extract the code
        this.envTypeCode = _envType.slice(0, 2);
        // If the Env Type Changed to Prod, then switch the runasID and Bind ID Defaults.
        if( this.envTypeCode.startsWith(Constants.PROD_ENV_CODE) || this.envTypeCode.startsWith(Constants.DR_ENV_CODE)){
            this.selectedLdapType = Constants.PROD_LDAP_TYPE;
            this.runasId = Constants.PROD_RUNAS_ID;
            this.ldapId = Constants.DEF_LDAP_ID;
            this.ldapBindId = Constants.PROD_BIND_ID;
        }
        else {
            this.runasId = Constants.DEF_RUNAS_ID;
          //this.ldapBindId = Constants.DEF_BIND_ID;            
            if( this.envTypeCode.startsWith(Constants.ETEST_ENV_CODE) ) 
                this.selectedLdapType = Constants.ETEST_LDAP_TYPE;
            else
                this.selectedLdapType = Constants.DEF_LDAP_TYPE;
        }
        this.updateNames();
        this.updateJvmAndIhsEnvType(this.envTypeCode);
    }

    cellTypeChanged(_cellType: boolean) {
        // Extract the code
       this.isCollectiveController = _cellType;
       for(var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].isCollectiveController = _cellType;
            if (_cellType){
                this.nodeTemplates[i].isCollectiveMember = false;
            }
        }

       if( _cellType ){
          // Set the Product Type to WAS ND.
          this.selectedProductType = Constants.WLP_LIBERTY_ND;
       }
       else {
          this.selectedProductType = Constants.WLP_LIBERTY_CORE;        
       }
       this.updateNames();
    }


    wlpVersionChanged(_wlpVersion: string) {
        // Extract the code
        this.wlpVersionCode = _wlpVersion.replace('.', '').slice(0, 2);
        this.selectedJavaVersion = this.WLP_JAVA.filter(function (obj ) {
            return obj.wlp == _wlpVersion;
        })[0].java;
    }

     javaVersionChanged(_javaVersion : string) {
        /*
       if(_javaVersion == '9.0'){
           
       }
       else{

       }
       */      
    }

    ihsVersionChanged(_ihsVersion: string) {
        this.selectedIhsVersion = _ihsVersion;
    }
    
    ldapTypeChanged(_ldapType: string) {
    }

    tciCodeChanged(_tciCode: string) {
        this.updateNames();
    }

    updateJvmAndIhsEnvNbr(envNbr) : void {
        if( this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmEnvNbr(envNbr);
                this.nodeTemplates[i].updateIhsEnvNbr(envNbr);
            }
        }
        for(var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }
    
    updateJvmAndIhsEnvType(envType) : void {
        if( this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmEnvType(envType);
                this.nodeTemplates[i].updateIhsEnvType(envType);
            }
        }
        for(var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }

    updateNames() : void {
        this.buildCellName();
        this.updateNodeNames();        
    }
    
    getTotalJvms() : number {
        return this.totalJvms;
    }

    getTotalIhs() : number {
        return this.totalIhs;
    }

    getLibertyPrefix(): string {
        var prefix = Constants.WLC_CELLNAME_PREFIX; // default.
        if(this.selectedProductType === Constants.WLP_LIBERTY_BASE)
            prefix = Constants.WLB_CELLNAME_PREFIX;
        else
        if(this.selectedProductType === Constants.WLP_LIBERTY_ND && this.isCollectiveController)
            prefix = Constants.CONTROLLER_PREFIX;
        else
        if (this.selectedProductType === Constants.WLP_LIBERTY_ND)
            prefix = Constants.WLN_CELLNAME_PREFIX;
        return prefix;        
    }

    buildCellName() : void {
       // Build a cell name when either tcicode, env number or version changes.
        if( !this.isCollectiveController )
            this.cellname = this.tciCode + this.getLibertyPrefix() + "-" + this.envTypeCode + this.envNumber;
        else
            this.cellname = this.tciCode + Constants.WLN_CELLNAME_PREFIX + "-" + this.envTypeCode + this.envNumber;
    }

    buildNodeName(_nodeName : string, index: number) : string {
        // Build a cell name when either tcicode, env number or version changes.
        var nodeName = "";
        var idx = "";
        index = index+1;
        if( index < 10)
           idx = '0' + index.toString();
        else
           idx = index.toString();
           
        nodeName = this.tciCode + this.getLibertyPrefix() + "-" + this.envTypeCode + this.envNumber + "-" + idx;
        return nodeName;
    }

    isValidTCI() : boolean {
        if( this.tciCode && this.tciCode.length >= Constants.MIN_TCICODE_LEN)
           return true;
        else
           return false;
    }

    validate() : boolean {
        var isValid = false;
        this.nodeTemplates.forEach(function (node){
            isValid = node.validate();
        });
        return isValid;
    }

}
