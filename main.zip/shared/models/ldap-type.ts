export class LdapType {

  public ldapType: string;
  public desc: string;
  public isProd: boolean;
  public isDev: boolean;
  public isEtest: boolean;

  constructor(
     _ldapType: string,
     _desc: string, 
     _isProd: boolean,
     _isDev: boolean,
     _isEtest: boolean) {
         this.ldapType = _ldapType;
         this.desc = _desc;
         this.isProd = _isProd;
         this.isDev = _isDev;
         this.isEtest = _isEtest;
     }  // constructor
}