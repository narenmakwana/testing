// Socket.io events
export enum SocketEvent {
    CONNECT = 'connect',
    DISCONNECT = 'disconnect',
    JOIN = 'join',
    ERROR = 'error',
    CONNECT_ERR = 'connect_error',
    WLP_STATUS = 'wlpStatus',
    WLP_STOP = 'wlpStop',
    WLP_START = 'wlpStart',
    WAS_STATUS = 'wasStatus',
    WAS_START = 'wasStart',
    WAS_STOP = 'wasStop',
    IHS_STATUS = 'ihsStatus',
    IHS_START = 'ihsStart',
    IHS_STOP = 'ihsStop',
    DMGR_START = 'dmgrStart',
    DMGR_STOP = 'dmgrStop',
    NODE_AGENT_START = 'nodeStart',
    NODE_AGENT_STOP = 'nodeStop',
    TAIL = 'tail',
    TERMINATE = "terminate"
}