import {Constants} from '../config/constants';

export class LinuxGroupCloud {
  
    cloud_type: string  = "AWS";
    region: string = "";
    instance_type: string = "";
    security_group: string = "";

    constructor( initData? : any){
        if( initData ) {
            this.cloud_type = initData.cloud_type;
            this.region = initData.region;
            this.instance_type = initData.instance_type;
            this.security_group = initData.security_group;
        }
    }

    validate() : boolean {
        return true;
    }
}
