import {Constants} from '../config/constants';

export class LinuxGroupNetwork {
  
    net_design_loc: string = "MPN";
    domain: string = "allstate.com";

    constructor( initData? : any){
        if( initData ) {
            this.net_design_loc = initData.net_design_loc;
            this.domain = initData.domain;
        }
    }

    validate() : boolean {
        return true;
    }
}
