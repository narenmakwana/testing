import { IhsTemplate } from './ihs-template';
import { JvmTemplate } from './jvm-template';
import { LibertyCell } from './liberty-cell';
import { Constants } from '../config/constants';

export class LibertyNodeTemplate {

    public hostName: string;
    public nodeName: string;
    public portBlock: string;

    public isCollectiveMember: boolean;
    public isCollectiveController: boolean;
    public collControllerName: string;
    public collHostName: string;
    public collCellName: string;
    public collPortNumber: string;
    public collJavaPath: string;
    public collAdminUser: string;

    numHttpServers: number = 0;
    public ihsTemplates: IhsTemplate[];

    numJvms: number = 0;
    public jvmTemplates: JvmTemplate[];

    constructor(initData?: any) {
        if (initData) {
            this.hostName = initData.hostName;
            this.nodeName = initData.nodeName;
            this.portBlock = initData.portBlock;
            this.isCollectiveMember = initData.isCollectiveMember;
            this.isCollectiveController = initData.isCollectiveController;
            this.collControllerName = initData.collControllerName;
            this.collHostName = initData.collHostName;
            this.collPortNumber = initData.collPortNumber;
            this.collCellName = initData.collCellName;
            this.collJavaPath = initData.collJavaPath;
            this.collAdminUser = initData.collAdminUser;
            this.ihsTemplates = initData.ihsTemplates;
            this.jvmTemplates = initData.jvmTemplates;
        }
        else {
            this.hostName = "";
            this.nodeName = "";
            this.isCollectiveMember = false;
            this.isCollectiveController = false;
            this.portBlock = Constants.WAS_DEF_NODE_PORTBLOCK;
            this.ihsTemplates = [];
            this.jvmTemplates = [];
            this.collControllerName = "";
            this.collHostName = "";
            this.collPortNumber = "";
            this.collCellName = "";
            this.collAdminUser = "";
            this.collJavaPath = "";
        }
    }

    addJvm(libertyCell: LibertyCell): JvmTemplate {
        var newJvm;
        var newPort;
        var lastPort = Constants.STARTING_JVM_PORT_BLOCK;
        if (this.numJvms > 0) {
            lastPort = Number(this.jvmTemplates[this.numJvms - 1].portBlock);
        }

        if (libertyCell.isCollectiveController && this.numJvms == 0) {
            this.isCollectiveController = true;
            lastPort = Constants.STARTING_CNTRL_PORT_BLOCK;
        }
        else if (libertyCell.isCollectiveController && this.numJvms > 0) {
            this.isCollectiveController = true;
            lastPort = Number(this.jvmTemplates[this.numJvms - 1].portBlock);
        }

        newPort = lastPort + 1;
        this.jvmTemplates[this.numJvms] = new JvmTemplate();
        newJvm = this.jvmTemplates[this.numJvms];
        newJvm.portBlock = newPort;


        if (libertyCell.nodeTemplates.length > 0 && libertyCell.totalJvms > 0) {
            var appName;
            for (var i = 0; i < libertyCell.nodeTemplates.length; i++) {
                for (var j = 0; j < libertyCell.nodeTemplates[i].jvmTemplates.length; j++) {
                    if (libertyCell.nodeTemplates[i].jvmTemplates.length > 0) {
                        newJvm.minHeap = libertyCell.nodeTemplates[i].jvmTemplates[j].minHeap;
                        newJvm.maxHeap = libertyCell.nodeTemplates[i].jvmTemplates[j].maxHeap;
                        if (libertyCell.nodeTemplates[i].jvmTemplates[j].jvmName != "") {
                            var arrayOfStrings = libertyCell.nodeTemplates[i].jvmTemplates[j].jvmName.split('-');
                            appName = arrayOfStrings[1]
                        }
                    }
                }
            }
        }

        this.setNewJvmName(newJvm, libertyCell.getTotalJvms(), appName);
        this.numJvms++;
        libertyCell.totalJvms += 1;
        return newJvm;
    }

    setNewJvmName(newJvm: JvmTemplate, totalJvms: number, appName: string): void {
        var jvmName = "";
        if (this.nodeName) {
            // Assume that the node contains enough characters where we want to strip the last three
            var n = this.nodeName.lastIndexOf("-");
            if (n > -1) { // Found atleast one separator. 
                jvmName = this.nodeName.slice(0, n);
                // replace node with app.
                if (appName) {
                    jvmName = jvmName.replace(/wl[c,b,n]/, appName);
                }

            }
        }

        var idx = "";
        var index = totalJvms + 1;
        if (index < 10)
            idx = '0' + index.toString();
        else
            idx = index.toString();
        jvmName = jvmName + "-" + idx;
        newJvm.jvmName = jvmName;
    }

    addIhs(libertyCell: LibertyCell): IhsTemplate {
        var newIhs = new IhsTemplate()
        var newPort;
        var lastPort = Constants.STARTING_IHS_PORT_BLOCK;
        var installAsRoot = false;

        if (this.numHttpServers > 0) {
            lastPort = Number(this.ihsTemplates[this.numHttpServers - 1].portBlock);
            installAsRoot = Boolean(this.ihsTemplates[this.numHttpServers - 1].installAsRoot);
        }

        newPort = lastPort + 1;

        this.ihsTemplates[this.numHttpServers] = new IhsTemplate();
        newIhs = this.ihsTemplates[this.numHttpServers];
        newIhs.portBlock = newPort;
        newIhs.installAsRoot = installAsRoot;
        this.setNewIhsName(newIhs, libertyCell.getTotalIhs())
        this.numHttpServers++;
        libertyCell.totalIhs += 1;
        return newIhs;
    }

    setNewIhsName(newIhs: IhsTemplate, totalIhs: number): void {
        var ihsName = "";
        if (this.nodeName) {
            // Assume that the node contains enough characters where we want to strip the last three
            var n = this.nodeName.lastIndexOf("-");
            if (n > -1) { // Found atleast one separator. 
                ihsName = this.nodeName.slice(0, n);
                // replace node with app.
                ihsName = ihsName.replace(/wl[c,b,n]/, "ihs")
            }
        }

        var idx = "";
        var index = totalIhs + 1;
        if (index < 10)
            idx = '0' + index.toString();
        else
            idx = index.toString();
        ihsName = ihsName + "-" + idx;
        newIhs.ihsName = ihsName;
    }

    setJvm(libertyCell: LibertyCell, selectedJvm: number, _jvm: JvmTemplate) {
        this.jvmTemplates[selectedJvm] = _jvm;
    }

    setIhs(libertyCell: LibertyCell, selectedIhs: number, _ihs: IhsTemplate) {
        this.ihsTemplates[selectedIhs] = _ihs;
    }

    updateJvmEnvNbr(envNbr: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var tokens = this.jvmTemplates[i].jvmName.split("-");
            var jvmName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token3 = tokens[2].substr(0, 2) + envNbr;
                jvmName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                jvmName = this.jvmTemplates[i].jvmName;

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateJvmVerCode(verCode: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var tokens = this.jvmTemplates[i].jvmName.split("-");
            var jvmName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token2 = tokens[1].substr(0, tokens[1].length - 2) + verCode;
                jvmName = tokens[0] + "-" + token2 + "-" + tokens[2] + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                jvmName = this.jvmTemplates[i].jvmName;

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateJvmEnvType(envType: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            var tokens = this.jvmTemplates[i].jvmName.split("-");
            var jvmName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token3 = envType + tokens[2].substr(2, 2);
                jvmName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                jvmName = this.jvmTemplates[i].jvmName;

            this.jvmTemplates[i].jvmName = jvmName;
        }
    }

    updateIhsEnvNbr(envNbr: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token3 = tokens[2].substr(0, 2) + envNbr;
                ihsName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    updateIhsVerCode(verCode: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token2 = tokens[1].substr(0, tokens[1].length - 2) + verCode;
                ihsName = tokens[0] + "-" + token2 + "-" + tokens[2] + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    updateIhsEnvType(envType: string): void {

        // get the jvm name and replace the env nbr in the name.
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            var tokens = this.ihsTemplates[i].ihsName.split("-");
            var ihsName = "";
            // First Check to see if the names conform to our standards.
            if (tokens.length === 4) {
                var token3 = envType + tokens[2].substr(2, 2);
                ihsName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
            }
            else  // does not conform..so keep it the same.
                ihsName = this.ihsTemplates[i].ihsName;

            this.ihsTemplates[i].ihsName = ihsName;
        }
    }

    findDuplicateJvmPorts(): any {
        var ports = [];
        for (var i = 0; i < this.jvmTemplates.length; i++) {
            ports.push(this.jvmTemplates[i].portBlock);
        }
        var sortedNames = ports.slice().sort();
        var results = [];

        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }
        return results;
    }

    findDuplicateIhsPorts(): any {
        var ports = [];
        for (var i = 0; i < this.ihsTemplates.length; i++) {
            ports.push(this.ihsTemplates[i].portBlock);
        }
        var sortedNames = ports.slice().sort();
        var results = [];

        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }
        return results;
    }

    getJvm(selectedJvm: number): JvmTemplate {
        // Make sure that we can access the node.
        if (selectedJvm < this.numJvms)
            return this.jvmTemplates[selectedJvm];
    }

    getIhs(selectedIhs: number): IhsTemplate {
        // Make sure that we can access the node.
        if (selectedIhs < this.numHttpServers)
            return this.ihsTemplates[selectedIhs];
    }

    get totalJvms(): number {
        return this.numJvms;
    }

    get totalIhs(): number {
        return this.numHttpServers;
    }

    removeJvm(libertyCell: LibertyCell, selectedJvm: number): void {
        if (selectedJvm < this.numJvms) {
            this.jvmTemplates.splice(selectedJvm, 1);
            this.numJvms--;
            libertyCell.totalJvms--;
        }
    }

    removeAllJvms(libertyCell: LibertyCell): void {
        this.jvmTemplates = [];
        libertyCell.totalJvms = libertyCell.totalJvms - this.numJvms;
        this.numJvms = 0;
    }

    removeAllIhs(libertyCell: LibertyCell): void {
        this.ihsTemplates = [];
        libertyCell.totalIhs = libertyCell.totalIhs - this.numHttpServers;
        this.numHttpServers = 0;
    }

    removeIhs(libertyCell: LibertyCell, selectedIhs: number): void {
        if (selectedIhs < this.numHttpServers) {
            this.ihsTemplates.splice(selectedIhs, 1);
            this.numHttpServers--;
            libertyCell.totalIhs--;
        }
    }

    setNodeName(tciCode: string, envTypeCode: string, versionCode: string, envNumber: string, index: number): string {
        var _nodeName = tciCode + "-node" + versionCode + "-" + envTypeCode + envNumber + "-";
        if (index < 10) {
            // append a leading zero
            _nodeName += "0" + index.toString();
        }
        else {
            _nodeName += index.toString();
        }
        this.nodeName = _nodeName;
        return _nodeName;
    }

    validate(): boolean {
        if (this.hostName.length !== Constants.MAX_HOSTNAME_LEN)
            return false;
        return true;
    }
}
