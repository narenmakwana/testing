import {Constants} from '../config/constants';

export class LinuxGroupLocalDasd {
  
    dasd_spec: string = "std";
    apps_size: string = "";

    constructor( initData? : any){
        if( initData ) {
            this.dasd_spec = initData.dasd_spec;
            this.apps_size = initData.apps_size;
        }
    }

    validate() : boolean {
        return true;
    }
}
