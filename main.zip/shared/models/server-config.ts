import { LinuxGroupTemplate } from './linux-group-template';
import { Constants } from '../config/constants';

export class ServerConfig {

    _id: string;
    project_name: string;
    project_status: string = "final";
    pmt_num: string = "";
    rc_num: string = "";
    dcio: string = "";
    dept: string = "";
    proj_desc: string = "";
    numGroups: number = 0;
    cmdbBusUnits: string[] = [];
    cmdbBusApps: string[] = [];
    softwareProducts: string[] = [];
    business_unit: string = "";
    cmdb_app_name: string = "";
    primary_app_contact: string = "";
    secondary_app_contact: string = "";
    sppt_it_org: string = "";
    application_function: string = "";
    groupTemplates: LinuxGroupTemplate[] = [];

    constructor(initData?: any) {
        if (initData) {
            this._id = initData._id;
            this.numGroups = initData.numGroups;
            this.project_name = initData.project_name;
            this.project_status = initData.project_status;
            this.pmt_num = initData.pmt_num;
            this.rc_num = initData.rc_num;
            this.business_unit = initData.business_unit;
            this.cmdb_app_name = initData.cmdb_app_name;
            this.primary_app_contact = initData.primary_app_contact;
            this.secondary_app_contact = initData.secondary_app_contact;
            this.sppt_it_org = initData.sppt_it_org;
            this.application_function = initData.application_function;
            if (initData.numGroups > 0) {
                for (var i = 0; i < initData.numGroups; i++) {
                    this.groupTemplates[i] = new LinuxGroupTemplate(initData.groupTemplates[i]);
                }
            }
        }
        else {
            this.addGroup(); // Start with one group.
        }
    }

    addGroup(): void {
        this.numGroups++;
        // Lets say that we had 4 nodes and user removed a node. In this case we want to keep the data in the array and not
        // lose it. So check if the total nodes is less than the nodeTemplates Length.
        if (this.numGroups < this.groupTemplates.length)
            this.groupTemplates = this.groupTemplates.slice(0, this.numGroups);
        else {
            for (var i = this.groupTemplates.length; i < this.numGroups; i++) {
                if (i > 0) { // more than one group. Copy data from last group to this new group.
                    var oldgroup = this.groupTemplates[i - 1];
                    this.groupTemplates[i] = new LinuxGroupTemplate(oldgroup);
                }
                else
                    this.groupTemplates[i] = new LinuxGroupTemplate();
                this.groupTemplates[i].group_name = ""; // blank it out to force them to select.
            }
        }
    }

    removeGroup(selectedGroup: number): void {
        if (selectedGroup < this.numGroups) {
            this.groupTemplates.splice(selectedGroup, 1);
            this.numGroups--;
        }
    }

    setGroup(selectedGroup: number, _group: LinuxGroupTemplate) {
        this.groupTemplates[selectedGroup] = _group;
    }

    getGroup(selectedGroup: number): LinuxGroupTemplate {
        // Make sure that we can access the node.
        if (selectedGroup < this.numGroups)
            return this.groupTemplates[selectedGroup];
    }

    get totalGroups(): number {
        return this.numGroups;
    }
}