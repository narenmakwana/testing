export class EnvType {

  public envType: string;
  public desc: string;
  public isProd: boolean;
  public isDev: boolean;
  public isTest: boolean;
  public isDR: boolean;

  constructor(
     _envType: string,
     _desc: string, 
     _isProd: boolean,
     _isDev: boolean,
     _isTest: boolean,
     _isDR: boolean) {
         this.envType = _envType;
         this.desc = _desc;
         this.isProd = _isProd;
         this.isDev = _isDev;
         this.isTest = _isTest;
         this.isDR = _isDR;
     }  // constructor
}