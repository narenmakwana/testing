import {Dcio} from './dcio';

export interface TciCodesResult {
  items: Dcio[];
  total: string;
  offset: string;
  count: string;
}