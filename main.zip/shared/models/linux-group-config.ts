import {Constants} from '../config/constants';

export class LinuxGroupConfig {
  
    cmdb_app_users: string = "All";
    unix_sec: string = "";
    puppet: string = "";
    tuning: string = "";
    install: string = "";

    constructor( initData? : any){
        if( initData ) {
            this.cmdb_app_users = initData.cmdb_app_users;
            this.unix_sec = initData.unix_sec;
            this.puppet = initData.puppet;
            this.tuning = initData.tuning;
            this.install = initData.install;
        }
    }

    validate() : boolean {
        return true;
    }
}
