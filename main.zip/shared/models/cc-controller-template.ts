import {Constants} from '../config/constants';

export class CcControllerTemplate {
  
    public controllerName: string;
    public portBlock: number;
    public minHeap: string;
    public maxHeap: string;


    constructor( initData? : any){
        if( initData ){
            this.controllerName = initData.controllerName;
            this.portBlock = initData.portBlock;  
            this.minHeap = initData.minHeap;
            this.maxHeap = initData.maxHeap;
        }
        else {
            this.controllerName = "";     
            this.portBlock = Constants.STARTING_CNTRL_PORT_BLOCK;
            this.minHeap = "1024";
            this.maxHeap = "1024";
        }
    }

    setJvmName( tciCode: string, appName: string, envTypeCode: string, envNumber: string, index: number) : string{
        var _jvmName = tciCode +  "-" + "cntrlr" + "-" + envTypeCode + envNumber + "-";
        if( index < 10) {
            // append a leading zero
            _jvmName += "0" + index.toString();
        }
        else {
            _jvmName += index.toString();
        }
        this.controllerName = _jvmName;
        return _jvmName;
    }

    validate() : boolean {
        return true;
    }
}
