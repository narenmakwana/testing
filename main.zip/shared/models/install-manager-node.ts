export class InstallManagerNode {

  dataLocation : string;
  installLocation: string;
  repositoryLocation: string;
  templateVer: string;
  task: string;
  hostName: string;

  constructor(
     _dataLocation?: string,
     _installLocation?: string, 
     _repositoryLocation?: string,
     _templateVer?: string,
     _task?: string,
     _hostName?: string){
         this.dataLocation = _dataLocation;
         this.installLocation = _installLocation;
         this.repositoryLocation = _repositoryLocation;
         this.templateVer = _templateVer;
         this.task = _task;
         this.hostName = _hostName;
     }  // constructor
}