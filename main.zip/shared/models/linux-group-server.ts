import {Constants} from '../config/constants';

export class LinuxGroupServer {
  
    profile: string = "base";
    num_servers: number = 1;
    datacenter: string  = "Hudson";
    cpu: number = 4;
    memory: number = 16;
    os: string = "rhel7";
    pri_srvr_func: string = "lxv";
    env_code: string = "A";
    network_code: string = "0";
    type: string = "vmware";
    windows_local_admin : string = "";

    constructor( initData? : any){
        if( initData ) {
            this.profile = initData.profile;
            this.num_servers = initData.num_servers;
            this.datacenter = initData.datacenter;
            this.cpu = initData.cpu;
            this.memory = initData.memory;
            this.os = initData.os;
            this.pri_srvr_func = initData.pri_srvr_func;
            this.env_code = initData.env_code;
            this.network_code = initData.network_code;
            this.type = initData.type;
            this.windows_local_admin = initData.windows_local_admin;
        }
    }

    validate() : boolean {
        return true;
    }
}
