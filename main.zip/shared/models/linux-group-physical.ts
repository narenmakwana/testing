import { Constants } from '../config/constants';

export class LinuxGroupPhysicalTeam {

    team_number: string = "";
    net_type: string = "1";
    pri_interface: string = "";
    sec_interface: string = "";
    switch1: string = "";
    switch1_port: string = "";
    switch2: string = "";
    switch2_port: string = "";
    network: string = "";
    vlan: string = "";
    sec_zone: string = "";
    pri_target_slot: string = "";
    pri_target_port: string = "";
    sec_target_slot: string = "";
    sec_target_port: string = "";

    constructor(initData?: any) {
        if (initData) {
            this.team_number = initData.team_number;
            this.net_type = initData.net_type;
            this.pri_interface = initData.pri_interface;
            this.sec_interface = initData.sec_interface;
            this.switch1 = initData.switch1;
            this.switch1_port = initData.switch1_port;
            this.switch2 = initData.switch2;
            this.switch2_port = initData.switch2_port;
            this.network = initData.network;
            this.vlan = initData.vlan;
            this.sec_zone = initData.sec_zone;
            this.pri_target_slot = initData.pri_target_slot;
            this.sec_target_slot = initData.sec_target_slot;
            this.pri_target_port = initData.pri_target_port;
            this.sec_target_port = initData.sec_target_port;
        }
    }
}

export class LinuxGroupPhysicalSE {

    servername: string = "";
    // Physical Section
    hardware_module: string = "";
    ht: boolean = true;
    san: boolean = false;
    san_nets: number = 0;  // Integer value of number of SAN configs
    networks: number = 0;  // Integer value of total number of networkConfigTeams of the first phys group
    part_number: string = "";
    datacenter: string = "";
    serial: string = "";   // Example H6M2GK2

    vendor: string = "DELL";
    model: string = "R740";
    num_process_cores: string = "";
    memory: string = "";

    num_nic_1gb: number = 0;
    num_nic_10gb: number = 0;
    num_hba: number = 0;


    constructor(initData?: any) {
        if (initData) {
            this.servername = initData.servername;
            this.hardware_module = initData.hardware_module;
            this.part_number = initData.part_number;
            this.san_nets = initData.san_nets;
            this.datacenter = initData.datacenter;
            this.serial = initData.serial;
            this.vendor = initData.vendor;
            this.model = initData.model;
            this.num_process_cores = initData.num_process_cores;
            this.memory = initData.memory;
            this.num_nic_1gb = initData.num_nic_1gb;
            this.num_nic_10gb = initData.num_nic_10gb;
            this.num_hba = initData.num_hba;
            this.ht = initData.ht;
            this.san = initData.san;
            this.networks = initData.networks;
        }
    }

    validate(): boolean {
        return true;
    }
}

export class LinuxGroupPhysical {

    rack_loc: string = "";  // 0775-AI14
    top_u: string = "";    // 19

    loip: string = "";      // Ip Address
    lonetwork: string = "";
    loswitch: string = "";    // ho-ggg35-sw3-210 P11
    loport: string = ""; // Port for the switch
    security_zone: string = "";

    networkTeamConfig: LinuxGroupPhysicalTeam[] = [];

    constructor(initData?: any) {
        if (initData) {
            this.rack_loc = initData.rack_loc;
            this.top_u = initData.top_u;
            this.loip = initData.loip;
            this.lonetwork = initData.lonetwork;
            this.loswitch = initData.loswitch;
            this.loport = initData.loport;
            this.security_zone = initData.security_zone;
            if (initData.networkTeamConfig) {
                for (let i = 0; i < initData.networkTeamConfig.length; i++) {
                    this.networkTeamConfig[i] = new LinuxGroupPhysicalTeam(initData.networkTeamConfig[i]);
                }
            }
        }
    }

    addTeam(): LinuxGroupPhysicalTeam {
        var newTeam = new LinuxGroupPhysicalTeam();
        this.networkTeamConfig[this.networkTeamConfig.length] = newTeam;
        return newTeam;
    }

    getTeam(selectedTeam: number): LinuxGroupPhysicalTeam {
        // Make sure that we can access the node.
        if (selectedTeam < this.networkTeamConfig.length)
            return this.networkTeamConfig[selectedTeam];
    }

    removeTeam(selectedTeam: number): void {
        if (selectedTeam < this.networkTeamConfig.length) {
            this.networkTeamConfig.splice(selectedTeam, 1);
        }
    }

    validate(): boolean {
        return true;
    }
}

