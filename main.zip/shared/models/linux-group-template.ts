import { Constants } from '../config/constants';
import { LinuxGroupCloud } from './linux-group-cloud';
import { LinuxGroupConfig } from './linux-group-config';
import { LinuxGroupLocalDasd } from './linux-group-local-dasd';
import { LinuxGroupManagement } from './linux-group-management';
import { LinuxGroupNetwork } from './linux-group-network';
import { LinuxGroupPhysical, LinuxGroupPhysicalSE } from './linux-group-physical';
import { LinuxGroupServer } from './linux-group-server';
import { LinuxGroupVmware } from './linux-group-vmware';
import { LinuxGroupNas } from './linux-group-nas';
import { LinuxGroupAppliance } from './linux-group-appliance';

export class LinuxGroupTemplate {

    group_name: string = "";
    business_unit: string = "";
    env_type: string = "Production";
    osType: string = "lin";
    cmdb_app_name: string = "";
    primary_app_contact: string = "";
    secondary_app_contact: string = "";
    sppt_it_org: string = "";
    mgmt: LinuxGroupManagement;
    appliance: LinuxGroupAppliance;
    server: LinuxGroupServer;
    vmware: LinuxGroupVmware;
    cloud: LinuxGroupCloud;
    physical: LinuxGroupPhysicalSE;
    phys: LinuxGroupPhysical[] = [];
    local_dasd: LinuxGroupLocalDasd;
    config: LinuxGroupConfig;
    network: LinuxGroupNetwork;
    nas: LinuxGroupNas[] = [];

    constructor(initData?: any) {
        if (initData) {
            this.group_name = initData.group_name;
            this.business_unit = initData.business_unit;
            this.env_type = initData.env_type;
            this.osType = initData.osType;
            this.cmdb_app_name = initData.cmdb_app_name;
            this.primary_app_contact = initData.primary_app_contact;
            this.secondary_app_contact = initData.secondary_app_contact;
            this.sppt_it_org = (initData.sppt_it_org) ? initData.sppt_it_org : "";
            this.mgmt = new LinuxGroupManagement(initData.mgmt);
            this.appliance = new LinuxGroupAppliance(initData.appliance);
            this.server = new LinuxGroupServer(initData.server);
            this.vmware = new LinuxGroupVmware(initData.vmware);
            this.cloud = new LinuxGroupCloud(initData.cloud);
            this.local_dasd = new LinuxGroupLocalDasd(initData.local_dasd);
            this.config = new LinuxGroupConfig(initData.config);
            this.physical = new LinuxGroupPhysicalSE(initData.physical);
            this.network = new LinuxGroupNetwork(initData.network);
            if (initData.nas) {
                for (let i = 0; i < initData.nas.length; i++) {
                    this.nas[i] = new LinuxGroupNas(initData.nas[i]);
                }
            }
            if (initData.phys) {
                for (let i = 0; i < initData.phys.length; i++) {
                    this.phys[i] = new LinuxGroupPhysical(initData.phys[i]);
                }
            }
        }
        else {
            this.mgmt = new LinuxGroupManagement();
            this.server = new LinuxGroupServer();
            this.vmware = new LinuxGroupVmware();
            this.cloud = new LinuxGroupCloud();
            this.local_dasd = new LinuxGroupLocalDasd();
            this.config = new LinuxGroupConfig();
            this.network = new LinuxGroupNetwork();
            this.appliance = new LinuxGroupAppliance();
            this.physical = new LinuxGroupPhysicalSE();
        }
    }

    addNas(): LinuxGroupNas {

        var newNas = new LinuxGroupNas();
        this.nas[this.nas.length] = newNas;
        return newNas;
    }

    getNas(selectedNas: number): LinuxGroupNas {
        // Make sure that we can access the node.
        if (selectedNas < this.nas.length)
            return this.nas[selectedNas];
    }

    removeNas(selectedNas: number): void {
        if (selectedNas < this.nas.length) {
            this.nas.splice(selectedNas, 1);
        }
    }

    addPhysical(): LinuxGroupPhysical {
        var newPhysical = new LinuxGroupPhysical();
        this.phys[this.phys.length] = newPhysical;
        return newPhysical;
    }

    getPhysical(selectedPhysical: number): LinuxGroupPhysical {
        // Make sure that we can access the node.
        if (selectedPhysical < this.phys.length)
            return this.phys[selectedPhysical];
    }

    removePhysical(selectedPhysical: number): void {
        if (selectedPhysical < this.phys.length) {
            this.phys.splice(selectedPhysical, 1);
        }
    }

    validate(): boolean {
        return true;
    }
}
