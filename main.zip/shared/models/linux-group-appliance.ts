import { Constants } from '../config/constants';

export class LinuxGroupAppliance {
  appliance_name: string = '';
  datacenter: string = '';
  num_appliances: string = '';
  cpu: string = '';
  memory: string = '';
  disk: string = '';
  security_group: string = '';
  image_path: string = '';
  doc_path: string = '';
  virt_host_env_fldr: string = '';
  targetcluster: string = '';

  constructor(initData?: any) {
    if (initData) {
      this.appliance_name = initData.appliance_name;
      this.datacenter = initData.datacenter;
      this.num_appliances = initData.num_appliances;
      this.cpu = initData.cpu;
      this.memory = initData.memory;
      this.disk = initData.disk;
      this.security_group = initData.security_group;
      this.image_path = initData.image_path;
      this.doc_path = initData.doc_path;
      this.virt_host_env_fldr = initData.virt_host_env_fldr;
      this.targetcluster = initData.targetcluster;
    }
  }

  validate(): boolean {
    return true;
  }
}
