import { WasNodeTemplate } from './was-node-template';
import { WasJvmTemplate } from './was-jvm-template';
import { WasIhsTemplate } from './was-ihs-template';
import { Constants } from '../config/constants';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

export class WasCell {

    _id: string = "";
    appName: string = "";
    tciCode: string = "";
    envNumber: string = Constants.STARTING_ENV_NUMBER;
    cellname: string = "";

    envTypes: string[] = Constants.ENV_TYPES;
    selectedEnvType: string = Constants.DEF_ENV_TYPE;
    envTypeCode: string;

    ldapTypes: string[] = Constants.LDAP_TYPES;
    selectedLdapType: string = Constants.DEF_LDAP_TYPE;

    wasVersions: string[] = Constants.WAS_VERSIONS;
    selectedWasVersion: string = "";
    wasVersionCode: string;


    ldapId: string = Constants.DEF_LDAP_ID;
    ldapBindId: string = Constants.DEF_BIND_ID;
    runasId: string = Constants.DEF_RUNAS_ID;
    globalSecurityGroup: string = "";
    monitorSecurityGroup: string = "";
    hasClusters: boolean = false;

    clusterNames: string[] = [];

    installType: string = "WAS_ND";
    fixLevel: string = "No";

    dmgrNode: string = "";
    dmgrName: string = "";
    dmgrMinHeap: string = "512";
    dmgrMaxHeap: string = "1024";
    dmgrPort: string = Constants.WAS_DEF_DMGR_PORTBLOCK;

    numNodes: number = 0;
    totalJvms: number = 0;
    totalIhs: number = 0;
    javaVersion: string = "8.0_64";
    installRoot: string = "/apps/ki01";
    installAsRoot: boolean = false;
    standaloneLdap: boolean = false;
    separateBinaries: boolean = false;
    oldStandards: boolean = true;
    actionType: string = "NewInstall";
    installLocation: string = "/apps/ki01/WebSphere9/AppServer";

    nodeTemplates: WasNodeTemplate[] = [];
    status: any[] = [];

    constructor(initData?: any) {
        // If we are coming to edit a cell, then initialize the cell data from the database info.
        if (initData) {
            this._id = initData._id;
            this.numNodes = initData.numNodes;
            this.cellname = initData.cellname;
            this.envNumber = initData.envNumber;
            this.tciCode = initData.tciCode;
            this.appName = initData.appName;
            this.ldapBindId = initData.ldapBindId;
            this.ldapId = initData.ldapId;
            this.globalSecurityGroup = initData.globalSecurityGroup;
            this.monitorSecurityGroup = initData.monitorSecurityGroup;
            this.clusterNames = initData.clusterNames;
            this.dmgrNode = initData.dmgrNode;
            this.dmgrName = initData.dmgrName;
            this.installAsRoot = initData.installAsRoot;
            this.dmgrMinHeap = initData.dmgrMinHeap;
            this.dmgrMaxHeap = initData.dmgrMaxHeap;
            this.runasId = initData.runasId;
            this.selectedEnvType = initData.selectedEnvType;
            this.selectedLdapType = initData.selectedLdapType;
            this.selectedWasVersion = initData.selectedWasVersion;
            this.envTypeCode = initData.envTypeCode;
            this.fixLevel = initData.fixLevel;
            this.wasVersionCode = initData.wasVersionCode;
            this.javaVersion = initData.javaVersion;
            this.installType = initData.installType;
            this.standaloneLdap = initData.standaloneLdap;
            let token = this.cellname.split("-");
            /* Disable the standards
            if (token.length > 2) {
                if (token[1].length > 4) {
                    this.oldStandards = true;
                }
                else
                    this.oldStandards = false;
            }
            */
            this.oldStandards = true;
            this.dmgrPort = initData.dmgrPort;
            this.status = initData.status || [];
            if (initData.clusterNames) {
                if (initData.clusterNames.length > 0) {
                    this.hasClusters = true;
                    initData.hasClusters = true;
                }
            }
            if (initData.numNodes > 0) {
                for (var i = 0; i < initData.numNodes; i++) {
                    this.nodeTemplates[i] = new WasNodeTemplate(initData.nodeTemplates[i]);
                    // For this node, initialize the jvms and http servers.
                    if (initData.nodeTemplates[i].numJvms) {
                        this.nodeTemplates[i].numJvms = initData.nodeTemplates[i].numJvms;
                        for (var j = 0; j < initData.nodeTemplates[i].numJvms; j++) {
                            this.nodeTemplates[i].jvmTemplates[j] = new WasJvmTemplate(initData.nodeTemplates[i].jvmTemplates[j]);
                        }
                        this.totalJvms += this.nodeTemplates[i].numJvms;
                    }
                    if (initData.nodeTemplates[i].numHttpServers) {
                        this.nodeTemplates[i].numHttpServers = initData.nodeTemplates[i].numHttpServers;
                        for (var j = 0; j < initData.nodeTemplates[i].numHttpServers; j++) {
                            this.nodeTemplates[i].ihsTemplates[j] = new WasIhsTemplate(initData.nodeTemplates[i].ihsTemplates[j]);
                        }
                        this.totalIhs += this.nodeTemplates[i].numHttpServers;
                    }
                }
            }
        }
        else {
            this.addNode(); // Start with one node.
            this.envTypeCode = this.selectedEnvType.slice(0, 2); // strip the first two characters for default.
            if (this.selectedWasVersion)
                this.wasVersionChanged(this.selectedWasVersion);

        }
    }

    findDuplicateClusterNames(): any {
        var sortedNames = this.clusterNames.slice().sort();
        var results = [];

        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }
        return results;
    }

    findDuplicateJvmNames(): any {
        // Get all the jvm names first
        let jvmNames = [];
        this.nodeTemplates.forEach(node => {
            // Process each node.
            node.jvmTemplates.forEach(jvm => {
                jvmNames.push(jvm.jvmName);
            });
        });

        // Find any duplicates
        let sortedNames = jvmNames.slice().sort();
        let results = [];
        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }

        // return the results.
        return results;
    }

    findJvmsWithNoClusters(): any {
        // Get all the jvm names first
        let jvmNames = [];
        this.nodeTemplates.forEach(node => {
            // Process each node.
            node.jvmTemplates.forEach(jvm => {
                // We want to know if this jvm is assigned to a cluster
                // so check for clusters which are not 'none'
                if (jvm.clusterName === "none" || jvm.clusterName === "") {
                    jvmNames.push(jvm.jvmName);
                }
            });
        });

        // return the results.
        return jvmNames;
    }

    findDuplicateIhsNames(): any {
        // Get all the jvm names first
        let ihsNames = [];
        this.nodeTemplates.forEach(node => {
            // Process each node.
            node.ihsTemplates.forEach(ihs => {
                ihsNames.push(ihs.ihsName);
            });
        });

        // Find any duplicates
        let sortedNames = ihsNames.slice().sort();
        let results = [];
        for (var i = 0; i < sortedNames.length - 1; i++) {
            if (sortedNames[i + 1] == sortedNames[i]) {
                results.push(sortedNames[i]);
            }
        }

        // return the results.
        return results;
    }

    setWasVersions(versions: any, update: boolean) {
        this.wasVersions = versions;
        // If version is not set, then set it to default.
        if (!this.selectedWasVersion)
            this.selectedWasVersion = this.wasVersions[0];
        if (update)
            this.wasVersionChanged(this.selectedWasVersion);
    }

    addNode(): void {
        this.numNodes++;
        // Lets say that we had 4 nodes and user removed a node. In this case we want to keep the data in the array and not
        // lose it. So check if the total nodes is less than the nodeTemplates Length.
        if (this.numNodes < this.nodeTemplates.length)
            this.nodeTemplates = this.nodeTemplates.slice(0, this.numNodes);
        else {
            for (var i = this.nodeTemplates.length; i < this.numNodes; i++) {
                this.nodeTemplates[i] = new WasNodeTemplate();
            }
        }
        this.updateNodeNames();
    }

    updateNodeNames(): void {
        var portsInUse = [];
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
            var newPort;
            if (this.nodeTemplates[i].portBlock === Constants.WAS_DEF_NODE_PORTBLOCK) {
                newPort = Number(Constants.WAS_DEF_NODE_PORTBLOCK) + i + 1;
            }
            else {
                // Existing Node
                newPort = Number(this.nodeTemplates[i].portBlock);
            }

            // Check to see if this port is already in use.
            if (portsInUse.length > 0) {
                if (portsInUse.includes(newPort)) {
                    // Port exists in the array. 
                    // Get the max value from the array and add 1 to it.
                    newPort = Math.max(...portsInUse) + 1;
                }
            }

            portsInUse.push(newPort);

            this.nodeTemplates[i].portBlock = newPort.toString();
        }
        // Update the port blocks.
    }

    updateNodeWasVersion(wasVersion) {
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            if (this.nodeTemplates[i].nodeName) {
                var nodenamesarr = this.nodeTemplates[i].nodeName.split("-");
                if (nodenamesarr.length === 4) {
                    // name conforms to our standard. Now Parse it.
                    var tmp = nodenamesarr[1].slice(0, nodenamesarr[1].length - 2)
                    var currversion = nodenamesarr[1].slice(-2);
                    var reg = new RegExp(/^\d+$/);
                    if (reg.test(currversion)) {
                        console.log("WAS VERSION " + wasVersion);
                        if (this.oldStandards) { // Only for old standards we want to change the names 
                            var newname = nodenamesarr[0] + "-" + tmp + wasVersion + "-" + nodenamesarr[2] + "-" + nodenamesarr[3];
                            this.nodeTemplates[i].nodeName = newname;
                        }
                    }
                }
            }
        }
    }

    updateNodeEnvType(envType) {
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            if (this.nodeTemplates[i].nodeName) {
                var nodenamesarr = this.nodeTemplates[i].nodeName.split("-");
                if (nodenamesarr.length === 4) {
                    // name conforms to our standard. Now Parse it.
                    var token3 = envType + nodenamesarr[2].substr(2, 2);
                    this.nodeTemplates[i].nodeName = nodenamesarr[0] + "-" + nodenamesarr[1] + "-" + token3 + "-" + nodenamesarr[3];
                }
            }
        }
    }

    updateNodeEnvNbr(envNbr) {
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            if (this.nodeTemplates[i].nodeName) {
                var tokens = this.nodeTemplates[i].nodeName.split("-");
                if (tokens.length === 4) {
                    // name conforms to our standard. Now Parse it.
                    var currnbr = tokens[2].slice(-2);
                    var reg = new RegExp(/^\d+$/);
                    if (reg.test(currnbr)) {
                        var token3 = tokens[2].substr(0, 2) + envNbr;
                        this.nodeTemplates[i].nodeName = tokens[0] + "-" + tokens[1] + "-" + token3 + "-" + tokens[3];
                    }
                }
            }
        }
    }


    setNode(selectedNode: number, _node: WasNodeTemplate) {
        this.nodeTemplates[selectedNode] = _node;
    }

    getNode(selectedNode: number): WasNodeTemplate {
        // Make sure that we can access the node.
        if (selectedNode < this.numNodes)
            return this.nodeTemplates[selectedNode];
    }

    get totalNodes(): number {
        return this.numNodes;
    }

    removeNode(selectedNode: number): void {
        if (selectedNode < this.numNodes) {
            this.nodeTemplates.splice(selectedNode, 1);
            this.numNodes--;
        }
        this.updateNodeNames();
    }

    envNbrChanged(_envNbr: string) {
        this.envNumber = _envNbr;
        this.buildCellName();
        this.updateNodeEnvNbr(this.envNumber);
        this.updateJvmAndIhsEnvNbr(this.envNumber);
        this.buildDmgrName();
        this.updateClusterEnvNbr(this.envNumber);
    }

    setEnvType(envTypeCd: string) {
        for (let i = 0; i < this.envTypes.length; i++) {
            if (this.envTypes[i].startsWith(envTypeCd))
                this.selectedEnvType = this.envTypes[i];
        }
    }

    envTypeChanged(_envType: string) {
        // Extract the code
        this.envTypeCode = _envType.slice(0, 2);
        // If the Env Type Changed to Prod, then switch the runasID and Bind ID Defaults.
        if (this.envTypeCode.startsWith(Constants.PROD_ENV_CODE) || this.envTypeCode.startsWith(Constants.DR_ENV_CODE)) {
            this.selectedLdapType = Constants.PROD_LDAP_TYPE;
            this.runasId = Constants.PROD_RUNAS_ID;
            this.ldapBindId = Constants.PROD_BIND_ID;
        }
        else {
            this.runasId = Constants.DEF_RUNAS_ID;
            this.ldapBindId = Constants.DEF_BIND_ID;
            if (this.envTypeCode.startsWith(Constants.ETEST_ENV_CODE))
                this.selectedLdapType = Constants.ETEST_LDAP_TYPE;
            else
                this.selectedLdapType = Constants.DEF_LDAP_TYPE;
        }
        this.buildCellName();
        this.updateNodeEnvType(this.envTypeCode);
        this.updateJvmAndIhsEnvType(this.envTypeCode);
        this.buildDmgrName();
        this.updateClusterEnvType(this.envTypeCode);
    }

    wasVersionChanged(_wasVersion: string) {
        // Extract the code
        this.wasVersionCode = _wasVersion.replace('.', '').slice(0, 2);
        this.buildCellName();
        this.updateNodeWasVersion(this.wasVersionCode);
        this.updateJvmAndIhsVersionCode(this.wasVersionCode);
        this.buildDmgrName();
    }

    processChangeStandards() {
        this.buildCellName();
        this.updateNodeEnvType(this.envTypeCode);
        this.updateNodeWasVersion(this.wasVersionCode);
        this.updateJvmAndIhsVersionCode(this.wasVersionCode);
        this.buildDmgrName();
    }

    ldapTypeChanged(_ldapType: string) {
    }

    tciCodeChanged(_tciCode: string) {
        this.updateNames();
    }

    getTotalJvms(): number {
        return this.totalJvms;
    }

    getTotalIhs(): number {
        return this.totalIhs;
    }

    updateJvmAndIhsEnvNbr(envNbr): void {
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmEnvNbr(envNbr);
                this.nodeTemplates[i].updateIhsEnvNbr(envNbr);
            }
        }
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }

    updateJvmAndIhsVersionCode(verCode): void {
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmVerCode(this.oldStandards, verCode); // Don't update version
                this.nodeTemplates[i].updateIhsVerCode(this.oldStandards, verCode);
            }
        }

        for (var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }

    updateJvmAndIhsEnvType(envType): void {
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmEnvType(envType);
                this.nodeTemplates[i].updateIhsEnvType(envType);
            }
        }
        for (var i = 0; i < this.nodeTemplates.length; i++) {
            this.nodeTemplates[i].nodeName = this.buildNodeName(this.nodeTemplates[i].nodeName, i);
        }
    }

    updateJvmAndIhsTciCode(tciCode): void {
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateJvmTciCode(tciCode);
                this.nodeTemplates[i].updateIhsTciCode(tciCode);
            }
        }
    }

    updateNames(): void {

        this.buildCellName();
        this.updateNodeNames();
        this.buildDmgrName();
        this.updateJvmAndIhsTciCode(this.tciCode);
        this.updateClusterTciCode(this.tciCode);

    }

    buildCellName(): void {
        // Build a cell name when either tcicode, env number or version changes.
        if (this.oldStandards) {
            this.cellname = this.tciCode + Constants.WAS_CELLNAME_PREFIX + this.wasVersionCode + "-" + this.envTypeCode + this.envNumber;
        }
        else
            this.cellname = this.tciCode + Constants.WAS_CELLNAME_PREFIX + "-" + this.envTypeCode + this.envNumber;
    }

    buildDmgrName(): void {
        // Build a cell name when either tcicode, env number or version changes.
        if (this.oldStandards) {
            this.dmgrName = this.tciCode + Constants.WAS_DMGRNAME_PREFIX + this.wasVersionCode + "-" + this.envTypeCode + this.envNumber;
        }
        else
            this.dmgrName = this.tciCode + Constants.WAS_DMGRNAME_PREFIX + "-" + this.envTypeCode + this.envNumber;
    }

    buildClusterName(): string {
        // Build a cell name when either tcicode, env number or version changes.
        return this.tciCode + Constants.CLUSTER_PREFIX + "-" + this.envTypeCode + this.envNumber;
    }

    updateClusterEnvType(envType) {
        for (var i = 0; i < this.clusterNames.length; i++) {
            var name = this.clusterNames[i];
            this.clusterNames[i] = this.updateClusterName(name);
        }
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateClusterEnvType(envType);
            }
        }
    }

    updateClusterTciCode(tciCode) {
        for (var i = 0; i < this.clusterNames.length; i++) {
            var name = this.clusterNames[i];
            this.clusterNames[i] = this.updateClusterName(name);
        }
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateClusterTciCode(tciCode);
            }
        }
    }

    updateClusterEnvNbr(envNbr) {
        for (var i = 0; i < this.clusterNames.length; i++) {
            var name = this.clusterNames[i];
            this.clusterNames[i] = this.updateClusterName(name);
        }
        if (this.numNodes > 0) {
            for (var i = 0; i < this.numNodes; i++) {
                this.nodeTemplates[i].updateClusterEnvNbr(envNbr);
            }
        }

    }

    updateClusterName(name): string {
        var pos1 = name.indexOf("-");  // get the location of the first -
        var pos2 = name.lastIndexOf("-");
        var cluster = name.substring(pos1 + 1, pos2);
        var newname = this.tciCode + "-" + cluster + "-" + this.envTypeCode + this.envNumber;
        return newname;
    }

    buildNodeName(_nodeName: string, index: number): string {
        // Build a cell name when either tcicode, env number or version changes.
        var nodeName = "";
        var idx = "";
        index = index + 1;
        if (index < 10)
            idx = '0' + index.toString();
        else
            idx = index.toString();
        if (this.oldStandards) {
            nodeName = this.tciCode + Constants.WAS_NODENAME_PREFIX + this.wasVersionCode + "-" + this.envTypeCode + this.envNumber + "-" + idx;
        }
        else
            nodeName = this.tciCode + Constants.WAS_NODENAME_PREFIX + "-" + this.envTypeCode + this.envNumber + "-" + idx;
        return nodeName;
    }

    isValidTCI(): boolean {
        if (this.tciCode && this.tciCode.length >= Constants.MIN_TCICODE_LEN)
            return true;
        else
            return false;
    }

    validate(): boolean {
        var isValid = false;
        this.nodeTemplates.forEach(function (node) {
            isValid = node.validate();
        });
        return isValid;
    }
}
