import { EnvType } from '../models/env-type';
import { LdapType } from '../models/ldap-type';
import { environment } from '../../../../environments/environment';

export class Constants {

    // Constants for Liberty Design Pages
    public static MAX_HOSTNAME_LEN: number = 7;
    public static MIN_TCICODE_LEN: number = 2;
    public static STARTING_IHS_PORT_BLOCK: number = 100;
    public static STARTING_JVM_PORT_BLOCK: number = 210;
    public static STARTING_CNTRL_PORT_BLOCK: number = 200;
    public static STARTING_ENV_NUMBER: string = "001";

    public static OPERATOR_TYPES = ['CONTAINS', 'DOES NOT CONTAIN', 'EQUALS', 'NOT EQUALS', 'GREATER THAN', 'LESS THAN', 'LIKE', 'STARTS WITH', 'ENDS WITH'];

    public static PRODUCT_TYPES = ['Liberty-Core', 'Liberty-Base', 'Liberty-ND'];
    public static ENV_TYPES = ['sb-sandbox', 'dv-development', 'ft-function test', 'rt-regression test', 'it-integration test',
        'st-system test', 'et-etest', 'pp-pre prod', 'hf-hot fix', 'sc-show case', 'pt-performance test', 'pd-production', 'pb-prod backup'];
    public static DEF_ENV_TYPE = "dv-development";
    public static LDAP_TYPES = ['prod', 'test', 'etest'];
    public static DEF_LDAP_TYPE = "prod";
    public static ETEST_LDAP_TYPE = "etest";
    public static PROD_LDAP_TYPE = "prod";


    public static WLP_JAVA = [
        { wlp: "17.0.0.4", java: "8.0.5.7" },
        { wlp: "17.0.0.3", java: "8.0.5.0" },
        { wlp: "17.0.0.2", java: "8.0.4.6" },
        { wlp: "17.0.0.1", java: "8.0.4.1" },
        { wlp: "16.0.0.4", java: "8.0.3.21" }];

    public static JAVA_VERSIONS = ['8.0'];
    public static WLP_JAVA_VERSIONS = Constants.WLP_JAVA.map(function (a) { return a.java });
    public static IHS_VERSIONS = ['9.0.0.1', '9.0.0.2', '9.0.0.3', '9.0.0.4', '9.0.0.5', '9.0.0.6'];
    public static WLP_VERSIONS = Constants.WLP_JAVA.map(function (a) { return a.wlp; });
    public static DEF_WLP_VERSION = Constants.WLP_VERSIONS[0];
    public static DEF_JAVA_VERSION = Constants.JAVA_VERSIONS[0];
    public static DEF_WLP_JAVA_VERSION = Constants.WLP_JAVA_VERSIONS[0];
    public static DEF_IHS_VERSION = Constants.IHS_VERSIONS[Constants.IHS_VERSIONS.length - 1];
    public static DEF_LDAP_ID = "sys-kiwadminsb";
    public static DEF_BIND_ID = "sys-kibindsb";
    public static DEF_RUNAS_ID = "kiwasdv"
    public static PROD_ENV_CODE = "pd";
    public static DR_ENV_CODE = "pb";
    public static ETEST_ENV_CODE = "et";
    public static PROD_BIND_ID = "sys-kiwadminsb";
    public static PROD_RUNAS_ID = "kiwaspd";

    // Prefixes used when generating Cell, node and jvm names.
    public static CONTROLLER_PREFIX = "-cntrlr";
    public static CLUSTER_PREFIX = "-clstr";
    public static WLC_CELLNAME_PREFIX = "-wlc";
    public static WLB_CELLNAME_PREFIX = "-wlb";
    public static WLN_CELLNAME_PREFIX = "-wln";
    public static WLP_NODENAME_PREFIX = "-node";
    public static WLP_JVMNAME_PREFIX = "-wlp";
    public static WLP_IHSNAME_PREFIX = "-ihs";
    public static WLP_LIBERTY_CORE = "Liberty-Core";
    public static WLP_LIBERTY_BASE = "Liberty-Base";
    public static WLP_LIBERTY_ND = "Liberty-ND";

    // Prefixes used when generating Cell, node and jvm names.
    public static WAS_VERSIONS = ['9.0.0.4', '9.0.0.3', '9.0.0.2', '9.0.0.1', '8.5.5.10',
        '9.0.0.0', '8.5.5.12', '8.5.5.11', '8.5.5.10', '8.5.5.9',
        '8.5.5.8', '8.5.5.7', '8.5.5.6', '8.5.5.5', '8.5.5.4',
        '8.5.5.3', '8.5.5.2', '8.5.5.1', '8.5.5.0', '8.5.0.2',
        '8.5.0.1', '8.5.0.0', '8.0.0.13', '8.0.0.6', '8.0.0.4',
        '8.0.0.3', '8.0.0.0']
    public static DEF_WAS_VERSION = '9.0.0.4';
    public static WAS_CELLNAME_PREFIX = "-cell";
    public static WAS_DMGRNAME_PREFIX = "-dmgr";
    public static WAS_NODENAME_PREFIX = "-node";
    public static WAS_JVMNAME_PREFIX = "-jvm";
    public static WAS_IHSNAME_PREFIX = "-ihs";
    public static WAS_DEF_NODE_PORTBLOCK = "290";
    public static WAS_DEF_DMGR_PORTBLOCK = "201";

    public static INSTALL_WAS_BASE = "WAS_BASE";

    public static CONFIG = { 'API_PATH': '/api/v1' }

    public static DATE_FORMAT = 'MMMM Do YYYY, h:mm:ss a';

    public static ENDPOINTS = { 'ADMIN': 'WC_adminhost' }

    public static DMGR_LINK = 'http://' + '%host%' + ':' + '%port%' + '/ibm/console/logon.jsp';
    public static REST_ERR = [{ 'ERR_NOT_AUTHORIZED': 'User is not authorized for this action' }, { 'ERR_NOT_AUTHENTICATED': 'User is not authenticated' }];
    public static WORKFLOW_ERR = { "JOB_PROCESS_ERROR": "Error encounted running job" }
    public static WORKFLOW_WARN = { "JOB_PAST_DUE": "Job is past due" }
    //Negative projections for inventory search to reduce payload size
    public static INVENTORY_TRIM = '-globalSecurity,-nodes.servers';

    public static NODE_TYPES = {
        'DMGR': { value: 'DEPLOYMENT_MANAGER', label: 'Deployment Manager', diffLabel: 'Dmgr' },
        'HTTP': { value: 'WEB_SERVER', label: 'Web Server', diffLabel: 'Http' },
        'NODE': { value: 'NODE_AGENT', label: 'Node Agent', diffLabel: 'Node' },
        'APP_SERVER': { value: 'APPLICATION_SERVER', label: 'App Server', hideFromDesigner: true }
    }

    public static INSTALL_TYPES = {
        'TOMCAT': { value: 'TOMCAT', label: 'Tomcat' },
        'ND': { value: 'WAS_ND', pvu: 70, label: 'WebSphere Network Deployment' },
        'BASE': { value: 'WAS_BASE', label: 'WebSphere Base' },
        'PORTAL': { value: 'WAS_PORTAL', pvu: 120, label: 'WebSphere Portal' },
        'LIBERTY_ND': { value: 'WLP_ND', label: 'WebSphere Liberty Network Deployment' },
        'LIBERTY_BASE': { value: 'WLP_BASE', label: 'WebSphere Liberty Base' },
        'LIBERTY_CORE': { value: 'WLP_CORE', label: 'WebSphere Liberty Core' }
    }

    constructor() {
    }

    static getWasInstallRootPath(): string {
        return environment.was_install_root_path;
    }

    static getImInstallRootPath(): string {
        return environment.im_install_root_path;
    }

    static getImInstallPath(): string {
        return environment.im_install_path;
    }

    static getImDataRootPath(): string {
        return environment.im_data_root_path;
    }

    static getImSharedRootPath(): string {
        return environment.im_shared_root_path;
    }

    static getImSharedPath(): string {
        return environment.im_shared_path;
    }

    static getWasGlobalSecurityPath(): string {
        return environment.was_globalsecurity_path;
    }

    static getWasHttpdConfLocPath(): string {
        return environment.was_httpdconfloc_path;
    }

    static getWasInstallationPath(): string {
        return environment.was_installation_path;
    }

    static getWlpBaseDir(): string {
        return environment.wlp_basedir;
    }

    static getWlpTemplatePath(): string {
        return environment.wlp_template_path;
    }

    static getWlpCommonPath(): string {
        return environment.wlp_common_path;
    }

    static getNasPath(): string {
        return environment.nas_path;
    }

    static getWasOpsPath(): string {
        return environment.wasops_path;
    }

    static getSignerCertsPath(): string {
        return environment.signer_certs_path;
    }

    static getLoginUrl(): string {
        return environment.gateway_server_url + environment.login_url;
    }

    static getValidateUrl(): string {
        return environment.gateway_server_url + environment.validate_url;
    }

    static getWlpVersionsUrl(): string {
        return environment.base_server_url + environment.wlpversions_url;
    }

    static getWlpDesignUrl(): string {
        return environment.base_server_url + environment.wlp_design_url;
    }

    static getWasDesignUrl(): string {
        return environment.base_server_url + environment.was_design_url;
    }

    static getReportUrl(): string {
        return environment.base_server_url + environment.report_url;
    }

    static getConfigDriftUrl(): string {
        return environment.base_server_url + environment.config_drift_url;
    }

    static getDcioUrl(): string {
        return environment.base_server_url + environment.dcio_url;
    }

    static getServersInventoryUrl(): string {
        return environment.base_server_url + environment.servers_inventory_url;
    }

    static getWasInventoryUrl(): string {
        return environment.base_server_url + environment.was_inventory_url;
    }

    static getWasInventoryHistoryUrl(): string {
        return environment.base_server_url + environment.was_inventory_history_url;
    }

    static getWasInvSummaryUrl(): string {
        return environment.base_server_url + environment.was_inventory_summary_url;
    }

    static getWasInvSummaryHistoryUrl(): string {
        return environment.base_server_url + environment.was_inventory_summary_history_url;
    }

    static getWlpInventoryUrl(): string {
        return environment.base_server_url + environment.wlp_inventory_url;
    }

    static getWlpInventoryHistoryUrl(): string {
        return environment.base_server_url + environment.wlp_inventory_history_url;
    }

    static getTagDefinitionsUrl(): string {
        return environment.base_server_url + environment.tag_definitions_url;
    }

    static getTagsUrl(): string {
        return environment.base_server_url + environment.tags_url;
    }

    static getWasPackagesUrl(): string {
        return environment.base_server_url + environment.was_package_url;
    }

    static getWasFixpacksUrl(): string {
        return environment.base_server_url + environment.was_fixpack_url;
    }

    static getWlpPackagesUrl(): string {
        return environment.base_server_url + environment.wlp_version_url;
    }

    static getDeployLibertyCellUrl(): string {
        return environment.deployment_service_url + environment.deploy_liberty_cell_url;
    }

    static getDeployLinuxUrl(): string {
        return environment.deployment_service_url + environment.deploy_linux_url;
    }

    static getDeployWasCellUrl(): string {
        return environment.deployment_service_url + environment.deploy_was_cell_url;
    }

    static getDiscoverWlpWorkflowUrl(): string {
        return environment.deployment_service_url + environment.discover_wlp_workflow_url;
    }

    static getDiscoverLinuxWorkflowUrl(): string {
        return environment.deployment_service_url + environment.discover_linux_workflow_url;
    }

    static getDiscoverWasWorkflowUrl(): string {
        return environment.deployment_service_url + environment.discover_was_workflow_url;
    }

    static getDiscoverWorkflowUrl(): string {
        return environment.deployment_service_url + environment.discover_workflow_url;
    }

    static getLinuxDesignUrl(): string {
        return environment.linux_server_url + environment.linux_design_url;
    }

    static getBusUnitsUrl(): string {
        return environment.servicenow_url + environment.bus_units_url;
    }

    static getBusAppsUrl(): string {
        return environment.servicenow_url + environment.bus_apps_url;
    }


    static getBusDcioUrl(): string {
        return environment.servicenow_url + environment.bus_dcio_url;
    }

    static getBusSupportingOrgsUrl(): string {
        return environment.servicenow_url + environment.bus_supporting_orgs_url;
    }

    static getBusAreasUrl(): string {
        return environment.servicenow_url + environment.bus_areas_url;
    }

    static getSoftwareProductsUrl(): string {
        return environment.servicenow_url + environment.software_products_url;
    }

    static getVropsHudsonUrl(): string {
        return environment.servicenow_url + environment.vrops_hudson_url;
    }

    static getVropsRochelleUrl(): string {
        return environment.servicenow_url + environment.vrops_rochelle_url;
    }

    static getVropsHudsonPropsUrl(): string {
        return environment.servicenow_url + environment.vrops_hudson_props_url;
    }

    static getVropsRochellePropsUrl(): string {
        return environment.servicenow_url + environment.vrops_rochelle_props_url;
    }

    static getpreCheckUrl(): string {
        return environment.precheck_url + environment.precheck_api;
    }

    static getOpsServiceUrl(): string {
        return environment.ops_service_url;
    }

    static getServersUrl(): string {
        return environment.linux_server_url + environment.servers_url;
    }
}