import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'input-dialog',
  template: `
     <mat-card>
      <mat-card-title>{{ title }}</mat-card-title>
      <mat-card-content>
      <p innerHtml="{{message}}"></p>
        <div style="margin-top:20px">
          <mat-input-container>
            <input matInput [(ngModel)]="inputField" placeholder="{{placeHolderText}}"/>
          </mat-input-container>
        </div>
      </mat-card-content>
      <mat-card-actions align="end">
        <button mat-raised-button color="primary" (click)="save()">Save</button>
        <button mat-raised-button (click)="cancel()">Cancel</button>
      </mat-card-actions>
    </mat-card>
  `,
  styles: []
})
export class InputDialog {

  public title: string;
  public message: string;
  public placeHolderText: string;
  public inputField: string;

  constructor(public dialogRef: MatDialogRef<InputDialog>) {

  }

  save() {
    this.dialogRef.close({ success: true, data: { inputField: this.inputField } });
  }

  cancel() {
    this.dialogRef.close({ success: false });
  }
}