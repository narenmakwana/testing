import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'status-dialog',
  template: `
      <div align="center" style="font-size:20px">{{ title }}</div>
        <div class="body">
            <pre> {{ data }} </pre>
          </div>
          <div *ngIf="loading" style="display: flex; justify-content: center; align-items: center;padding-bottom:10px">
          <mat-progress-spinner diameter="50" color='primary' mode="indeterminate"></mat-progress-spinner>
          </div>
      <div align="center">
         <button mat-raised-button color="primary" (click)="dialogRef.close()">DISMISS</button>
        </div>
  `,
  styles: []
})
export class StatusDialog {

  public title: string;
  public data: any;
  public loading: boolean;

  constructor(public dialogRef: MatDialogRef<StatusDialog>) {

  }
}