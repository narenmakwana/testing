import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'patch-dialog',
  template: `
    <mat-card style="box-shadow:none">
    <mat-card-title>{{ title }}</mat-card-title>
    <div fxLayout="row" fxLayoutAlign="center" style="margin-top:20px">
    {{ message }}
    </div>
    <mat-card-content>
      <div fxLayout="row" fxLayoutAlign="center" style="margin-top:20px">
      <mat-form-field style="width:65%;">
      <mat-select class="simplified" placeholder="WAS" [(ngModel)]="selectedWlpVersion" [ngModelOptions]="{standalone: true}">
        <mat-option *ngFor="let version of wlpVersions" [value]="version">{{version}}</mat-option>
      </mat-select>
    </mat-form-field>
    <mat-form-field *ngIf="ihsVersions.length > 0" style="width:75%;padding-left:20px">
    <mat-select placeholder="IHS" class="simplified" [(ngModel)]="selectedIhsVersion" [ngModelOptions]="{standalone: true}">
    <mat-option *ngFor="let version of ihsVersions" [value]="version">{{version}}</mat-option>
  </mat-select>
  </mat-form-field>
      </div>
    </mat-card-content>
    <mat-card-actions align="end">
      <button mat-raised-button color="primary" (click)="ok()">Ok</button>
      <button mat-raised-button (click)="cancel()">Cancel</button>
    </mat-card-actions>
  </mat-card>
  `,
  styles: []
})
export class PatchDialog {

  public title: string;
  public message: string;
  public placeHolderText: string;
  public wlpVersions: string[];
  public ihsVersions: string[];
  public selectedWlpVersion: string;
  public selectedIhsVersion: string;

  constructor(public dialogRef: MatDialogRef<PatchDialog>) {

  }

  ok() {
    this.dialogRef.close({ success: true, data: { selectedWlpVersion: this.selectedWlpVersion, selectedIhsVersion: this.selectedIhsVersion } });
  }

  cancel() {
    this.dialogRef.close({ success: false });
  }
}