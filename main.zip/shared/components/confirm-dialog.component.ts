import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'confirm-dialog',
  template: `
    <mat-card style="box-shadow:none">
      <mat-card-title>{{ title }}</mat-card-title>
      <mat-card-content>
      <p innerHtml="{{message}}"></p>
      </mat-card-content>
      <mat-card-actions align="end">
        <button mat-raised-button color="primary" (click)="dialogRef.close(true)">OK</button>
        <button mat-raised-button (click)="dialogRef.close()">Cancel</button>
      </mat-card-actions>
    </mat-card>
  `,
  styles: []
})
export class ConfirmDialog {

  public title: string;
  public message: string;

  constructor(public dialogRef: MatDialogRef<ConfirmDialog>) {

  }
}