import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'ok-dialog',
  template: `
    <mat-card style="box-shadow:none">
      <mat-card-title>{{ title }}</mat-card-title>
      <mat-card-content>
       <p innerHtml="{{message}}"></p>
       <p><a href="{{url}}" target="_blank">{{url}}</a></p>
      </mat-card-content>
      <mat-card-actions align="center">
         <button mat-raised-button color="primary" (click)="dialogRef.close()">OK</button>
      </mat-card-actions>
    </mat-card>
  `,
  styles: []
})
export class OkDialog {

  public title: string;
  public message: string;
  public url: string = "";

  constructor(public dialogRef: MatDialogRef<OkDialog>) {

  }
}