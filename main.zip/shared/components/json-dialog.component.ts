import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
    selector: 'json-dialog',
    template : `
    <mat-card>
      <mat-card-title>{{ title }}</mat-card-title>
      <mat-card-content>
        <div class="body">
          <div class="title <mat-display-1">Server Details</div>
            <pre> {{ jsondata }} </pre>
          </div>
      </mat-card-content>
      <mat-card-actions align="center">
         <button mat-raised-button color="primary" (click)="dialogRef.close()">Dismiss</button>
      </mat-card-actions>
    </mat-card>
  `,
  styles : []
})
export class JsonDialog {

    public title: string;
    public jsondata: any;

    constructor(public dialogRef: MatDialogRef<JsonDialog>) {

    }
}