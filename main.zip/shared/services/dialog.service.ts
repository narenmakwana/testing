import { Observable } from 'rxjs/Rx';
import { ConfirmDialog } from '../components/confirm-dialog.component';
import { OkDialog } from '../components/ok-dialog.component';
import { PatchDialog } from '../components/patch-dialog.component';
import { StatusDialog } from './../components/status-dialog.component';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { Injectable } from '@angular/core';

@Injectable()
export class DialogService {

    constructor(private dialog: MatDialog) { }

    public confirm(title: string, message: string): Observable<boolean> {

        let dialogRef: MatDialogRef<ConfirmDialog>;

        dialogRef = this.dialog.open(ConfirmDialog);
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = message;

        return dialogRef.afterClosed();
    }

    public ok(title: string, message: string, url?: string): Observable<boolean> {

        let dialogRef: MatDialogRef<OkDialog>;

        dialogRef = this.dialog.open(OkDialog);
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = message;
        if (url) {
            dialogRef.componentInstance.url = url;
        }

        return dialogRef.afterClosed();
    }

    public patch(title: string, message: string, wlpVersions: string[], ihsVersions : string[]): Observable<any> {
        let dialogRef: MatDialogRef<PatchDialog>;
        
        dialogRef = this.dialog.open(PatchDialog);
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = message;
        dialogRef.componentInstance.wlpVersions = wlpVersions;
        dialogRef.componentInstance.ihsVersions = ihsVersions;
        dialogRef.componentInstance.selectedWlpVersion = wlpVersions[0];
        dialogRef.componentInstance.selectedIhsVersion = ihsVersions[0];
        return dialogRef.afterClosed();
    }


    public status(title: string, data : any, loading : boolean): Observable<any> {

        let dialogRef: MatDialogRef<StatusDialog>;

        dialogRef = this.dialog.open(StatusDialog, {
            height: '500px',
            width: '750px',
            disableClose: true
          });
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.data = data;
        dialogRef.componentInstance.loading = loading;

        return dialogRef.afterClosed();
    }
}