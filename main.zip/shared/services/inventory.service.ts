import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Constants } from '../config/constants';


@Injectable()
export class InventoryService {

  constructor(private http: HttpClient) {
  }

  public getInventory(httpParams): Promise<any> {
    return this.http.get(Constants.getWasInventoryUrl(), { params: httpParams })
      .toPromise()
      .then(this.inventorySearchResults)
      .catch(this.handleError);
  }

  public getWasSummaryInventory(httpParams): Promise<any> {
    return this.http.get(Constants.getWasInvSummaryUrl(), { params: httpParams })
      .toPromise()
      .then(this.inventorySearchResults)
      .catch(this.handleError);
  }

  public getWlpInventory(httpParams): Promise<any> {
    return this.http.get(Constants.getWlpInventoryUrl(), { params: httpParams })
      .toPromise()
      .then(this.wlpSearchResults)
      .catch(this.handleError);
  }

  public getServersInventory(httpParams): Promise<any> {
    return this.http.get(Constants.getServersInventoryUrl(), { params: httpParams })
      .toPromise()
      .then(this.serversSearchResults)
      .catch(this.handleError);
  }


  inventorySearchResults(_response: Response): any {
    let body = _response;
    return body || {};
  }

  wlpSearchResults(_response: Response): any {
    let body = _response;
    return body || {};
  }

  serversSearchResults(_response: Response): any {
    let body = _response;
    return body || {};
  }

  // 	getJdkDetails(_response:  Response):  any  {
  //		let  body  =  _response;
  //		return  body  ||  {};
  //	}

  public getInventoryById(id: string): Promise<any> {
    return this.http.get(Constants.getWasInventoryUrl() + "/" + id)
      .toPromise()
      .then(this.inventorySearchResults)
      .catch(this.handleError);
  }


  public getLibertyInvCellByName(cellname: string): Promise<any> {
    let httpParams = new HttpParams().set('cellName', cellname);
    return this.http.get(Constants.getWlpInventoryUrl(), { params: httpParams })
      .toPromise()
      .then(this.wlpSearchResults)
      .catch(this.handleError);
  }


  public getInventoryHistory(params: string[], limit: number, offset: number, trim: string): Promise<any> {
    var _params = {
    };

    // Make copy of params in browser safe manner
    if (params) {
      _params = JSON.parse(JSON.stringify(params));
    }
    if (limit) {
      //_params.limit = limit;
    }
    if (offset) {
      //_params.offset = offset;
    }
    if (trim) {
      //	_params.fields = INVENTORY_TRIM
    }
    return this.http.get(Constants.getWasInventoryHistoryUrl())
      .toPromise()
      .then(this.inventorySearchResults)
      .catch(this.handleError);
  }

  public getInventoryHistoryById(id: string): Promise<any> {
    return this.http.get(Constants.getWasInventoryHistoryUrl() + "/" + id)
      .toPromise()
      .then(this.inventorySearchResults)
      .catch(this.handleError);
  }

  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  }
}
