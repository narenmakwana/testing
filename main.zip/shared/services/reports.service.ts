import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Constants } from '../config/constants';


@Injectable()
export class ReportService {

	constructor(private http: HttpClient) {
	}

	public getSDKDataold = function () {
		var self = this;
		var resultGeneration = function (dcioMap, resolve) {
			//Get PVU data for hosts
			var ndPvuVals = [], basePvuVals = [], portalPvuVals = [], labels = [],
				_ndPvuVals = [], _basePvuVals = [], _portalPvuVals = [], _labels = [],
				seriesLabels = ['Base', 'Portal', 'ND'];
			Object.keys(dcioMap).map(function (dcio) {
				if (!dcioMap[dcio].installTypes) {
					return;
				}
				ndPvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.ND.value] || 0);
				_ndPvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.ND.value] || 0);
				basePvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.BASE.value] || 0);
				_basePvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.BASE.value] || 0);
				portalPvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.PORTAL.value] || 0);
				_portalPvuVals.push(dcioMap[dcio].installTypes[self.INSTALL_TYPES.PORTAL.value] || 0);
				labels.push(dcio);
				_labels.push(dcio);
			});
			//Add row labels to the front of data arrays for csv output generation
			_ndPvuVals.unshift(seriesLabels[2]);
			_portalPvuVals.unshift(seriesLabels[1]);
			_basePvuVals.unshift(seriesLabels[0]);
			_labels.unshift('');
			resolve({
				data: [basePvuVals, portalPvuVals, ndPvuVals],
				dataLabels: labels,
				seriesLabels: seriesLabels,
				colors: self.barColors,
				sum: dcioMap.total,
				csv: self._toCsv([_labels].concat([_basePvuVals, _portalPvuVals, _ndPvuVals]))
			});
		};

		return this.getJDKData(resultGeneration);

	};


	public getfootPrint(): Promise<any> {
		return this.http.get(Constants.getReportUrl() + "/footprint")
			.toPromise()
			.then(this.getResults)
			.catch(this.handleError);
	}


	public getSDKData(): Promise<any> {
		return this.http.get(Constants.getReportUrl() + "/sdk")
			.toPromise()
			.then(this.getJdkDetails)
			.catch(this.handleError);
	}

	getJdkDetails(_response: Response): any {
		let body = _response;
		return body || {};
	}

	getResults(_response: Response): any {
		let body = _response;
		return body || {};
	}


	//Get report from back end
	_getReport = function (type, mapDataFn) {
		return new Promise((resolve, reject) => {
			var processResponse = function (response) {
				var results = response.data;
				if (typeof mapDataFn === 'function') {
					mapDataFn(results).then(function (data) {
						resolve(data);
					});
				}
				else {
					resolve(results);
				}
			};
			if (this.cachedReports[type]) {
				processResponse(this.cachedReports[type]);
			}
			else {
				this.http.get(Constants.getReportUrl() + "/" + type)
					.toPromise()
					.then((response) => {
						this.cachedReports[type] = response;
						console.log("Response" + response);
						processResponse(response);
					})
					.catch(this.handleError);
			}
		});
	};


	private handleError(error: Response | any) {
		// In a real world app, we might use a remote logging infrastructure
		let errMsg: string;
		if (error instanceof Response) {
			const body = error.json() || '';
			const err = JSON.stringify(body);
			errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
		} else {
			errMsg = error.message ? error.message : error.toString();
		}
		console.error(errMsg);
		return Promise.reject(errMsg);
	}
}
