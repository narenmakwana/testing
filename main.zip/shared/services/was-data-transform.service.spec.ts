/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { WasDataTransformService } from './was-data-transform.service';

describe('WasDataTransformService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WasDataTransformService]
    });
  });

  it('should ...', inject([WasDataTransformService], (service: WasDataTransformService) => {
    expect(service).toBeTruthy();
  }));
});
