import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Constants} from '../config/constants';

export class Params {
   limit: number;
   offset: number;
}

@Injectable()
export class DeployService {

  constructor(private http: HttpClient ) {
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

	//Move cell to the next workflow state
	updateWasState (docId, type, state){
		  return this.http.post(Constants.getDeployWasCellUrl() + "/" + docId + "/state", {"workflow" : type, "state": state}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

	setWlpErrorStatus (docId, state, err){
		  return this.http.post(Constants.getDeployWasCellUrl() + "/" + docId + "/status", {"status": state, "progress":  0, "error": err}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

	updateWlpState (docId, type, state){
		  return this.http.post(Constants.getDeployLibertyCellUrl() + "/" + docId + "/state", {"workflow" : type, "state": state}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

	setWasErrorStatus (docId, state, err){
		  return this.http.post(Constants.getDeployLibertyCellUrl() + "/" + docId + "/status", {"status": state, "progress":  0, "error": err}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

  updateLinuxState (docId, type, state){
		  return this.http.post(Constants.getDeployLinuxUrl() + "/" + docId + "/state", {"workflow" : type, "state": state}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

	setLinuxErrorStatus (docId, state, err){
		  return this.http.post(Constants.getDeployLinuxUrl() + "/" + docId + "/status", {"status": state, "progress":  0, "error": err}) 
                    .toPromise()
                    .then(this.updateStateSuccess)
                    .catch(this.handleError);
	}

	updateStateSuccess (_response: Response) : any {
    if (_response)
        return _response;
     else
        return { };
  }

}
