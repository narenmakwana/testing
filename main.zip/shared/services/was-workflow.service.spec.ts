/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { WasWorkflowService } from './was-workflow.service';

describe('WasWorkflowService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WasWorkflowService]
    });
  });

  it('should ...', inject([WasWorkflowService], (service: WasWorkflowService) => {
    expect(service).toBeTruthy();
  }));
});
