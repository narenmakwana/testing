import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {ServerConfig} from '../models/server-config';
import {Constants} from '../config/constants';

@Injectable()
export class LinuxWorkflowService {

  workflow = {};
  workflowProgress = {};
  
  constructor(private http: HttpClient) {
  }

  public deployProject( body: ServerConfig) : Promise<any> {
    body['deploymentType'] = 'build';
      if(body._id)
         delete body._id;
      return this.http.post(Constants.getDeployLinuxUrl(), body) 
                    .toPromise()
                    .then(this.deployResult)
                    .catch(this.handleError);
  }

  deployResult (_response: Response) : any {
  }

  public discoverWorkflow() : Promise<any> {
      if( this.workflow && (this.workflow === Array)) {
         return;
      }
      else {
          return this.http.get(Constants.getDiscoverLinuxWorkflowUrl()) 
                        .toPromise()
                        .then(this.workflowResults.bind(this))
                        .catch(this.handleError);
      }
  }
 
 workflowResults (_response: Response) : any {
     var body = _response;
     this.workflow = body;
     Object.keys(body).forEach(type=>{
						this.workflowProgress[type] = {};
						this.workflow[type].forEach((state, idx)=>{
							this.workflowProgress[type][state.id] = (idx / (this.workflow[type].length-1))*100;
						});
					});
     return body || { };
  }

 private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

  getWorkflowStates (type)      {
    if(this.workflow[type]){
      return this.workflow[type].map(function(state){
        return {value: state.id, label: state.label};
      });
    }
    return [];
  };
	
  getNextAction (type, status){
			var action = null;
			if(status.error){
				action = status.state;
			}
			else if(status.complete && this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach((stage, idx)=>{
					if(stage.id === status.state && ((idx + 1) < this.workflow[type].length)){
						action = this.workflow[type][idx+1].id;
					}
				});
			}
      return action;
	};

	getMaxStateDuration (type, state){
			var duration = null;
			if(this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach((stage)=>{
					if(stage.id === state){
						duration = stage.max;
					}
				});
			}
			return duration;
	};
	
  getStateLabel(type, state){
			var label = null;
			if(this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach((stage)=>{
					if(stage.id === state){
						label = stage.label;
					}
				});
			}
			return label;
	};

  getStateStatus(type, state){
			var status = null;
			if(this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach((stage)=>{
					if(stage.id === state){
						status = stage;
					}
				});
			}
			return status;
	};

	getStateProgress (type, state){
			return Math.round(this.workflowProgress[type][state]) || 0;
	}
  
}
