import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Constants } from './../config/constants';
import { SocketEvent } from './../models/socket-event';

import * as socketIo from 'socket.io-client';

const SERVER_URL = Constants.getOpsServiceUrl();

@Injectable()
export class SocketService {
    private socket;

    // Initialize socket.io instance using only Websockets as the transport with no reconnection attempts and including JWT Token
    public initSocket(token: any): void {
        this.socket = socketIo(SERVER_URL, { transports: ['websocket'], upgrade: false, reconnection: false, query: { token: token } });
    }

    // Disconnect this socket instance
    public closeSocket(): void {
        if (this.socket) {
            this.socket.disconnect();
        }
    }

    // Check if socket is connected
    public isConnected() : Boolean {
        return this.socket.connected ? true : false;
    }

    // Emit an event to the udi-ops socket.io server
    public send(event: SocketEvent, data: any): void {
        this.socket.emit(event, data);
    }

    // Listen for events for this socket.io instance
    public onEvent(event: SocketEvent): Observable<any> {
        return new Observable<Event>(observer => {
            this.socket.on(event, (data?: any) => observer.next(data));
        });
    }
}