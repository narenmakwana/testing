import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Constants} from '../config/constants';
import {ResponseResult} from '../models/response-result';
import { UditUtils } from '../../../core/uditUtils';

export class Packages {
    _id: string;
    install_id: string;
    install_type: string;
    location: string;
    name: string;
    version: string;
    releaseDate: string;
    fixpacks: string[];
}


@Injectable()
export class PackagesService {

  constructor(private http: HttpClient ) {
  }

  public getPackagesResult (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  public getPackages( params : any) : Promise<any> {
      var httpParams = UditUtils.buildHttpParams(params);
      return this.http.get(Constants.getWasPackagesUrl(), {params: httpParams}) 
                    .toPromise()
                    .then(this.getPackagesResult)
                    .catch(this.handleError);
  }

  public getWlpPackages( params : any) : Promise<any> {
    if(params){
      var httpParams = UditUtils.buildHttpParams(params);
      return this.http.get(Constants.getWlpPackagesUrl(), {params: httpParams})
                    .toPromise()
                    .then(this.getPackagesResult)
                    .catch(this.handleError);      
    }
    else
      return this.http.get(Constants.getWlpPackagesUrl())
                    .toPromise()
                    .then(this.getPackagesResult)
                    .catch(this.handleError);
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

}
