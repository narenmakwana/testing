import {Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Dcio} from '../models/dcio';
import {TciCodes} from '../models/tci-codes';
import {TciCodesResult} from '../models/tci-codes-result';
import {Constants} from '../config/constants';


@Injectable()
export class OrgService {

  constructor(private http: HttpClient ) {
  }

  getHeaders(): Headers {
    return new Headers(); 
  }
 
  public getTciCodes() : Promise<any> {
      return this.http.get(Constants.getDcioUrl()) 
                    .toPromise()
                    .then(this.tciCodeSearchResults)
                    .catch(this.handleError);
  }

  tciCodeSearchResults (_response: Response) : any {
     let body = _response;
     return body || { };
  }

  mapTciCodesToDcio = function(){
    return new Promise(function(resolve, reject){
      this.getTciCodes().then(function(response){
        var map = {};
        response.forEach(function(dcio){
          dcio.applications.forEach(function(apps){
            map[apps.tciCode] = dcio.dcio;
          });
        });
        resolve(map);
      }, function() {
        reject();
      });
    });
  };
		
  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

}