import { Injectable } from '@angular/core';
import { Constants } from '../config/constants';
import { DataFormatService } from './data-format.service';
import { WasCell } from '../models/was-cell';
import { WasNodeTemplate } from '../models/was-node-template';
import { WasJvmTemplate } from '../models/was-jvm-template';
import { WasIhsTemplate } from '../models/was-ihs-template';

@Injectable()
export class CellParseService {

	NODE_TYPES = Constants.NODE_TYPES;
	INSTALL_TYPES = Constants.INSTALL_TYPES;


	constructor(private dataFormatService: DataFormatService) {
	}

	convertFromInventoryToDesignFormat = function (data): WasCell {

		return this.fromInventoryFormat(data);
	}


	fromInventoryFormat = function (data): WasCell {
		var self = this;
		var destCell = new WasCell();
		destCell.cellname = data.cellId;
		destCell.tciCode = this.getTciCode(data.cellId);
		destCell.envTypeCode = this.getEnvType(data.cellId);
		destCell.installType = this.getCellInstallType(data);
		destCell.envNumber = this.getEnvNumber(data.cellId);

		var versions = this.getWasVersions(data);
		var verFound = versions.length ? versions[0].version : 'None';

		destCell.selectedWasVersion = verFound;
		destCell.wasVersionCode = destCell.selectedWasVersion.replace('.', '').slice(0, 2);

		if (destCell.nodeTemplates.length > 0) {
			// we need to start with zero nodes and keep adding them as we need it.
			destCell.removeNode(0);  // Remove the node.
		}

		var nodes = [];

		var hosts = {};
		//Consolidate inventory nodes into nodes by host name
		data.nodes.forEach((invNode) => {
			var nodeType = this.getNodeType(invNode);
			var hostName = this.getUniqueHosts([invNode])[0] || null;
			if (hostName !== 'pluginNode') {
				// We want to skip all the pluginNodes since they are not supported in cloning.
				if (!hosts[hostName]) {
					hosts[hostName] = {
						dmgr: null,
						jvms: [],
						http: []
					}
				}
				if (nodeType === Constants.NODE_TYPES.DMGR.value) {
					hosts[hostName].dmgr = this.dataFormatService.getDmgrObj(destCell.installType);
					hosts[hostName].dmgr.name = invNode.nodeName;
					hosts[hostName].dmgr.portBlock = this.getDmgrPortBlock(invNode);
				}
				else if (nodeType === Constants.NODE_TYPES.HTTP.value) {
					invNode.serverIndex.serverEntries.forEach((http) => {
						var newHttp = this.dataFormatService.getHttpObj(hosts[hostName].http.length, 'ihs', destCell.envTypeCode);
						newHttp.name = http.serverName;

						var portInfo = this.getPortBlock(data, http.serverName);
						newHttp.portBlock = portInfo.portBlock;

						hosts[hostName].http.push(newHttp);
					});
					hosts[hostName].nodeName = invNode.nodeName;
				}
				else if (nodeType === Constants.NODE_TYPES.NODE.value) {
					invNode.serverIndex.serverEntries.forEach((server) => {
						if (server.serverType === Constants.NODE_TYPES.APP_SERVER.value) {
							var clusterName, newJvm = this.dataFormatService.getJvmObj(hosts[hostName].jvms.length, destCell.installType);
							newJvm.name = server.serverName;

							var jvmEntries = this.getJvmEntries(data, server.serverName);
							if (jvmEntries) {
								newJvm.minHeap = jvmEntries.jvmEntry.initialHeapSize;
								newJvm.maxHeap = jvmEntries.jvmEntry.maximumHeapSize;
							}

							var portInfo = this.getPortBlock(data, server.serverName);
							newJvm.portBlock = portInfo.portBlock;

							//Find Cluster For JVM
							if (data.serverCluster) {
								data.serverCluster.forEach((cluster) => {
									if (cluster.members)
										cluster.members.forEach((member) => {
											if (member.memberName === server.serverName) {
												clusterName = cluster.name;
											}
										});
								});
							}
							if (!clusterName) {
								clusterName = 'none';
							}
							var foundCluster;
							destCell.clusterNames.forEach((cluster) => {
								if (cluster === clusterName) {
									foundCluster = true;
									destCell.hasClusters = true;
								}
							});
							if (!foundCluster) {
								destCell.clusterNames.push(clusterName);
							}
							newJvm.clusterName = clusterName;
							hosts[hostName].jvms.push(newJvm);
						}
					});
					hosts[hostName].nodeName = invNode.nodeName;
				}
			}
		});


		var hostKeys = Object.keys(hosts);
		hostKeys.forEach((key, idx) => {
			var nodeTemplate = new WasNodeTemplate();
			var value = hosts[key];
			var node = this.dataFormatService.getNodeObj(idx, destCell.installType);
			node.hostName = key;
			nodeTemplate.hostName = key;
			nodeTemplate.nodeName = value.nodeName;

			if (value.dmgr) {
				node.dmgr = value.dmgr
				nodeTemplate.hasDmgr = true;
				destCell.dmgrName = value.dmgr.name;
				destCell.dmgrMinHeap = value.dmgr.minHeap;
				destCell.dmgrMaxHeap = value.dmgr.maxHeap;
				destCell.dmgrPort = value.dmgr.portBlock;
				destCell.dmgrNode = key;
			}
			node.jvmMembers = value.jvms;
			node.jvmMembers.forEach(node => {
				var jvmTemplate = new WasJvmTemplate();
				jvmTemplate.jvmName = node.name;
				jvmTemplate.portBlock = node.portBlock;
				jvmTemplate.clusterName = node.clusterName;
				jvmTemplate.minHeap = node.minHeap;
				jvmTemplate.maxHeap = node.maxHeap;
				nodeTemplate.jvmTemplates.push(jvmTemplate);
				nodeTemplate.numJvms++; // Increment the number of JVMs.
			});
			node.httpMembers = value.http;
			node.httpMembers.forEach(http => {
				var ihsTemplate = new WasIhsTemplate();
				ihsTemplate.ihsName = http.name;
				ihsTemplate.portBlock = http.portBlock;
				nodeTemplate.ihsTemplates.push(ihsTemplate);
				nodeTemplate.numHttpServers++;  // Increment the number of http Servers
			});

			nodes.push(node);
			destCell.nodeTemplates.push(nodeTemplate);
			destCell.numNodes++;  // Increment the number of nodes
		});
		destCell.numNodes = nodes.length;
		if (nodes[0].dmgr) {
			destCell.dmgrName = nodes[0].dmgr.name;
			destCell.dmgrMinHeap = nodes[0].dmgr.minHeap;
			destCell.dmgrMaxHeap = nodes[0].dmgr.maxHeap;
			destCell.dmgrPort = (nodes[0].dmgr.portBlock.portBlock) ? nodes[0].dmgr.portBlock.portBlock : '201';
		}
		return destCell;
	}

	getJvmEntries(cell: any, serverName: string): any {
		var i, j;
		if (!cell) {
			return { jvmEntry: null };
		}
		for (i = 0; i < cell.nodes.length; i++) {
			var node = cell.nodes[i];
			for (j = 0; j < node.servers.length; j++) {
				var server = node.servers[j];
				if (server.name === serverName) {
					return { jvmEntry: server.processDefinitions[0].jvmEntries };
				}
			}
		}
		return { jvmEntry: null };
	};

	getPortBlock(cell: any, serverName: string): any {
		var i, j;
		if (!cell) {
			return { portBlock: null };
		}
		for (i = 0; i < cell.nodes.length; i++) {
			var node = cell.nodes[i];
			for (j = 0; j < node.serverIndex.serverEntries.length; j++) {
				var serverEntry = node.serverIndex.serverEntries[j];
				if (serverEntry.serverName === serverName) {
					return { portBlock: serverEntry.specialEndpoints[0].endPoint.port.substring(0, 3) };
				}
			}
		}
		return { portBlock: null };
	};

	getDmgrPortBlock(invNode: any): any {
		var i, j;
		if (!invNode.serverIndex.serverEntries) {
			return { portBlock: null };
		}
		for (i = 0; i < invNode.serverIndex.serverEntries.length; i++) {
			var serverEntry = invNode.serverIndex.serverEntries[i];
			return { portBlock: serverEntry.specialEndpoints[0].endPoint.port.substring(0, 3) };

		}
		return { portBlock: null };
	};

	_findDmgr(cell: any): any {
		var i, j;
		if (!cell) {
			return { server: null, node: null };
		}
		for (i = 0; i < cell.nodes.length; i++) {
			var node = cell.nodes[i];
			for (j = 0; j < node.serverIndex.serverEntries.length; j++) {
				var server = node.serverIndex.serverEntries[j];
				if (server.serverType === Constants.NODE_TYPES.DMGR.value) {
					return { server: server, node: node };
				}
				else
					if (server.serverType === Constants.NODE_TYPES.APP_SERVER.value) {
						if (server.serverName === 'server1')
							return { server: server, node: node };
					}
			}
		}
		return { server: null, node: null };
	};


	public getDmgrLink(cell: any): string {
		var k;
		var result = this._findDmgr(cell);
		if (!result.node || !result.server) {
			return '';
		}
		for (k = 0; k < result.server.specialEndpoints.length; k++) {
			if (result.server.specialEndpoints[k].endPointName === Constants.ENDPOINTS.ADMIN) {
				return Constants.DMGR_LINK.replace('%host%', result.node.hostName).replace('%port%', result.server.specialEndpoints[k].endPoint.port);
			}
		}
		return '';
	}

	public getDmgrHostName(cell: any): string {
		var result = this._findDmgr(cell);
		return result.node ? result.node.host : '';
	};

	public getCellComponentsForServiceNow(cell: any): any {
		var returns = [];
		//Traverse cell data
		cell.nodes.forEach(function (node) {
			node.serverIndex.serverEntries.forEach(function (server) {
				var entry = {
					host: node.host,
					name: server.serverName,
					nodeName: node.nodeName
				};
				returns.push(entry);
			});
		});
		return returns;
	};

	public getCellComponentsForDiff(cell: any, normalizeNames: any): any {
		var returns = {
			'packages': [],
			globalSecurity: {}
		};
		Object.keys(this.NODE_TYPES).forEach(function (key) {
			returns[this.NODE_TYPES[key].value] = [];
		});
		//Traverse cell data
		cell.nodes.forEach(function (node) {
			var type = this._cellParseService.getNodeType(node), names = {};
			if (type) {
				//Gather all member names for node
				node.serverIndex.serverEntries.forEach(function (server) {
					names[server.serverName] = true;
				});
				Object.keys(names).forEach(function (name) {
					var component = this.getCellComponentByName(cell, name, normalizeNames);
					returns[type].push(component);
				});
				//Get package data from DMGR node
				if (type === this.NODE_TYPES.DMGR.value) {
					returns.packages = node.installedPackages;
				}
			}
		});
		if (cell.globalSecurity) {
			returns.globalSecurity = cell.globalSecurity;
		}
		//If no DMGR to get package info from
		if (!returns.packages.length && cell.nodes.length && cell.nodes[0].serverIndex.serverEntries.length) {
			returns.packages.push(cell.nodes[0].serverIndex.serverEntries[0].installedPackages);
		}

		//Generate Friendly Display Names For Components
		var _returns = {};
		Object.keys(returns).forEach(function (key) {
			var newKey;
			Object.keys(this.NODE_TYPES).forEach(function (_key) {
				if (this.NODE_TYPES[_key].value === key) {
					newKey = this.NODE_TYPES[_key].diffLabel;
				}
			});
			if (newKey) {
				_returns[newKey] = returns[key];
			}
			else {
				_returns[key] = returns[key];
			}
		});
		return _returns;
	};



    /** 
		 * Gathers component information - gathering data from serverIndex & servers
		 * arrays in the inventory JSON.
		 *
		 * If normalizeName is true, the any instnace of the component name in the 
		 * JSON is set to a constant token value.
		 */
	public getCellComponentByName(cell: any, name: any, normalizeName: string): any {
		var i, j, nameToken = '##componentName##',
			result = {
				server: null,
				serverIndex: null,
				name: name
			};
		if (!cell || !name) {
			return null;
		}
		for (i = 0; i < cell.nodes.length; i++) {
			var node = cell.nodes[i];
			//Search server index
			for (j = 0; j < node.serverIndex.serverEntries.length; j++) {
				var server = node.serverIndex.serverEntries[j];
				if (server.serverName === name) {
					result.serverIndex = server;
					break;
				}
			}
			//Search servers
			for (j = 0; j < node.servers.length; j++) {
				server = node.servers[j];
				if (server.name === name) {
					result.server = server;
					break;
				}
			}
		}
		if (normalizeName) {
			result.server = JSON.parse(JSON.stringify(result.server).replace(new RegExp(name, "g"), nameToken));
			result.serverIndex = JSON.parse(JSON.stringify(result.serverIndex).replace(new RegExp(name, "g"), nameToken));
		}
		return result;
	};

	//Packages on app server nodes to ignore
	_isWasPackage(packageId, version) {
		var wasVersionRegex = new RegExp(/^\d{1}[.]?\d{1}[.]?\d{1}[.]?\d{1,2}\b/);
		var iswaspkg = false;
		if (packageId.indexOf('BASE') > -1)
			iswaspkg = true;
		else
			if (packageId.indexOf('ND') > -1)
				iswaspkg = true;
		return (wasVersionRegex.test(version) && iswaspkg);
	};

	_isJavaPackage(packageId) {
		return packageId.toUpperCase().indexOf('JAVA') > -1;
	};

	_isWasFP(packageId) {
		var wasFPRegex = new RegExp(/^\d{1}[.]?\d{1}[.]?\d{1}[.]?\d{1,2}-WS-WAS-IFP\w*\b/);
		return wasFPRegex.test(packageId)
	};
	_isWasND(packageId) {
		return packageId.toUpperCase().indexOf('COM.IBM.WEBSPHERE.ND') > -1;
	};

	_isWasBase(packageId) {
		return packageId.toUpperCase().indexOf('COM.IBM.WEBSPHERE.BASE') > -1;
	};

	getJavaSDKVersions(cell) {
		return this._getVersions(cell, this._isJavaPackage);
	};

	getWasFixPackVersions(cell) {
		return this._getVersions(cell, this._isWasFP);
	};

	getWasVersions(cell) {
		return this._getVersions(cell, this._isWasPackage);
	};

	getWasVersion(name) {
		return name.split('-')[1].slice(4) || '85';  //default to 85
	}

	_findWasNode(cell: any, type: any, comparator: any): any {
		var versions = [];
		cell.nodes.forEach(function (node) {
			var isWasNode = false;
			//Find DMGR Node
			node.serverIndex.serverEntries.forEach(function (server) {
				if (server.serverType === type) {
					isWasNode = true;
				}
			});
			//Analyze packages for this node
			if (isWasNode && Array.isArray(node.installedPackages)) {
				node.installedPackages.forEach(function (installed) {
					installed.packages.forEach(function (p) {
						if (comparator(p.id, p.version)) {
							versions.push({ version: p.version, id: p.id });
						}
					});
				});
			}
		});
		return versions;
	}

	//Get latest WAS version
	_getVersions(cell, comparator) {
		var _versions = this._findWasNode(cell, this.NODE_TYPES.DMGR.value, comparator);
		//No DMGR, try for standalone app server
		if (_versions.length === 0) {
			_versions = this._findWasNode(cell, this.NODE_TYPES.APP_SERVER.value, comparator);
		}
		return _versions;
	};

	//Returns -1 if was1 is older than was2, 1 if newer, 0 if same
	compareWasVersions(was1, was2) {
		if (was1 === was2) {
			return 0;
		}
		var wasTokens1 = was1.split('.'),
			wasTokens2 = was2.split('.'),
			length = (wasTokens1.length < wasTokens2) ? wasTokens1.length : wasTokens2.length,
			i;
		for (i = 0; i < length; i++) {
			if (+wasTokens1[i] > +wasTokens2[i]) {
				return 1;
			}
			else if (+wasTokens1[i] < +wasTokens2[i]) {
				return -1;
			}
			else {
				continue;
			}
		}
		return 1;
	};

	getMajorWasVersion(version) {
		return version.split('.').slice(0, -1).join('.');
	};

	//Get all hosts for a cell regardless of what is on them(JVM, HTTP...etc)
	getUniqueHosts(nodes) {
		var hosts = {};
		nodes.forEach(function (node) {
			hosts[node.host] = true;
		});
		return Object.keys(hosts);
	};
	//Get hosts for a cell that have JVMs on them
	getJvmHosts(nodes) {
		var hosts = {};
		nodes.forEach(function (node) {
			var isAppHost = false;
			node.serverIndex.serverEntries.forEach(function (server) {
				if (server.serverType === this.NODE_TYPES.APP_SERVER.value || server.serverType === this.NODE_TYPES.DMGR.value) {
					isAppHost = true;
				}
			});
			if (isAppHost) {
				hosts[node.host] = true;
			}
		});
		return Object.keys(hosts);
	};

	getNodeType(node) {
		var type = null, NODE_TYPES = Constants.NODE_TYPES;
		node.serverIndex.serverEntries.forEach((server) => {
			if (!server || !server.serverType) {
				return;
			}
			if (server.serverType === Constants.NODE_TYPES.NODE.value || server.serverType === Constants.NODE_TYPES.APP_SERVER.value) {
				type = NODE_TYPES.NODE.value
			}
			else if (server.serverType === Constants.NODE_TYPES.HTTP.value || server.serverType === this.NODE_TYPES.DMGR.value) {
				type = server.serverType;
			}
		});
		return type;
	};

	getCellInstallType(cell) {
		var self = this;
		var installType = '', INSTALL_TYPES = this.INSTALL_TYPES;
		[{ func: this._isWasND, type: INSTALL_TYPES.ND.value }, { func: this._isWasBase, type: INSTALL_TYPES.BASE.value }].forEach(function (obj) {
			var versions = self._getVersions(cell, obj.func);
			if (versions.length > 0) {
				installType = obj.type;
			}
		})
		return installType;
	};

	getField(cell, key): any {
		this.processCell(cell, key, function (results) {
			return results;
		});
		return null;
	}

	processCell(cell, key, callback) {
		var targetField = key;
		var valuesArr = [];
		JSON.parse(JSON.stringify(cell), function (key, value) {
			if (key === targetField) {
				valuesArr.push(value);
			}
		});
		callback(valuesArr);
	};

	getTciCode = function (name) {
		if (typeof name === 'string') {
			return name.split('-')[0] || null;
		}
		return null;
	};

	getEnvType = function (name) {
		return name.split('-')[2].slice(0, 2) || null;
	};

	getEnvNumber = function (name) {
		return name.split('-')[2].slice(2) || null;
	};

	isProd = function (type) {
		return type === 'pd';
	};

	isde = function (type) {
		return type === 'pb';
	};
}
