import { Injectable } from '@angular/core';
import { WasNodeTemplate } from '../models/was-node-template';
import { WasJvmTemplate } from '../models/was-jvm-template';
import { WasIhsTemplate } from '../models/was-ihs-template';
import { WasCell } from '../models/was-cell';
import { Constants } from '../config/constants';
import { CellParseService } from './cell-parse.service';
import { DataFormatService } from './data-format.service';

const nas_path = Constants.getNasPath();
const was_install_root = Constants.getWasInstallRootPath();

export class LogRotate {

  confLocation: string = was_install_root + "/allstate/conf/logrotate.conf";
  cronLocation: string = "/etc/cron.daily/logrotate";
  options: string[] = [
    "daily",
    "rotate 14",
    "compress",
    "missingok",
    "notifempty",
    "copytruncate",
    "dateext"
  ];
  logs: LogTask[] = [];

  constructor() { }

  createLogTasks(node: WasNodeTemplate, data: any) {
    var self = this;
    var logTask = new LogTask();
    // For each node, we want to create the Log Tasks
    node.jvmTemplates.forEach(function (jvmTemplate) {
      logTask.host = node.hostName;
      logTask.logName.push(
        was_install_root + "/" + data.cellname + "/config/servers/" + jvmTemplate.jvmName + "/logs/messages.log",
        was_install_root + "/" + data.cellname + "/config/servers/" + jvmTemplate.jvmName + "/logs/console.log");
    });

    node.ihsTemplates.forEach(function (ihsTemplate) {
      logTask.host = node.hostName;
      logTask.logName.push(
        was_install_root + "/" + ihsTemplate.ihsName + "/HTTPServer/logs/access_log",
        was_install_root + "/" + ihsTemplate.ihsName + "/HTTPServer/logs/error_log",
        was_install_root + "/" + ihsTemplate.ihsName + "/Plugins/logs/" + ihsTemplate.ihsName + "/http_plugin.log");
    });

    self.logs.push(logTask);
  }
}

export class LogTask {
  host: string = "";
  logName: string[] = [];

  constructor() { }

}

export class InstallationManager {

  hostName: string = "";
  task: string = "imInstall";

  constructor() { }
}

export class PatchesTask {

  task: string = "";
  templateVer: string = "";
  useVer: string = "";
  hosts: string[] = [];

  constructor() {
  }

}

export class WasInstallTask {

  task: string = "";
  templateVer: string = "";
  pkgName: string = "";

  constructor() {
  }

}

export class GenerateIHSTasks {

  task: string = "";
  nodeName: string = "";
  ihsName: string = "";

  constructor() {
  }

}


export class MapGroupTask {

  task: string = "MapGroupToRole";
  roleName: string = "";
  accessids: string = "";
  groupids: string = "";

}

export class FederatedRepository {
  task: string = "ConfigFederatedRepository";
  realmName: string = "";
  primaryAdminId: string = "";
  registryType: string = "WIMUserRegistry";
  adminUser: string = "";
  id: string = "";
  host: string = "";
  primary_host: string = "";
  port: string = "3269";
  bindDN: string = "";
  bindPassword: string = "";
  DCname: string = "";
  DCnameInRepository: string = "";
  secmgraccid: string = "";
  secmgrgrpid: string = "";
  ContextPoolenabled: string = "true";
  ContextPoolinitPoolSize: string = "25";
  ContextPoolmaxPoolSize: string = "200";
  ContextPoolprefPoolSize: string = "50";
  ContextPoolpoolTimeOut: string = "0";
  ContextPoolpoolWaitTime: string = "3000";
  AttrCacheenabled: string = "true";
  AttrCachecacheSize: string = "4000";
  AttrCachecacheDistPolicy: string = "none";
  AttrCachecacheTimeOut: string = "2000";
  AttrCachecachesDiskOffLoad: string = "false";
  SearchResultCacheenabled: string = "true";
  SearchResultCachecacheSize: string = "2000";
  SearchResultCachecacheDistPolicy: string = "none";
  SearchResultCachecacheTimeOut: "600";
  SearchResultCachecachesDiskOffLoad: string = "false"

  constructor(cellname: string, ldapId: string, bindId: string, ldapType: string) {
    this.realmName = cellname;
    if (ldapType === Constants.DEF_LDAP_TYPE) {
      // Test Ldap
      this.primaryAdminId = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=test,dc=allstate,dc=com";
      this.adminUser = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=test,dc=allstate,dc=com";
      this.id = "TEST";
      this.primary_host = "test-gc.tptigslb.allstate.com";
      this.host = "test-gc.tptigslb.allstate.com";
      this.bindDN = "cn=" + bindId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=test,dc=allstate,dc=com";
      this.bindPassword = "Allstate1";
      this.DCname = "dc=test,dc=allstate,dc=com";
      this.DCnameInRepository = "dc=test,dc=allstate,dc=com";
      this.secmgraccid = "group:" + cellname + "/cn=was_dmgradmins,ou=ServiceAccounts,ou=Common,ou=Corp,dc=test,dc=allstate,dc=com";
      this.secmgrgrpid = "was_dmgradmins@" + cellname;
    }
    else if (ldapType === Constants.ETEST_LDAP_TYPE) {
      // Etest Ldap
      this.primaryAdminId = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=etest,dc=allstate,dc=com";
      this.adminUser = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=etest,dc=allstate,dc=com";
      this.id = "ETEST";
      this.primary_host = "etest-gc.tptigslb.allstate.com";
      this.host = "etest-gc.tptigslb.allstate.com";
      this.bindDN = "cn=" + bindId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=etest,dc=allstate,dc=com";
      this.bindPassword = "Allstate1";
      this.DCname = "dc=test,dc=allstate,dc=com";
      this.DCnameInRepository = "dc=etest,dc=allstate,dc=com";
      this.secmgraccid = "group:" + cellname + "/cn=was_dmgradmins,ou=ServiceAccounts,ou=Common,ou=Corp,dc=etest,dc=allstate,dc=com";
      this.secmgrgrpid = "was_dmgradmins@" + cellname;
    }
    else {
      // Prod Ldap
      this.primaryAdminId = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
      this.adminUser = "cn=" + ldapId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
      this.id = "AD";
      this.primary_host = "gldc-ad-gc-vip.igslb.allstate.com";
      this.host = "gldc-ad-gc-vip.igslb.allstate.com";
      this.bindDN = "cn=" + bindId + ",ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
      this.bindPassword = "Allstate1";
      this.DCname = "dc=ad,dc=allstate,dc=com";
      this.DCnameInRepository = "dc=ad,dc=allstate,dc=com";
      this.secmgraccid = "group:" + cellname + "/cn=was_dmgradmins,ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
      this.secmgrgrpid = "was_dmgradmins@" + cellname;
    }

  }

}


export class SpPackage {

  SPRoot: string = "";
  //  SPCommonArea: string = "SPCommonArea";
  //  SPInstalls: string = "SPInstalls";
  //  SPLink: string = "SPCommonArea/SPLink";
  //  Master: string = "SPInstalls/Master/AppServer";
  //  sharedLocation: string = "/apps/ki01/IMShared";
  //  imLocation: string = "/apps/ki01/InstallationManager/eclipse/tools";
  patches: PatchesTask[] = [];

  constructor() { }

  createPatchesTasks(cellname: string, installRoot: string, wasVersion: string, hosts: string[]) {
    var self = this;
    this.SPRoot = cellname;
    // For each node, we want to create the Deployment Package createDeployPackageTasks
    // Find out what is the chosen version.
    var versions: string[] = [];
    var baseVer = wasVersion.slice(0, wasVersion.lastIndexOf(".")).replace('.', '').replace('.', '');
    var selVer = parseInt(wasVersion.slice(wasVersion.lastIndexOf(".") + 1));
    // start with zero
    versions.push(baseVer + 0)
    versions.push(baseVer + selVer)

    versions.forEach(ver => {
      var wasSpInstall = new PatchesTask();
      wasSpInstall.task = "wasSPInstall";
      wasSpInstall.templateVer = "v" + ver;
      wasSpInstall.useVer = "v" + ver;
      wasSpInstall.hosts = hosts;
      this.patches.push(wasSpInstall);
    });

    var wasSwitchVer = new PatchesTask();
    wasSwitchVer.task = "switchVer";
    wasSwitchVer.templateVer = "v" + versions[1];
    wasSwitchVer.useVer = "v" + versions[1];
    wasSwitchVer.hosts = hosts;
    this.patches.push(wasSwitchVer);
  }

}


export class DeployPackageTask {

  task: string = "";
  templateVer: string = "";
  // sharedLocation: string = "";
  // imLocation: string = "";
  //  pkgLoc: string = "";
  pkgName: string = "";
  //  installLocation: string = "";
  //  respPath: string = "";
  httpPort: string = "";
  adminPort: string = "";

  constructor(installRoot: string) {
    //    this.sharedLocation = installRoot + "/IMShared";
    //    this.imLocation = installRoot + "/InstallationManager/eclipse/tools";
    //    this.installLocation = installRoot;
  }

}

export class ProfilesTask {

  task: string = "";
  SPLink: string = "/apps/ki01/WebSphere9/AppServer";
  nodeName: string = "";
  hostName: string = "";
  dmgrHost: string = "";
  dmgrPort: string = "";
  startNode: string = "";
  serverType: string = "";
  templateVer: string = "";
  portblock: string = "";
  federateLater: string = "";

  constructor(installRoot: string, cellname: string) {
    this.task = "createProfile";
    this.startNode = "true";
    this.federateLater = "false";
  }
}

export class Member {
  memberName: string = "";
  weight: string = "2";
  portblock: string = "211";
  nodeName: string = "";
}

export class VariableMapTask {
  task: string = "";
  scope: string = "";
  scopeName: string = "";
  serverType: string = "";
  varName: string = "";
  varValue: string = "";
  varDesc: string = "";
}

export class ErrorTask {
  task: string = "";
  serverType: string = "";
  fileName: string = "";
}

export class VirtualHostTask {
  task: string = "CreateVirtualHost";
  name: string = "default_host";
  hostname: string = "*";
  port: string = "";
}


export class LdapRegistryTask {
  task: string = "AddLDAPUserRegistry";
  autoGenerateServerId: string = "true";
  verifyRegistry: string = "false";
  baseDN: string = "dc=ad,dc=allstate,dc=com";
  bindDN: string = "cn=sys-mdwadminintc,ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
  bindPassword: string = "Allstate1";
  ignoreCase: string = "true";
  primaryAdminId: string = "sys-mdwadminintc";
  realm: string = "gldc-ad-gc-vip.igslb.allstate.com:3269"
  reuseConnection: string = "true";
  sslConfig: string = "CellDefaultSSLSettings";
  sslEnabled: string = "true";
  host: string = "gldc-ad-gc-vip.igslb.allstate.com";
  port: string = "3269";
}

export class WIMRegistryTask {
  task: string = "AddWIMUserRegistry";
  ignoreCase: string = "true"
  primaryAdminId: string = "cn=sys-mdwadminintc,ou=ServiceAccounts,ou=Common,ou=Corp,dc=ad,dc=allstate,dc=com";
  realm: string = "";
  registryClassName: string = "com.ibm.ws.wim.registry.WIMUserRegistry";
  serverId: string = "";
  serverPassword: string = "{xor}";
  useRegistryServerId: string = "false";
  XMIid: string = "WIMUserRegistry_1";
  XMItype: string = "security:WIMUserRegistry";
}

export class UserRegistry {
  LDAPUserRegistry: LdapRegistryTask[] = [];
  WIMUserRegistry: WIMRegistryTask[] = [];
}

export class AddServer {
  task: string = "addServer";
  serverName: string = "";
  serverType: string = "APPLICATION_SERVER";
  nodeName: string = "";
  templateName: string = "default";
  defaultPort: string = "false";
  portblock: string = "328";
  genUniquePorts: string = "true";

  constructor(_nodeName: string, _serverName: string) {
    this.nodeName = _nodeName;
    this.serverName = _serverName;
  }
}

export class AddUnmanagedNode {
  task: string = "createUnmanagedNode";
  hostName: string = "";
  nodeName: string = "";
  nodeOperatingSystem: string = "linux";

  constructor(_nodeName: string, _hostName: string) {
    this.nodeName = _nodeName;
    this.hostName = _hostName + ".allstate.com";
  }
}

export class AddClusterTask {

  task: string = "addCluster";
  clusterName: string = "";
  preferLocal: string = "true";
  defaultPort: string = "true";
  clusterType: string = "APPLICATION_SERVER";
  members: Member[] = [];
  nodeGroupName: string = "DefaultNodeGroup";
  enableHA: string = "false";

  constructor() { }

  addClusterMember(clusterMember: Member) {
    if (clusterMember)
      this.members.push(clusterMember);
  }

}

export class AddWebServer {
  task: string = "createWebServer";
  nodeName: string = "";
  serverName: string = "";
  webPort: string = "";
  webInstallRoot: string = "";
  pluginInstallRoot: string = "";
  configurationFile: string = "";
  pluginFile: string = "";
  errorLogfile: string = "";
  accessLogfile: string = "";
  webProtocol: string = "HTTP";
  webAppMapping: string = "All";
  adminPort: string = "";
  adminProtocol: string = "HTTP";
  adminUserID: string = "wasadmin";
  adminPasswd: string = "wasadmin";
  templateName: string = "IHS";
  genUniquePorts: string = "true";
  templateLocation: string = "";

  constructor(ihsname: string, installRoot: string, portBlock: string) {
    this.webInstallRoot = installRoot + "/" + ihsname + "/HTTPServer";
    this.pluginInstallRoot = installRoot + "/" + ihsname + "/Plugins";
    this.configurationFile = installRoot + "/" + ihsname + "/HTTPServer/conf/httpd.conf";
    this.pluginFile = installRoot + "/" + ihsname + "/Plugins/config/" + ihsname + "/plugin-cfg.xml";
    this.errorLogfile = installRoot + "/" + ihsname + "/HTTPServer/logs/error_log";
    this.accessLogfile = installRoot + "/" + ihsname + "/HTTPServer/logs/access_log";
    this.nodeName = ihsname;
    this.serverName = ihsname;
    this.webPort = portBlock + '80';
    this.adminPort = portBlock + '60';
  }
}

export class JvmSettings {
  debugMode: string = "false";
  disableJIT: string = "false";
  genericJvmArguments: string = "-Djava.awt.headless=true";
  hprofArguments: string = "";
  initialHeapSize: string = "512";
  maximumHeapSize: string = "1024";
  runHProf: string = "false";
  verboseModeClass: string = "false";
  verboseModeGarbageCollection: string = "false";
  verboseModeJNI: string = "false";
  executableJarFileName: string = "";
  debugArgs: string = "-Djava.compiler=NONE -Xdebug -Xnoagent -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=7777";
}

export class JvmEntry {
  task: string = "";
  serverType: string = "";
  nodeName: string = "";
  serverName: string = "";
  settings: JvmSettings;
}

export class ProcessExecution {
  task: string = "modifyProcessExecution";
  serverType: string = "";
  nodeName: string = "";
  serverName: string = "";
  runAsGroup: string = "wasusr";
  runAsUser: string = "";
  processPriority: string = "20";
  runInProcessGroup: string = "0";
  umask: string = "022";
}

export class MonitoringPolicy {
  task: string = "modifyMonitoringPolicy";
  note: string = "serverType -- APPLICATION_SERVER or '' only ";
  serverType: string = "APPLICATION_SERVER";
  nodeName: string = "";
  serverName: string = "";
  autoRestart: string = "true";
  maximumStartupAttempts: string = "3";
  nodeRestartState: string = "PREVIOUS";
  pingInterval: string = "60";
  pingTimeout: string = "300";
}

export class ProcessDefinitions {

  jvmEntries: JvmEntry[] = [];
  processExecution: ProcessExecution[] = [];
  monitoringPolicy: MonitoringPolicy[] = [];

  constructor() { }
}

export class AddSignerCertificate {
  task: string = "AddSignerCertificate";
  keyStoreScope: string = "";
  keyStoreName: string = "CellDefaultTrustStore";
  certificateAlias: string = "";
  certificateFilePath: string = "";
  base64Encoded: string = "true";
}

export class SignerCertificates {
  addSignerCertificate: AddSignerCertificate[] = [];
}

export class DeployPackage {

  hostName: string = "";
  startProduct: string = "start";
  responses: DeployPackageTask[] = [];
  wasHome: string = "";

  constructor() { }

  createDeployPackageTasks(cellname: string, installRoot: string, wasVersion: string, node: WasNodeTemplate) {
    var self = this;

    var versions: string[] = [];
    var baseVer = wasVersion.slice(0, wasVersion.lastIndexOf(".")).replace('.', '').replace('.', '');
    var selVer = parseInt(wasVersion.slice(wasVersion.lastIndexOf(".") + 1));
    // start with zero
    versions.push(baseVer + 0);
    versions.push(baseVer + selVer);
    var latestver = baseVer + selVer + ''; // Make it a string

    // For each node, we want to create the Deployment Package createDeployPackageTasks
    this.hostName = node.hostName;

    versions.forEach(ver => {
      var toolbox = new DeployPackageTask(installRoot);
      toolbox.task = "custInstall";
      toolbox.templateVer = ver.toString();
      toolbox.pkgName = cellname;
      delete toolbox.adminPort;
      delete toolbox.httpPort;
      this.responses.push(toolbox);
    });

    versions.forEach(ver => {
      var wasInstall = new DeployPackageTask(installRoot);
      wasInstall.task = "wasInstall";
      wasInstall.templateVer = ver.toString();
      wasInstall.pkgName = cellname;
      delete wasInstall.adminPort;
      delete wasInstall.httpPort;
      this.responses.push(wasInstall);
    });

    node.ihsTemplates.forEach(function (ihsTemplate) {
      versions.forEach(ver => {
        var ihsInstall = new DeployPackageTask(installRoot);
        ihsInstall.task = "ihsInstall";
        ihsInstall.templateVer = ver.toString();
        ihsInstall.pkgName = ihsTemplate.ihsName;
        ihsInstall.httpPort = ihsTemplate.portBlock + '80';
        ihsInstall.adminPort = ihsTemplate.portBlock + '60';
        self.responses.push(ihsInstall);

        var plgInstall = new DeployPackageTask(installRoot);
        plgInstall.task = "plgInstall";
        plgInstall.templateVer = ver.toString();
        plgInstall.pkgName = ihsTemplate.ihsName;
        delete plgInstall.adminPort;
        delete plgInstall.httpPort;
        self.responses.push(plgInstall);
      });
    });
  }

}


export class ManageSDK {

  hostName: string = "";
  task: string = "setNewProfileDefault";
  javaVersion: string = "";
  wasHome: string = "";

  constructor() { }
}

export class Dmgr {
  dmgrNode: string;
  dmgrName: string;
  minHeap: string;
  maxHeap: string;
}

export class LdapTypeInfo {
  ldapDomain: string = "";
  ldapId: string = "";
  ldapBindId: string = "";
}

export class EnvInfo {
  envType: string;
  envNumber: string;
  installType: string = "WAS_ND";
  installVersion: string;
  fixLevel: string = "No";
  clusterType: string = "";
  sslEnabled: string = "";
  globalSecurityAdmin: string = "";
  globalSecurityMonitor: string = "";
  installAsRoot: string = "";
  javaVersion: string;
  webServerType: string = "";
  webServerDmz: string = "";
  monitoringPolicy: string = "RUNNING";
  runas_id: string;
  runas_grp: string = "wasusr";
  standaloneLdap: string = "false";
}


@Injectable()
export class WasDataTransformService {

  wasHome: string = "";
  wasName: string = "";

  constructor() {

  }

  createDocId(cellname: string): string {
    var docId = "";
    // Create a new Doc ID using the format: cellname-timestamp.
    var now = new Date(Date.now());
    docId = now.getFullYear() + "-" + now.getMonth() + "-" +
      now.getDay() + "-" + now.getHours() + "-" + now.getMinutes() + "-" +
      now.getSeconds() + "-" + now.getMilliseconds();
    return docId;
  }

  formatInstallManager(nodes) {
    var installMgr = [];
    nodes.forEach(node => {
      // Process each node.
      var imgr = new InstallationManager();
      imgr.hostName = node.hostName;
      installMgr.push(imgr);
    });
    return installMgr;
  }

  formatRestartIHSTask() {

    let restartIhs = [];
    let rest = new GenerateIHSTasks();
    rest.task = "RestartIHS";

    restartIhs.push(rest);

    return restartIhs;
  }

  formatGenPluginTask() {

    let genPlug = [];
    let rest = new GenerateIHSTasks();
    rest.task = "GeneratePlugin";

    genPlug.push(rest);

    return genPlug;
  }

  formatPropPluginTask() {

    let genPlug = [];
    let rest = new GenerateIHSTasks();
    rest.task = "PropagatePlugin";

    genPlug.push(rest);

    return genPlug;
  }


  formatSignerCertificate(data) {
    var certs = new SignerCertificates();

    var signcert = new AddSignerCertificate();
    signcert = new AddSignerCertificate();
    signcert.certificateAlias = "aries-int";
    signcert.certificateFilePath = Constants.getSignerCertsPath() + "aries-int-prd.cer";
    certs.addSignerCertificate.push(signcert);

    signcert = new AddSignerCertificate();
    signcert.certificateAlias = "aries-root-etest";
    signcert.certificateFilePath = Constants.getSignerCertsPath() + "aries-root-etest.cer";
    certs.addSignerCertificate.push(signcert);

    signcert = new AddSignerCertificate();
    signcert.certificateAlias = "aries-root-test";
    signcert.certificateFilePath = Constants.getSignerCertsPath() + "aries-root-test.cer";
    certs.addSignerCertificate.push(signcert);

    signcert = new AddSignerCertificate();
    signcert.certificateAlias = "aries-root-prd";
    signcert.certificateFilePath = Constants.getSignerCertsPath() + "aries-root-prd.cer";
    certs.addSignerCertificate.push(signcert);

    signcert = new AddSignerCertificate();
    signcert.certificateAlias = "aries-int-test";
    signcert.certificateFilePath = Constants.getSignerCertsPath() + "aries-int-test.cer";
    certs.addSignerCertificate.push(signcert);

    return certs;
  }

  formatManageSDK(data) {
    var manageSDK = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      var mngSdk = new ManageSDK();
      mngSdk.hostName = node.hostName;
      mngSdk.javaVersion = data.javaVersion;
      mngSdk.wasHome = this.wasHome;
      manageSDK.push(mngSdk);
    });
    return manageSDK;
  }

  formatPackages(data, wasName) {
    var packages = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      var pkg = new DeployPackage();
      pkg.createDeployPackageTasks(wasName, data.installRoot, data.selectedWasVersion, node);
      packages.push(pkg);
    });
    return packages;
  }

  formatDmgr(data) {
    var dmgr = new Dmgr();

    dmgr.dmgrNode = data.dmgrNode;
    dmgr.dmgrName = data.dmgrName;
    dmgr.minHeap = data.dmgrMinHeap;
    dmgr.maxHeap = data.dmgrMaxHeap;

    return dmgr;
  }

  formatLdapInfo(data) {
    var ldap = new LdapTypeInfo();

    ldap.ldapBindId = data.ldapBindId;
    ldap.ldapId = data.ldapId;
    if (data.selectedLdapType === "test")
      ldap.ldapDomain = "sa-tst";
    else
      if (data.selectedLdapType === "etest")
        ldap.ldapDomain = "sa-tad";
      else
        ldap.ldapDomain = "sa-prd";

    return ldap;
  }

  formatEnvInfo(data) {
    var env = new EnvInfo();

    env.envType = data.envTypeCode;
    env.envNumber = data.envNumber;
    env.installVersion = data.selectedWasVersion;
    env.javaVersion = data.javaVersion;
    env.runas_id = data.runasId;
    env.installType = data.installType;
    env.fixLevel = data.fixLevel;
    env.globalSecurityAdmin = data.globalSecurityGroup;
    env.globalSecurityMonitor = data.monitorSecurityGroup;
    if (data.installAsRoot)
      env.installAsRoot = 'true';
    else
      env.installAsRoot = 'false';
    if (data.standaloneLdap)
      env.standaloneLdap = "true";
    else
      env.standaloneLdap = "false";
    return env;
  }

  formatProcessDefinitions(data) {
    var procdef = new ProcessDefinitions();

    // First Create the JVMEntry for dmgr
    var dmgrsettings = new JvmSettings();
    var dmgrEntry = new JvmEntry();
    dmgrEntry.settings = dmgrsettings;
    dmgrEntry.serverType = "DEPLOYMENT_MANAGER";
    dmgrEntry.task = "modifyJVMEntries";

    procdef.jvmEntries.push(dmgrEntry);

    // First Create the JVMEntry for nodeagent
    var nodesettings = new JvmSettings();
    var nodeEntry = new JvmEntry();
    nodeEntry.settings = nodesettings;
    nodeEntry.serverType = "NODE_AGENT";
    nodeEntry.task = "modifyJVMEntries";

    procdef.jvmEntries.push(nodeEntry);

    // Loop through all nodes and setup jvm settings.
    data.nodeTemplates.forEach(node => {
      // Loop through all the jvms.
      node.jvmTemplates.forEach(jvm => {
        var appsettings = new JvmSettings();
        appsettings.initialHeapSize = jvm.minHeap;
        appsettings.maximumHeapSize = jvm.maxHeap;
        var appEntry = new JvmEntry();
        appEntry.settings = appsettings;
        appEntry.serverName = jvm.jvmName;
        appEntry.nodeName = node.nodeName;
        appEntry.serverType = "APPLICATION_SERVER";
        appEntry.task = "modifyJVMEntries";

        procdef.jvmEntries.push(appEntry);

      });
    });

    // Setup Process Executions
    var procexec = new ProcessExecution();
    procexec.runAsUser = data.runasId;
    procdef.processExecution.push(procexec);

    var monpolicy = new MonitoringPolicy();
    //   procdef.monitoringPolicy.push(monpolicy);  no need to set this.

    return procdef;
  }

  formatProfiles(data, wasName) {
    var profiles: ProfilesTask[] = [];

    var wasVersion = data.selectedWasVersion;
    var baseVer = wasVersion.slice(0, wasVersion.lastIndexOf(".")).replace('.', '').replace('.', '');
    var selVer = parseInt(wasVersion.slice(wasVersion.lastIndexOf(".") + 1));
    var latestver = baseVer + selVer + ''; // Make it a string

    // Create DMGR First
    var dmgrprofile = new ProfilesTask(data.installRoot, wasName);
    dmgrprofile.nodeName = data.dmgrName;
    dmgrprofile.hostName = data.dmgrNode;
    dmgrprofile.serverType = "DEPLOYMENT_MANAGER";
    dmgrprofile.templateVer = latestver;
    dmgrprofile.portblock = data.dmgrPort ? data.dmgrPort : "201";
    profiles.push(dmgrprofile);

    data.nodeTemplates.forEach(node => {
      // Process each node.
      var nodeprofile = new ProfilesTask(data.installRoot, wasName);
      nodeprofile.nodeName = node.nodeName;
      nodeprofile.hostName = node.hostName;
      nodeprofile.dmgrHost = data.dmgrNode;
      nodeprofile.dmgrPort = dmgrprofile.portblock + '05';
      nodeprofile.serverType = "NODEAGENT";
      nodeprofile.templateVer = latestver;
      nodeprofile.portblock = node.portBlock + '';
      profiles.push(nodeprofile);
    });

    return profiles;
  }

  formatVariableMap(data) {
    var variablesMap = [];

    var logLocation = new VariableMapTask();
    logLocation.task = "createWebSphereVariable";
    logLocation.scope = "server";
    logLocation.serverType = "APPLICATION_SERVER";
    logLocation.varName = "SERVER_LOG_ROOT";
    logLocation.varValue = "${LOG_ROOT}/${WAS_SERVER_NAME}";
    logLocation.varDesc = "The log root directory for server ${WAS_SERVER_NAME}";

    variablesMap.push(logLocation);

    logLocation = new VariableMapTask();
    logLocation.task = "createWebSphereVariable";
    logLocation.scope = "cell";
    logLocation.varName = "SERVER_LOG_ROOT";
    logLocation.varValue = "${LOG_ROOT}/${WAS_SERVER_NAME}";
    logLocation.varDesc = "The log root directory for server ${WAS_SERVER_NAME}";

    variablesMap.push(logLocation);

    return variablesMap;
  }

  formatErrorStreamRedirect(data) {
    var errorStreamRedirect = [];

    var errorTask = new ErrorTask();

    errorTask.task = "updateSysErrLog";
    errorTask.serverType = "DEPLOYMENT_MANAGER";
    errorTask.fileName = "$(LOG_ROOT)/dmgr/SystemErr.log";
    errorStreamRedirect.push(errorTask);

    errorTask = new ErrorTask();
    errorTask.task = "updateSysErrLog";
    errorTask.serverType = "NODE_AGENT";
    errorTask.fileName = "${LOG_ROOT}/${SERVER}/SystemErr.log";
    errorStreamRedirect.push(errorTask);

    errorTask = new ErrorTask();
    errorTask.task = "updateSysErrLog";
    errorTask.serverType = "APPLICATION_SERVER";
    errorTask.fileName = "${SERVER_LOG_ROOT}/SystemErr.log";
    errorStreamRedirect.push(errorTask);

    return errorStreamRedirect;
  }

  formatOutputStreamRedirect(data) {
    var outputStreamRedirect = [];

    var errorTask = new ErrorTask();

    errorTask.task = "updateSysOutLog";
    errorTask.serverType = "DEPLOYMENT_MANAGER";
    errorTask.fileName = "$(LOG_ROOT)/dmgr/SystemOut.log";
    outputStreamRedirect.push(errorTask);

    errorTask = new ErrorTask();
    errorTask.task = "updateSysOutLog";
    errorTask.serverType = "NODE_AGENT";
    errorTask.fileName = "${LOG_ROOT}/${SERVER}/SystemOut.log";
    outputStreamRedirect.push(errorTask);

    errorTask = new ErrorTask();
    errorTask.task = "updateSysOutLog";
    errorTask.serverType = "APPLICATION_SERVER";
    errorTask.fileName = "${SERVER_LOG_ROOT}/SystemOut.log";
    outputStreamRedirect.push(errorTask);


    return outputStreamRedirect;
  }


  formatVirtualHosts(data) {
    var virtualHosts = [];

    // add the default port 80 and 443 for virtual hosts
    let hostTask = new VirtualHostTask();
    hostTask.port = '80';
    virtualHosts.push(hostTask);

    let admTask = new VirtualHostTask();
    admTask.port = '443';
    virtualHosts.push(admTask);

    if (data.nodeTemplates) {
      // Loop through all nodes and pickup the cluster members to create.
      data.nodeTemplates.forEach(node => {
        // Loop through all the jvms.
        node.jvmTemplates.forEach(jvm => {
          let hostTask = new VirtualHostTask();
          hostTask.port = jvm.portBlock + '80';
          virtualHosts.push(hostTask);

          let admTask = new VirtualHostTask();
          admTask.port = jvm.portBlock + '43';
          virtualHosts.push(admTask);
        })
        // Loop through all the ihs
        node.ihsTemplates.forEach(ihs => {
          let hostTask = new VirtualHostTask();
          hostTask.port = ihs.portBlock + '80';
          virtualHosts.push(hostTask);

          let admTask = new VirtualHostTask();
          admTask.port = ihs.portBlock + '43';
          virtualHosts.push(admTask);
        });
      }); //nodeTemplates

    } //if

    return virtualHosts;
  }

  formatAuthorization(data) {
    var mappingTasks = [];

    if (data.globalSecurityGroup) {
      var adminGroups = data.globalSecurityGroup.split(",");
      if (adminGroups.length > 0) {
        for (var i = 0; i < adminGroups.length; i++) {
          var dn = "";
          if (data.selectedLdapType === "etest") {
            dn = "cn=" + adminGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=tad,dc=allstate,dc=com";
          }
          else
            if (data.selectedLdapType === "prod") {
              dn = "cn=" + adminGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=ad,dc=allstate,dc=com";
            }
            else {
              // test ldap - default
              dn = "cn=" + adminGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=test,dc=allstate,dc=com";
            }
          var mapTask = new MapGroupTask();
          mapTask.roleName = "administrator";
          mapTask.accessids = dn;
          mapTask.groupids = dn;
          mappingTasks.push(mapTask);
        }
      }
    }

    if (data.monitorSecurityGroup) {
      var monitorGroups = data.monitorSecurityGroup.split(",");
      if (monitorGroups.length > 0) {
        for (var i = 0; i < monitorGroups.length; i++) {
          var dn = "";
          if (data.selectedLdapType === "etest") {
            dn = "cn=" + monitorGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=tad,dc=allstate,dc=com";
          }
          else
            if (data.selectedLdapType === "prod") {
              dn = "cn=" + monitorGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=ad,dc=allstate,dc=com";
            }
            else {
              // test ldap - default
              dn = "cn=" + monitorGroups[i] + ",OU=Security,OU=Groups,OU=Corp,dc=test,dc=allstate,dc=com";
            }
          var mapTask = new MapGroupTask();
          mapTask.roleName = "monitor";
          mapTask.accessids = dn;
          mapTask.groupids = dn;
          mappingTasks.push(mapTask);
        }
      }
    }

    return mappingTasks;
  }

  formatUserRegistries(data) {

    var userRegistry = new UserRegistry();

    var wimRegistryTask = new WIMRegistryTask();
    wimRegistryTask.realm = data.cellId;

    userRegistry.WIMUserRegistry.push(wimRegistryTask);

    if (!data.standaloneLdap) {
      delete userRegistry.LDAPUserRegistry;
    }
    else {
      var ldapRegistryTask = new LdapRegistryTask();
      userRegistry.LDAPUserRegistry.push(ldapRegistryTask);
    }

    return userRegistry;
  }


  formatFederatedRepository(data) {
    var fedrep = new FederatedRepository(data.cellname, data.ldapId, data.bindId, data.selectedLdapType);

    return fedrep;
  }

  formatTopology(data) {
    var topology = [];

    if (data.clusterNames.length > 0) {
      // Loop through each cluster and create cluster and cluster members
      data.clusterNames.forEach(clusterName => {
        var newCluster = new AddClusterTask();
        newCluster.clusterName = clusterName;

        // Loop through all nodes and pickup the cluster members to create.
        data.nodeTemplates.forEach(node => {
          // Loop through all the jvms.
          node.jvmTemplates.forEach(jvm => {
            if (jvm.clusterName === clusterName) {// Matches this cluster 
              var member = new Member();
              member.memberName = jvm.jvmName;
              member.portblock = jvm.portBlock + ''; // convert to string if its not.
              member.nodeName = node.nodeName;
              newCluster.addClusterMember(member);
            }
          })
        });
        topology.push(newCluster);
      });
    }

    // Add the standalone non-cluster app servers if any.
    // Loop through all nodes and pickup the cluster members to create.
    data.nodeTemplates.forEach(node => {
      // Loop through all the jvms.
      node.jvmTemplates.forEach(jvm => {
        if (!jvm.clusterName) {// no clustername defined.
          var server = new AddServer(node.nodeName, jvm.jvmName);
          topology.push(server);
        }
      });
    });

    // Add the WebServers
    data.nodeTemplates.forEach(node => {
      // Process each node.
      node.ihsTemplates.forEach(ihs => {
        var webnode = new AddUnmanagedNode(ihs.ihsName, node.hostName);
        topology.push(webnode);
        var webserver = new AddWebServer(ihs.ihsName, data.installRoot, ihs.portBlock);
        topology.push(webserver);
      });
    });

    return topology;
  }

  formatProcessOrder(data) {
    var processOrder = ["topology", "VariableMap", "jvmEntries", "processExecution", "virtualhosts", "errorStreamRedirect",
      "outputStreamRedirect", "monitoringPolicy", "virtualhosts", "WSCertExpMonitor", "deployApp"];

    return processOrder;
  }


  formatSpPackages(data, wasName) {
    var pkg = new SpPackage();
    var hosts: string[] = [];
    // Got a list of all hosts.
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.numJvms > 0)
        hosts.push(node.hostName);
    });

    pkg.createPatchesTasks(wasName, data.installRoot, data.selectedWasVersion, hosts);

    return pkg;
  }


  formatServerEntries(data) {
    var serverEntriesDefault = {
      "DEPLOYMENT_MANAGER": {
        "BOOTSTRAP_ADDRESS": "00",
        "CELL_DISCOVERY_ADDRESS": "01",
        "SOAP_CONNECTOR_ADDRESS": "05",
        "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS": "06",
        "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS": "07",
        "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS": "08",
        "ORB_LISTENER_ADDRESS": "13",
        "DCS_UNICAST_ADDRESS": "14",
        "IPC_CONNECTOR_ADDRESS": "15",
        "DataPowerMgr_inbound_secure": "16",
        "OVERLAY_UDP_LISTENER_ADDRESS": "17",
        "OVERLAY_TCP_LISTENER_ADDRESS": "18",
        "XDAGENT_PORT": "19",
        "STATUS_LISTENER_ADDRESS": "20",
        "WC_adminhost": "60",
        "WC_adminhost_secure": "63"
      },
      "APPLICATION_SERVER": {
        "BOOTSTRAP_ADDRESS": "00",
        "SIB_ENDPOINT_ADDRESS": "01",
        "SIB_ENDPOINT_SECURE_ADDRESS": "02",
        "SIB_MQ_ENDPOINT_ADDRESS": "03",
        "SIB_MQ_ENDPOINT_SECURE_ADDRESS": "04",
        "SOAP_CONNECTOR_ADDRESS": "05",
        "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS": "06",
        "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS": "07",
        "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS": "08",
        "SIP_DEFAULTHOST": "09",
        "SIP_DEFAULTHOST_SECURE": "10",
        "ORB_LISTENER_ADDRESS": "13",
        "DCS_UNICAST_ADDRESS": "14",
        "IPC_CONNECTOR_ADDRESS": "15",
        "OVERLAY_UDP_LISTENER_ADDRESS": "17",
        "OVERLAY_TCP_LISTENER_ADDRESS": "18",
        "WC_defaulthost_secure": "43",
        "WC_adminhost": "60",
        "WC_adminhost_secure": "63",
        "WC_defaulthost": "80"
      },
      "NODE_AGENT": {
        "BOOTSTRAP_ADDRESS": "00",
        "DCS_UNICAST_ADDRESS": "04",
        "SOAP_CONNECTOR_ADDRESS": "05",
        "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS": "06",
        "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS": "07",
        "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS": "08",
        "NODE_IPV6_MULTICAST_DISCOVERY_ADDRESS": "09",
        "NODE_MULTICAST_DISCOVERY_ADDRESS": "10",
        "NODE_DISCOVERY_ADDRESS": "11",
        "ORB_LISTENER_ADDRESS": "13",
        "IPC_CONNECTOR_ADDRESS": "15",
        "XDAGENT_PORT": "7062",
        "OVERLAY_TCP_LISTENER_ADDRESS": "11004",
        "OVERLAY_UDP_LISTENER_ADDRESS": "11003"
      }
    }
    return serverEntriesDefault;
  }

  formatDeployApp(data) {

    let deploy = [];
    let deployApp = {
      "task": "deployDefaultApp"
    }

    deploy.push(deployApp);

    return deploy;
  }


  formatLogRotate(data) {
    var logRotate = [];
    var log = new LogRotate();
    data.nodeTemplates.forEach(node => {
      // Process each node.
      log.createLogTasks(node, data);

    });
    logRotate.push(log);
    return logRotate;

  }

  toWasDeployFormat = function (data) {
    this.wasName = data.cellname.replace("-cell", "-was");
    this.wasHome = data.installRoot + "/" + this.wasName + "/AppServer";
    var defDocLoc = Constants.getWasGlobalSecurityPath();
    var httpdConfLoc = Constants.getWasHttpdConfLocPath();
    var installLoc = Constants.getWasInstallationPath();
    var installRoot = Constants.getWasInstallRootPath();

    var dest = {
      "docId": this.createDocId(data.cellname),
      "cellId": data.cellname || '',
      "installRoot": installRoot,
      "reGen": true,
      "runAsId": data.runasId,
      "wasHome": this.wasHome,
      "javaVersion": data.javaVersion,
      "ldapInfo": this.formatLdapInfo(data),
      "deploymentType": 'build',
      "oldStandards" : data.oldStandards,
      "projectInfo": {
        "projectName": data.appName,
        "tciCode": data.tciCode,
        "ldapInfo": this.formatLdapInfo(data),
        "envInfo": this.formatEnvInfo(data),
      },
      "defaultDoc": {
        "httpdConf": httpdConfLoc,
        "globalSecurity": defDocLoc,
        "installation": installLoc,
      },
      "installationManager": this.formatInstallManager(data.nodeTemplates),
      // Naren Commented out since we don't want to do this right now.
      //        "spPackages" : this.formatSpPackages(data, this.wasName),
      "packages": this.formatPackages(data, this.wasName),
      "profiles": this.formatProfiles(data, this.wasName),
      "processOrder": this.formatProcessOrder(data),
      "restartIHS": this.formatRestartIHSTask(),
      "generatePlugin": this.formatGenPluginTask(),
      "propagatePlugin": this.formatPropPluginTask(),
      "topology": this.formatTopology(data),
      "VariableMap": this.formatVariableMap(data),
      "processDefinitions": this.formatProcessDefinitions(data),
      //    "errorStreamRedirect": this.formatErrorStreamRedirect(data),
      //    "outputStreamRedirect": this.formatOutputStreamRedirect(data),
      "virtualhosts": this.formatVirtualHosts(data),
      //   "userRegistries" : this.formatUserRegistries(data),
      //    "Authorization" : this.formatAuthorization(data),
      //   "WSCertExpMonitor" : this.formatCertExpMonitor(data),
      //    "postConfig" : this.formatPostConfig(data),
      //    "signerCertificate" : this.formatSignerCertificate(data),
      //    "federatedRepository" : this.formatFederatedRepository(data),
      "dmgr": this.formatDmgr(data),
      "nodeTemplates": data.nodeTemplates,
      //      "serverEntriesDefault" : this.formatServerEntries(data),
      "deployApp": this.formatDeployApp(data),
      "rc": Constants.getWasOpsPath() + "wasScripts/boot/bin",
      "logrotate": this.formatLogRotate(data)
    }; //var dest

    return dest;

  }  //toWasDeployFormat

  toWasPatchFormat = function (data) {
    this.wasName = data.cellName.replace("-cell", "-was");
    this.wasHome = Constants.getWasInstallRootPath() + "/" + this.wasName + "/AppServer";
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "runAsId": data.runasId,
      "wasHome": this.wasHome,
      "installRoot": Constants.getWasInstallRootPath(),
      "deploymentType": 'patch',
      "nodeTemplates": data.nodes
    };

    return dest;
  }

  toWasRollbackFormat = function (data) {
    this.wasName = data.cellName.replace("-cell", "-was");
    this.wasHome = Constants.getWasInstallRootPath() + "/" + this.wasName + "/AppServer";
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "runAsId": data.runasId,
      "wasHome": this.wasHome,
      "installRoot": Constants.getWasInstallRootPath(),
      "deploymentType": 'rollback',
      "nodeTemplates": data.nodes
    };

    return dest;
  }

  toWasUninstallFormat = function (data) {
    this.wasName = data.cellName.replace("-cell", "-was");
    this.wasHome = Constants.getWasInstallRootPath() + "/" + this.wasName + "/AppServer";
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "runAsId": data.runasId,
      "wasHome": this.wasHome,
      "installRoot": Constants.getWasInstallRootPath(),
      "deploymentType": 'uninstall',
      "nodeTemplates": data.nodes
    };

    return dest;
  }


}  // WasDataFormatService

