import { TestBed, inject } from '@angular/core/testing';

import { LinuxWorkflowService } from './linux-workflow.service';

describe('LinuxWorkflowService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LinuxWorkflowService]
    });
  });

  it('should ...', inject([LinuxWorkflowService], (service: LinuxWorkflowService) => {
    expect(service).toBeTruthy();
  }));
});
