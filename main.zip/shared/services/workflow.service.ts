import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Constants} from '../config/constants';

@Injectable()
export class WorkflowService {

  workflow = {};
	workflowProgress = {};
  
  constructor(private http: HttpClient ) {
  }

  public discoverWorkflow( params: string[], limit: number, offset: number, trim: string) : Promise<any> {
      var _params = {        
      };

      // Make copy of params in browser safe manner
      if(params) {
        _params = JSON.parse(JSON.stringify(params));
      }
      if(limit){
				//_params.limit = limit;
			}
			if(offset){
				//_params.offset = offset;
			}
			if(trim){
			//	_params.fields = INVENTORY_TRIM
			}
      console.log('Calling Workflow...');
      return this.http.get(Constants.getDiscoverWorkflowUrl()) 
                    .toPromise()
                    .then(this.workflowResults)
                    .catch(this.handleError);
  }

  workflowResults (_response: Response) : any {
     let body = _response;
     this.workflow = body;
     Object.keys(this.workflow).forEach(function(type){
						this.workflowProgress[type] = {};
						this.workflow[type].forEach(function(state, idx){
							this.workflowProgress[type][state.id] = (idx / (this.workflow[type].length-1))*100;
						});
					});
     return body || { };
  }

  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  } 

  getWorkflowStates (type)      {
    if(this.workflow[type]){
      return this.workflow[type].map(function(state){
        return {value: state.id, label: state.label};
      });
    }
    return [];
  };
	
  getNextAction (type, status){
			var action = null;
			if(status.error){
				action = status.state;
			}
			else if(status.complete && this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach(function(stage, idx){
					if(stage.id === status.state && ((idx + 1) < this.workflow[type].length)){
						action = this.workflow[type][idx+1].id;
					}
				});
			}
			return action;
	};

	getMaxStateDuration (type, state){
			var duration = null;
			if(this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach(function(stage){
					if(stage.id === state){
						duration = stage.max;
					}
				});
			}
			return duration;
	};
	
  getStateLabel(type, state){
			var label = null;
			if(this.workflow[type] && this.workflow[type].length){
				this.workflow[type].forEach(function(stage){
					if(stage.id === state){
						label = stage.label;
					}
				});
			}
			return label;
	};

	getStateProgress (type, state){
			return Math.round(this.workflowProgress[type][state]) || 0;
	}

}
