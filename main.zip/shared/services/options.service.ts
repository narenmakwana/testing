import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Constants } from '../config/constants';
import { CellParseService } from './cell-parse.service';
import { OrgService } from './org.service';
import { PackagesService } from './packages.service';
import { TagsService } from './tags.service';

@Injectable()
export class OptionsService {

	NODE_TYPES: any;
	INSTALL_TYPES: any;

	constructor(private http: HttpClient, protected _cellParseService: CellParseService,
		protected _orgService: OrgService,
		protected _packagesService: PackagesService, protected _tagsService: TagsService) {
		this.NODE_TYPES = _cellParseService.NODE_TYPES;
		this.INSTALL_TYPES = _cellParseService.INSTALL_TYPES;
	}

	_createFilterFor = function (query) {
		return function filterFn(state) {
			return (('' + state).toLowerCase().match(query.toLowerCase()));
		}
	}

	getNodeTypes = function () {
		var types = [];
		Object.keys(this.NODE_TYPES).forEach(function (key) {
			if (!this.NODE_TYPES[key].hideFromDesigner) {
				types.push(this.NODE_TYPES[key]);
			}
		});
		return types;
	}

	getNodeType = function (val) {
		var type = null;
		Object.keys(this.NODE_TYPES).forEach(function (key) {
			if (this.NODE_TYPES[key].value === val) {
				type = this.NODE_TYPES[key];
			}
		});
		return type;
	};

	getInstallType = function (val) {
		var type = null;
		Object.keys(this.INSTALL_TYPES).forEach(function (key) {
			if (this.INSTALL_TYPES[key].value === val) {
				type = this.INSTALL_TYPES[key];
			}
		});
		return type;
	};

	getNodeLink = function (node) {
		if (!node) {
			return '';
		}
		return 'http://' + node.hostId + ':' +
			node.port + node.urlPath;
	};

	queryTciCodes(query): Promise<string[]> {
		return new Promise((resolve, reject) => {
			this._orgService.getTciCodes().then((resp) => {
				var tciArr = [];
				var dcios = resp.items;
				dcios.forEach((dcio) => {
					dcio.applications.forEach((app) => {
						tciArr.push(app.tciCode);
					});
				});
				if (query) {
					tciArr = tciArr.filter(this._createFilterFor(query))
				}
				resolve(tciArr);
			}, function () {
				reject();
			});
		});
	};

	queryClusterNames = function (clusters, query) {
		return new Promise((resolve) => {
			var clustersArr = [];
			if (query) {
				clustersArr = (Object.keys(clusters)).filter(this._createFilterFor(query))
			}
			resolve(clustersArr);
		});
	};
	/*
		queryHostNames = function(query){
				return new Promise((resolve, reject)=>{
					this._hostService.getHosts({'hostname.contains': query, 'limit': 50}).then(function(results){
						var hosts = [];
						results.data.items.forEach((item)=>{
							hosts.push(item.hostname);
						});
						if(query){
							hosts = hosts.filter(this._createFilterFor(query))
						}
						resolve( hosts ); 
					}, function(){
						reject();
					});
				});
		}
	
		queryOSVersions = function(query){
				return new Promise((resolve, reject)=>{
					//Limit to 50 results to make this snappy
					this._hostService.getHosts({'os.release.full.contains': query, 'limit': 50}).then(function(results){
						var os = {};
						results.data.items.forEach(function(item){
							os[item.os.release.full] = true;
						});
						var osArr = Object.keys(os);
						resolve( osArr ); 
					}, function(){
						reject();
					});
				});
		};
	*/
	getEnvTypes = function () {
		return ['sb', 'dv', 'et', 'ft', 'rt', 'it', 'st', 'pt', 'pp', 'hf', 'sc', 'pd', 'pb'];
	};

	queryEnvTypes = function () {
		return () => (function (resolve) {
			setTimeout(function () {
				resolve(this.getEnvTypes());
			});
		});
	};

	getInstallTypes = function () {
		return ['pdm', 'dm', 'bp'];
	};

	queryWasVersions = function (query, type) {
		var self = this;
		return new Promise(function (resolve, reject) {
			self._packagesService.getPackages({ 'install_type': type, 'expandRefs': true }).then(function (results) {
				var versions = [];
				results.items.forEach(function (item) {
					versions[item.version] = true;
					item.fixpacks.forEach(function (fp) {
						versions[fp.fixpackName] = true;
					});
				});
				versions = Object.keys(versions).sort(self._cellParseService.compareWasVersions);
				if (query) {
					versions = versions.filter(self._createFilterFor(query))
				}
				resolve(versions);
			}, function () {
				reject();
			});
		});
	};

	getWlpVersions = function () {
		var self = this;
		return new Promise(function (resolve, reject) {
			self._packagesService.getWlpPackages().then(function (results) {
				var versions = [];
				results.items.forEach((item) => {
					versions.push({
						wlp: item.fixpackName,
						java: item.java,
						deadline: item.complianceDeadline
					});
				});
				resolve(versions);
			}, function () {
				reject();
			});
		});
	};


	getWasVersions = function (query, type) {
		var self = this;
		return new Promise(function (resolve, reject) {
			self._packagesService.getPackages({ 'install_type': type, 'expandRefs': true }).then(function (results) {
				var versions = [];
				results.items.forEach(function (item) {
					item.fixpacks.forEach(function (fp) {
						var fixPack = { was: fp.fixpackName, deadline: fp.complianceDeadline };
						versions.push(fixPack);
					});
				});

				versions.sort((a, b) => {
					var fixpackA = new Date(Date.parse(a.deadline)).toISOString();
					var fixpackB = new Date(Date.parse(b.deadline)).toISOString();
					return (fixpackA < fixpackB) ? -1 : (fixpackA > fixpackB) ? 1 : 0;
				});

				resolve(versions);
			}, function () {
				reject();
			});
		});
	};


	getDomains = function () {
		return ['sa-tst', 'sa-tad', 'sa-prd'];
	};

	getGlobalSecurityPermissions = function () {
		return ['admin', 'monitor']
	}

	queryWasFixPacks(query, installType, wasVersion): Promise<string[]> {
		return new Promise((resolve, reject) => {
			var fixpacks = ['None'];
			if (!installType || !wasVersion) {
				resolve(fixpacks);
				return;
			}
			this._packagesService.getPackages(
				{
					'install_type': installType, 'expandRefs': true,
					'version.startsWith': this._cellParseService.getMajorWasVersion(wasVersion)
				})
				.then((results) => {
					results.data.items.forEach((item) => {
						item.fixpacks.forEach((fp) => {
							if (fp.fixpackName === wasVersion) {
								fp.ifix.forEach((ifix) => {
									fixpacks.push(ifix.ifixName);
								})
							}
						});
					});
					if (query) {
						fixpacks = fixpacks.filter(this._createFilterFor(query))
					}
					resolve(fixpacks);
				}, function () {
					reject();
				});
		});
	}

	queryAvailableTags = function (query) {
		return new Promise(function (resolve, reject) {
			this._tagsService.getAvailableTags().then(function (response) {
				var tags = response.data.items || [];
				tags = tags.map(function (item) { return item.id });
				if (query) {
					tags = tags.filter(this._createFilterFor(query))
				}
				resolve(tags);
			}, function () {
				reject();
			});
		});
	};

}
