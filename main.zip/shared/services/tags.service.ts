import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {Constants} from '../config/constants';
import {ResponseResult} from '../models/response-result';


@Injectable()
export class TagsService {

  constructor(private http: HttpClient) {

  }

	
}
