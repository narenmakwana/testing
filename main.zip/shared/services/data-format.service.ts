import { Injectable } from '@angular/core';
import {Constants} from '../config/constants';

@Injectable()
export class DataFormatService {

    constructor() { }

		//Format used by designer
		getJvmObj = function(idx, installType){
			var portBlockStart;
			if(installType === Constants.INSTALL_TYPES.PORTAL.value || installType === Constants.INSTALL_TYPES.BASE.value
				|| installType === Constants.INSTALL_TYPES.ND.value){
				portBlockStart = 211
			}
			else {
				portBlockStart = 300;
			}
			return {
				'portBlock': portBlockStart + idx,
				'clusterName': '',
				'name': '',
				'minHeap': '512',
				'maxHeap': '1024',
				'args': []
			}
		};
        
		//Format used by designer
		getHttpObj = function(idx, httpType, envType){
			var type;
			if(!httpType){
				type = 'ihs'
			}
			else {
				type = httpType;
			}
			return {
				'portBlock': 101 + idx,
				'name': '',
				'type': type,
				'runas_id': 'kiwasdv',
				'runas_grp': 'wasusr'
			};
		};

		//Format used by designer
		getNodeObj = function(idx, installType){
			var type;
			if(installType === Constants.INSTALL_TYPES.PORTAL.value){
				if(idx === 0){
					type = 'pp';
				}
				else {
					type = 'sp';
				}
			}
			else {
				type = 'sa';
			}
			return {
				'hostName': '',
				'httpMembers': [],
				'dmgr': false,
				'jvmMembers': [],
				'name': '',
				'type': type
			}
		};
		//Format used by designer
		getDmgrObj = function(installType){
			var type;
			if(installType === Constants.INSTALL_TYPES.PORTAL.value){
				type = 'pdm';
			}
			else {
				type = 'dm';
			}
			return {
				'name': '',
				'type': type,
				'minHeap': '512',
				'maxHeap': '1024'
			}
		};

		generateCellName = function(cellData){
			var type = '';
			switch(cellData.cell.installType) {
				case Constants.INSTALL_TYPES.TOMCAT.value:
					type = 'tomcat';
					break;
				case Constants.INSTALL_TYPES.ND.value:
					type = 'cell';
					break;
				case Constants.INSTALL_TYPES.BASE.value:
					type = 'cell';
					break;
				case Constants.INSTALL_TYPES.PORTAL.value:
					type = 'cell';
					break;
				case Constants.INSTALL_TYPES.LIBERTY_ND.value:
					type = 'wlp';
					break;
				case Constants.INSTALL_TYPES.LIBERTY_BASE.value:
					type = 'wlp';
					break;
				case Constants.INSTALL_TYPES.LIBERTY_CORE.value:
					type = 'wlp';
					break;
			}
			return cellData.cell.tciCode + '-' + type + (''+cellData.cell.version).charAt(0) + (''+cellData.cell.version).charAt(2) + '-' + 
				cellData.cell.envType + cellData.cell.envNumber;
		};

		generateMemberName = function(cellData, type, idx){
			var i = idx+1;
			if(type === 'dmgr'){
				return cellData.cell.tciCode + '-dmgr' + (''+cellData.cell.version).charAt(0) + (''+cellData.cell.version).charAt(2) + '-' + 
					cellData.cell.envType + cellData.cell.envNumber;
			}
			else if(type === 'http'){
				return cellData.cell.tciCode + '-ihs' + (''+cellData.cell.version).charAt(0) + (''+cellData.cell.version).charAt(2) + '-' + 
					cellData.cell.envType + cellData.cell.envNumber + '-' + ((i<10)?'0'+i:i);
			}
			else if(type === 'jvm'){
				return cellData.cell.tciCode + '-' + cellData.cell.appName + '-' + cellData.cell.envType + cellData.cell.envNumber + '-' + ((i<10)?'0'+i:i);
			}
			else if(type === 'node'){
				return cellData.cell.tciCode + '-node' + (''+cellData.cell.version).charAt(0) + (''+cellData.cell.version).charAt(2) + '-' + cellData.cell.envType + cellData.cell.envNumber + '-' + ((i<10)?'0'+i:i); 
			}
		};
		getDefaultClusterName = function(cellData, name){
			if(name && name !== '$$default$$'){
				return name;
			}
			return cellData.cell.tciCode + '-App-' + cellData.cell.envType + cellData.cell.envNumber;
		};

		getLdapIdFromTciCode = function(tciCode, envType){
			var ldapId = '';
			if( tciCode ) {
				if (envType){
                   ldapId = 'sys-' + tciCode.trim() + 'wadmin' + envType.trim();
				}
				else
					ldapId = 'sys-mdwadminintc';
			}
			else
				ldapId = 'sys-mdwadminintc';
			return ldapId;
		};

		getBindIdFromTciCode = function(tciCode, envType){
			var ldapId = '';
			if( tciCode ) {
				if (envType){
                   ldapId = 'sys-' + tciCode.trim() + 'bind' + envType.trim();
				}
				else
					ldapId = 'sys-mdwadminintc';
			}
			else
				ldapId = 'sys-mdwadminintc';
			return ldapId;
		};

		getDefaultLdapId = function(){
			return 'sys-mdwadminintc';
		};

		getDefaultBindId = function(){
			return 'sys-mdwadminintc';
		};

		getDefaultPortalGroup = function(){
			return 'SA-mdwadminsintc'
		};

		getDefaultPortalId = function(){
			return 'sys-mdwadminintc'
		};

		getDefautMinHeap = function(){
			return '1024';
		};

		getDefautMaxHeap = function(){
			return '1024';
		};
		getDefaultRunAsId = function(envType){
			if(envType === 'pd' || envType === 'pb'){
				return 'kiwaspd';
			}
			else {
				return 'kiwasdv';
			}
		};
		getDefaultRunAsGroup = function(){
			return 'wasusr';
		};

}