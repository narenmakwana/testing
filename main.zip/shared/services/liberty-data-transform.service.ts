import { Injectable } from '@angular/core';
import { LibertyNodeTemplate } from '../models/liberty-node-template';
import { JvmTemplate } from '../models/jvm-template';
import { IhsTemplate } from '../models/ihs-template';
import { Constants } from '../config/constants';

const wlp_basedir = Constants.getWlpBaseDir();
const nas_path = Constants.getNasPath();
const wlp_install_root = Constants.getWasInstallRootPath();
const wlp_template_path = Constants.getWlpTemplatePath();
const wlp_common_path = Constants.getWlpCommonPath();
const wasOps_path = Constants.getWasOpsPath();
const im_install_root = Constants.getImInstallRootPath();
const im_data_root = Constants.getImDataRootPath();
const im_shared_root = Constants.getImSharedRootPath();
const im_install = Constants.getImInstallPath();
const im_shared = Constants.getImSharedPath();


export class JdkInstallation {

  hostName: string = "";
  task: string = "jdkInstall";
  update: string = "";
  source: string = wlp_basedir + "WAS_Liberty_WLP_VERSION_Multiplatform_Patches/java.J_VERSION.tar";
  location: string = wlp_install_root + "/CELL_NAME";
  sourceRoot: string = "java/8.0";
  current: string = "java/current";
  target: string = "java/java.J_VERSION";

  constructor(hostName: string, cellName: string, selectedWlpVersion: string, selectedJavaVersion: string) {


    this.hostName = hostName;
    this.source = this.source.replace("WLP_VERSION", selectedWlpVersion.replace(/\./g, ''));
    this.location = this.location.replace("CELL_NAME", cellName);
    this.source = this.source.replace("J_VERSION", selectedJavaVersion);
    this.target = this.target.replace("J_VERSION", selectedJavaVersion);
  }
}

export class WlpInstallation {

  hostName: string = "";
  task: string = "wlpInstall";
  update: string = "";
  source: string = wlp_basedir + "WAS_Liberty_WLP_VERSION_Multiplatform_Patches/";
  sourceRoot: string = "wlp-PRODUCT_TYPE-all-WLP_VERSION";
  type: string = "jar";
  location: string = wlp_install_root + "/CELL_NAME/";
  jdkloc: string = "CELL_NAME/java/current";

  constructor(hostName: string, cellName: string, selectedWlpVersion: string) {

    this.hostName = hostName;
    this.source = this.source.replace("WLP_VERSION", selectedWlpVersion.replace(/\./g, ''));
    this.sourceRoot = this.sourceRoot.replace("WLP_VERSION", selectedWlpVersion);
    this.location = this.location.replace("CELL_NAME", cellName);
    this.jdkloc = this.jdkloc.replace("CELL_NAME", cellName);
    var cell = cellName.split("-");
    var wlpType = cell[1];

    if (wlpType == "wlc") {
      this.sourceRoot = this.sourceRoot.replace("PRODUCT_TYPE", "core");
      this.source += this.sourceRoot + "." + this.type;
      this.location += this.sourceRoot;
    }
    else if (wlpType == "wlb") {
      this.sourceRoot = this.sourceRoot.replace("PRODUCT_TYPE", "base");
      this.source += this.sourceRoot + "." + this.type;
      this.location += this.sourceRoot;
    }
    else if (wlpType == "wln") {
      this.sourceRoot = this.sourceRoot.replace("PRODUCT_TYPE", "nd");
      this.source += this.sourceRoot + "." + this.type;
      this.location += this.sourceRoot;
    }
  }
}

export class ServerTask {

  httpPort: string = "";
  httpsPort: string = "";
  serverName: string = "";
  webserverSecurePort: string = "";
  webserverPort: string = "";
  ihsName: string = "";
  minHeap: string = "";
  maxHeap: string = "";
  jvmEnv: string = wlp_template_path + "wlc/jvm/server.env"
  appDeploy: string[] = [
    wlp_common_path + "shared/DefaultApplication.ear"
  ];
  runCommands: string = "true";
  startServer: string = "true";

  constructor() {
  }

}


export class WlpConfigurations {

  hostName: string = "";
  wlpBinary: string = wlp_install_root + "/CELL_NAME/wlp-PRODUCT_TYPE-all-WLP_VERSION";
  wlp: string = "wlp";
  wlpLink: string = "true";
  javaHome: string = wlp_install_root + "/CELL_NAME/java/current";
  keyStoreJKS: string = wlp_template_path + "WLP_TYPE/key.jks";
  trustStoreJKS: string = wlp_template_path + "WLP_TYPE/trust.jks";
  serverEnv: string = wlp_template_path + "WLP_TYPE/server.env";
  serverXML: string = wlp_template_path + "WLP_TYPE/server.xml";
  jvmOptions: string = wlp_template_path + "WLP_TYPE/jvm.options";
  sharedDir: any = {
    "app_config_xml": wlp_common_path + "shared/app_config.xml",
    "ldap_xml": wlp_common_path + "shared/ldap.xml",
    "plugin_xml": wlp_common_path + "shared/plugin.xml"
  };
  servers: ServerTask[] = [];

  constructor(hostName: string, cellName: string, selectedWlpVersion: string, isCollectiveController: boolean) {

    this.hostName = hostName;
    this.wlpBinary = this.wlpBinary.replace("WLP_VERSION", selectedWlpVersion);
    this.wlpBinary = this.wlpBinary.replace("CELL_NAME", cellName);
    this.javaHome = this.javaHome.replace("CELL_NAME", cellName);
    var cell = cellName.split("-");
    var wlpType = cell[1];

    this.keyStoreJKS = this.keyStoreJKS.replace("WLP_TYPE", wlpType);
    this.trustStoreJKS = this.trustStoreJKS.replace("WLP_TYPE", wlpType);
    this.serverEnv = this.serverEnv.replace("WLP_TYPE", wlpType);
    if (isCollectiveController) {
      this.serverXML = this.serverXML.replace("WLP_TYPE", "cntrlr");
    }
    else {
      this.serverXML = this.serverXML.replace("WLP_TYPE", wlpType);
    }

    this.jvmOptions = this.jvmOptions.replace("WLP_TYPE", wlpType)

    if (wlpType == "wlc") {
      this.wlpBinary = this.wlpBinary.replace("PRODUCT_TYPE", "core");
    }
    else if (wlpType == "wlb") {
      this.wlpBinary = this.wlpBinary.replace("PRODUCT_TYPE", "base");
    }
    else if (wlpType == "wln") {
      this.wlpBinary = this.wlpBinary.replace("PRODUCT_TYPE", "nd");
    }
  }

  createServerTasks(node: LibertyNodeTemplate, data: any) {
    // For each node, we want to create the Server Task 
    this.hostName = node.hostName;
    var self = this;
    var ihsCount = 0;

    node.jvmTemplates.forEach(function (jvmTemplate, i) {
      var server = new ServerTask();
      ihsCount = i;
      server.serverName = jvmTemplate.jvmName;
      if (node.isCollectiveController) {
        server.httpPort = jvmTemplate.portBlock + '60';
        server.httpsPort = jvmTemplate.portBlock + '63';
      }
      else {
        server.httpPort = jvmTemplate.portBlock + '80';
        server.httpsPort = jvmTemplate.portBlock + '43';
      }

      if (node.ihsTemplates.length == 0) {
        // Check if IHS is on another node
        data.nodeTemplates.forEach(n => {
          if (n.ihsTemplates.length > 0 && n.numJvms == 0) {
            if (i < n.ihsTemplates.length) {
              server.webserverSecurePort = n.ihsTemplates[i].portBlock + '43';
              server.webserverPort = n.ihsTemplates[i].portBlock + '80';
              server.ihsName = n.ihsTemplates[i].ihsName;
            } else {
              ihsCount = 0;
              server.webserverSecurePort = n.ihsTemplates[0].portBlock + '43';
              server.webserverPort = n.ihsTemplates[0].portBlock + '80';
              server.ihsName = n.ihsTemplates[0].ihsName;
            }
          }
        });

        if (server.ihsName == "") {
          delete server.ihsName;
          delete server.webserverPort;
          delete server.webserverSecurePort;
        }

      } else if (i < node.ihsTemplates.length) {
        server.webserverSecurePort = node.ihsTemplates[i].portBlock + '43';
        server.webserverPort = node.ihsTemplates[i].portBlock + '80';
        server.ihsName = node.ihsTemplates[i].ihsName;
      } else {
        ihsCount = 0;
        server.webserverSecurePort = node.ihsTemplates[0].portBlock + '43';
        server.webserverPort = node.ihsTemplates[0].portBlock + '80';
        server.ihsName = node.ihsTemplates[0].ihsName;
      }

      server.minHeap = jvmTemplate.minHeap;
      server.maxHeap = jvmTemplate.maxHeap;
      self.servers.push(server);
    });
  }
}


export class InstallationManager {

  hostName: string = "";
  task: string = "imInstall";
  templateVer: string = "v185";
  repositoryLocation: string = nas_path + "etsapps/InstallManager/v185";
  installLocation: string = im_install;
  dataLocation: string = "/export/home/RUNASID" + im_data_root;

  constructor(runAsId: string, installAsRoot: boolean) {
    this.dataLocation = this.dataLocation.replace("RUNASID", runAsId);
    if(installAsRoot){
      this.installLocation = im_install_root;
      this.dataLocation = im_data_root;
    }
  }
}

export class DeployPackage {

  hostName: string = "";
  startProduct: string = "start"
  responses: DeployPackageTask[] = [];

  constructor() { }

  createDeployPackageTasks(cellname: string, installRoot: string, selectedIhsVersion: string, node: LibertyNodeTemplate) {
    var self = this;
    // For each node, we want to create the Deployment Package createDeployPackageTasks
    this.hostName = node.hostName;
    selectedIhsVersion = selectedIhsVersion.replace(/\./g, '');

    node.ihsTemplates.forEach(function (ihsTemplate) {
      var root_install = ihsTemplate.installAsRoot;
      var ihsInstall = new DeployPackageTask(installRoot, root_install);
      ihsInstall.task = "ihsInstall";
      ihsInstall.templateVer = selectedIhsVersion;
      ihsInstall.pkgLoc = "HTTPServer";
      ihsInstall.pkgName = ihsTemplate.ihsName;
      ihsInstall.httpPort = ihsTemplate.portBlock + '80';
      ihsInstall.adminPort = ihsTemplate.portBlock + '60';
      self.responses.push(ihsInstall);

      var plgInstall = new DeployPackageTask(installRoot, root_install);
      plgInstall.task = "plgInstall";
      plgInstall.templateVer = selectedIhsVersion;
      plgInstall.pkgLoc = "Plugins";
      plgInstall.pkgName = ihsTemplate.ihsName;
      self.responses.push(plgInstall);
    });
  }

}

export class DeployPackageTask {

  task: string = "";
  templateVer: string = "";
  sharedLocation: string = "";
  imLocation: string = "";
  pkgLoc: string = "";
  pkgName: string = "";
  installLocation: string = "";
  respPath: string = "";
  httpPort: string = "";
  adminPort: string = "";

  constructor(installRoot: string, installAsRoot: boolean) {
    var installRoot = wlp_install_root;
    this.sharedLocation = im_shared;
    this.imLocation = im_install + '/tools';
    this.installLocation = installRoot;
    if(installAsRoot){
      this.sharedLocation = im_shared_root;
      this.imLocation = im_install_root + '/tools';
    }
  }

}

export class MergePluginsRemote {
  sourcePath: SourcePathTask[] = [];
  targetPath: TargetPathTask[] = [];

  constructor() { }


  createSourcePathTasks(node: LibertyNodeTemplate, data: any) {
    var self = this;
    // For each node, we want to create the Source Path Tasks
    node.jvmTemplates.forEach(function (jvmTemplate) {
      var jvm = new SourcePathTask();
      jvm.host = node.hostName;
      jvm.plgName = wlp_install_root + "/" + data.cellname + "/config/servers/" + jvmTemplate.jvmName + "/logs/state/plugin-cfg.xml";
      self.sourcePath.push(jvm);
    });
  }

  createTargetPathTasks(node: LibertyNodeTemplate, data: any) {
    var self = this;
    // For each node, we want to create the Target Path Tasks
    node.ihsTemplates.forEach(function (ihsTemplate) {
      var ihs = new TargetPathTask();
      ihs.host = node.hostName;
      ihs.plgDir = wlp_install_root + "/" + ihsTemplate.ihsName + "/Plugins/config/" + ihsTemplate.ihsName;
      self.targetPath.push(ihs);
    });
  }
}


export class SourcePathTask {

  host: string = "";
  plgName: string = "";

  constructor() {

  }
}

export class TargetPathTask {

  host: string = "";
  plgDir: string = "";

  constructor() {

  }
}

export class CopyFile {

  task: string = "copyFile";
  hostName: string = "";
  fileName: FileName[] = [];

  constructor(ihsName: string, hostName: string, node: LibertyNodeTemplate, data) {
    this.hostName = hostName;

    var kdb = new FileName();
    kdb.source = wlp_common_path + "HTTP/HTTP.kdb";
    kdb.target = wlp_install_root + "/" + ihsName + "/HTTPServer/conf/" + ihsName + ".kdb";
    delete kdb.targetDir;
    this.fileName.push(kdb);

    var sth = new FileName();
    sth.source = wlp_common_path + "HTTP/HTTP.sth";
    sth.target = wlp_install_root + "/" + ihsName + "/HTTPServer/conf/" + ihsName + ".sth";
    delete sth.targetDir;
    this.fileName.push(sth);

    var pluginKey = new FileName();
    pluginKey.source = wlp_common_path + "Plugin/plugin-key.*";
    pluginKey.targetDir = wlp_install_root + "/" + ihsName + "/Plugins/config/" + ihsName;
    delete pluginKey.target;
    this.fileName.push(pluginKey);

    var healthCheck = new FileName();
    healthCheck.source = wlp_common_path + "HTTP/healthcheck.html";
    healthCheck.targetDir = wlp_install_root + "/" + ihsName + "/HTTPServer/htdocs/slb/";
    delete healthCheck.target;
    this.fileName.push(healthCheck);

  }
}

export class AppendLine {

  task: string = "appendLine";
  backup: string = "true";
  fileName: string = wlp_install_root + "/IHS_NAME/HTTPServer/conf/httpd.conf";
  newLine: string[];

  constructor(ihsName: string, ihsSecurePort: string) {
    this.fileName = this.fileName.replace("IHS_NAME", ihsName);
    ihsSecurePort = ihsSecurePort + "43";
    this.newLine = [
      "## Stability Pack 2015",
      "LimitRequestFieldSize  85536",
      "",
      "<VirtualHost *:" + ihsSecurePort + ">",
      "  SSLEnable",
      "  SSLProtocolEnable TLSv12",
      "  SSLProtocolDisable SSLv2 SSLv3 TLSv10 TLSv11",
      "  SSLCipherSpec ALL -TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA -TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA -SSL_RSA_WITH_3DES_EDE_CBC_SHA",
      "  SSLServerCert AriesWild",
      "</VirtualHost>",
      "KeyFile " + wlp_install_root + "/" + ihsName + "/HTTPServer/conf/" + ihsName + ".kdb",
      "",
      "## Load the Websphere Plugins",
      "LoadModule was_ap22_module " + wlp_install_root + "/" + ihsName + "/Plugins/bin/64bits/mod_was_ap22_http.so",
      "WebSpherePluginConfig " + wlp_install_root + "/" + ihsName + "/Plugins/config/" + ihsName + "/plugin-cfg.xml",
      "",
      ""];
  }
}

export class ReplaceLine {

  task: string = "replaceLine";
  backup: string = "false";
  fileName: string = wlp_install_root + "/IHS_NAME/HTTPServer/conf/httpd.conf";
  replace: IhsConfLine[] = [];

  constructor(ihsName: string, ihsSecurePort: string, runAsId: string) {
    this.fileName = this.fileName.replace("IHS_NAME", ihsName);
    ihsSecurePort = ihsSecurePort + "43";

    var modExpires = new IhsConfLine();
    modExpires.oldline = "#LoadModule expires_module modules/mod_expires.so";
    modExpires.newline = "LoadModule expires_module modules/mod_expires.so";
    this.replace.push(modExpires);

    var modDeflate = new IhsConfLine();
    modDeflate.oldline = "#LoadModule deflate_module modules/mod_deflate.so";
    modDeflate.newline = "LoadModule deflate_module modules/mod_deflate.so";
    this.replace.push(modDeflate);

    var modSSL = new IhsConfLine();
    modSSL.oldline = "#LoadModule ibm_ssl_module modules/mod_ibm_ssl.so";
    modSSL.newline = "LoadModule ibm_ssl_module modules/mod_ibm_ssl.so";
    this.replace.push(modSSL);

    var listen = new IhsConfLine();
    listen.oldline = "#Listen 443";
    listen.newline = "Listen *:" + ihsSecurePort;
    this.replace.push(listen);

    var serverLimit = new IhsConfLine();
    serverLimit.oldline = "ServerLimit           12";
    serverLimit.newline = "ServerLimit           20";
    this.replace.push(serverLimit);

    var startServers = new IhsConfLine();
    startServers.oldline = "StartServers           1";
    startServers.newline = "StartServers           2";
    this.replace.push(startServers);

    var maxClients = new IhsConfLine();
    maxClients.oldline = "MaxClients          1200";
    maxClients.newline = "MaxClients          1800";
    this.replace.push(maxClients);

    var minSpareThreads = new IhsConfLine();
    minSpareThreads.oldline = "MinSpareThreads       50";
    minSpareThreads.newline = "MinSpareThreads       100";
    this.replace.push(minSpareThreads);

    var maxSpareThreads = new IhsConfLine();
    maxSpareThreads.oldline = "MaxSpareThreads      600";
    maxSpareThreads.newline = "MaxSpareThreads      100";
    this.replace.push(maxSpareThreads);

    var maxKeepAlive = new IhsConfLine();
    maxKeepAlive.oldline = "MaxKeepAliveRequests 100";
    maxKeepAlive.newline = "MaxKeepAliveRequests 500";
    this.replace.push(maxKeepAlive);

    var user = new IhsConfLine();
    user.oldline = "User nobody";
    user.newline = "User " + runAsId;
    this.replace.push(user);

    var group = new IhsConfLine();
    group.oldline = "Group nobody";
    group.newline = "Group wasusr";
    this.replace.push(group);

  }
}

export class FileName {

  source: string = "";
  target: string = "";
  targetDir: string = "";

  constructor() { }
}

export class IhsConfLine {
  oldline: string = "";
  newline: string = "";

  constructor() { }
}


export class RestartServers {

  type: string = "";
  host: string = "";
  adminctl: string = "false"
  serverName: string = "";

  constructor() { }
}

export class LogRotate {

  confLocation: string = wlp_install_root + "/allstate/conf/logrotate.conf";
  cronLocation: string = "/etc/cron.daily/logrotate";
  options: string[] = [
    "daily",
    "rotate 14",
    "compress",
    "missingok",
    "notifempty",
    "copytruncate",
    "dateext"
  ];
  logs: LogTask[] = [];

  constructor() { }

  createLogTasks(node: LibertyNodeTemplate, data: any) {
    var self = this;
    var logTask = new LogTask();
    // For each node, we want to create the Log Tasks
    node.jvmTemplates.forEach(function (jvmTemplate) {
      logTask.host = node.hostName;
      logTask.logName.push(
        wlp_install_root + "/" + data.cellname + "/config/servers/" + jvmTemplate.jvmName + "/logs/messages.log",
        wlp_install_root + "/" + data.cellname + "/config/servers/" + jvmTemplate.jvmName + "/logs/console.log");
    });

    node.ihsTemplates.forEach(function (ihsTemplate) {
      logTask.host = node.hostName;
      logTask.logName.push(
        wlp_install_root + "/" + ihsTemplate.ihsName + "/HTTPServer/logs/access_log",
        wlp_install_root + "/" + ihsTemplate.ihsName + "/HTTPServer/logs/error_log",
        wlp_install_root + "/" + ihsTemplate.ihsName + "/Plugins/logs/" + ihsTemplate.ihsName + "/http_plugin.log");
    });

    self.logs.push(logTask);
  }
}

export class LogTask {
  host: string = "";
  logName: string[] = [];

  constructor() { }

}


export class AddCCMembers {
  privateKey: string = "";
  keyLoc: string = "";
  ccHost: string = "";
  ccPort: string = "";
  ccLocation: string = wlp_install_root + "/";
  ccName: string = "";
  keystorePW: string = "2";
  javaHome: string = "";
  members: MembersTask[] = [];

  constructor() { }


  createMembersTasks(node: LibertyNodeTemplate, data: any) {
    var self = this;
    this.ccLocation = wlp_install_root + "/";
    this.ccHost = node.collHostName;
    this.ccPort = node.collPortNumber;
    this.ccLocation += node.collCellName;
    this.ccName = node.collControllerName;
    this.javaHome = node.collJavaPath;
    var member = new MembersTask();
    member.updateHost = node.hostName + ".allstate.com";
    // For each node, we want to create the Members Tasks
    node.jvmTemplates.forEach(function (jvmTemplate) {
      member.memName.push(
        jvmTemplate.jvmName);
    });
    member.memLocation = member.memLocation.replace("CELL_NAME", data.cellname);
    member.javaHome = member.javaHome.replace("CELL_NAME", data.cellname);
    member.hostReadPath = member.hostReadPath.replace("CELL_NAME", data.cellname);
    member.hostWritePath = member.hostReadPath;
    member.user = node.collAdminUser;
    member.createConfigFile = member.createConfigFile.replace("CELL_NAME", data.cellname);
    self.members.push(member);
  }
}

export class MembersTask {
  updateHost: string = "";
  memName: string[] = [];
  memLocation: string = wlp_install_root + "/CELL_NAME";
  javaHome: string = wlp_install_root + "/CELL_NAME/java/current";
  userDir: string = "config";
  hostReadPath: string = wlp_install_root + "/CELL_NAME/config";
  hostWritePath: string = wlp_install_root + "/CELL_NAME/config";
  user: string = "";
  password: string = "";
  createConfigFile: string = wlp_install_root + "/CELL_NAME/config/shared/collective_member.xml";
  collective: string[] = [
    wlp_template_path + "cntrlr/collectiveTrust.jks",
    wlp_template_path + "cntrlr/serverIdentity.jks"
  ];
  security: string[] = [
    wlp_template_path + "cntrlr/key.jks",
    wlp_template_path + "cntrlr/trust.jks"
  ];
}

export class CcConfigurations {
  ccHost: string = "";
  ccLocation: string = wlp_install_root + "/CELL_NAME";
  wlp: string = "wlp";
  ccName: string = "";
  keystorePW: string = "2";
  collective: string[] = [
    wlp_template_path + "cntrlr/collectiveTrust.jks",
    wlp_template_path + "cntrlr/serverIdentity.jks"
  ];
  security: string[] = [
    wlp_template_path + "cntrlr/key.jks",
    wlp_template_path + "cntrlr/trust.jks"
  ];

  constructor(jvm: JvmTemplate, node: LibertyNodeTemplate, data: any) {
    this.ccHost = node.hostName;
    this.ccLocation = this.ccLocation.replace("CELL_NAME", data.cellname);
    this.ccName = jvm.jvmName;
  }
}


export class CcReplicaSet {
  ccHost: string = "";
  ccPort: string = "";
  ccLocation: string = wlp_install_root + "/CELL_NAME";
  serverName: string = "";
  javaHome: string = wlp_install_root + "/CELL_NAME/java/current";
  serverEnv: string = wlp_template_path + "wln/server.env";
  serverXML: string = wlp_template_path + "cntrlr/server.xml";
  jvmOptions: string = wlp_template_path + "wln/jvm.options";
  configFile: string = wlp_install_root + "/CELL_NAME/config/shared/collective_replicaX.xml";
  replicaPort: string = "1001X";
  importCerts: Object;
  removeLines: Object[] = [];
  appendElm: Object[] = [];
  server: Object;

  constructor(jvm: JvmTemplate, node: LibertyNodeTemplate, data: any, index: any) {
    this.ccHost = node.hostName;
    this.ccLocation = this.ccLocation.replace("CELL_NAME", data.cellname);
    this.ccPort = data.nodeTemplates[0].jvmTemplates[0].portBlock.toString() + +'63';
    this.serverName = jvm.jvmName;
    this.javaHome = this.javaHome.replace("CELL_NAME", data.cellname);
    this.configFile = this.configFile.replace("CELL_NAME", data.cellname);
    this.configFile = this.configFile.replace("X", index);
    this.replicaPort = this.replicaPort.replace("X", index);
    this.importCerts = new Object();

    var tempObj = new Object();
    tempObj['location'] = "security";
    tempObj['srckeystore'] = wlp_template_path + "cntrlr/key.jks";
    tempObj['destkeystore'] = "key.jks";
    var tempArray = new Array();
    tempArray.push(tempObj);

    var tempObj2 = new Object();
    tempObj2['fileName'] = this.configFile;
    tempObj2['start'] = "<!-- TODO: Define the security configuration exactly as defined in the";
    tempObj2['endBefore'] = "</server>";

    var tempObj3 = new Object();
    tempObj3['fileName'] = this.ccLocation + "/config/servers/" + this.serverName + "/server.xml";
    tempObj3['name'] = "include";
    tempObj3['attib'] = "location";
    tempObj3['attibValue'] = "${wlp.user.dir}/shared/collective_replica" + index + ".xml";

    this.importCerts['keytool'] = tempArray;
    this.removeLines.push(tempObj2);
    this.appendElm.push(tempObj3);
    this.server = new Object();
    this.server['httpPort'] = jvm.portBlock + "60";
    this.server['httpsPort'] = jvm.portBlock + "63";
    this.server['minHeap'] = jvm.minHeap;
    this.server['maxHeap'] = jvm.maxHeap;
    this.server['startServer'] = "true";
  }
}

@Injectable()
export class LibertyDataTransformService {

  wasHome: string = "";

  constructor() { }

  createDocId() {
    var docId = "";
    // Create a new Doc ID using the format: cellname-timestamp.
    docId = new Date(Date.now()).toISOString();
    docId = docId.replace(/:/g, '.');
    return docId;
  }

  formatInstallManager(data) {
    var installMgr = [];
    var numIhs = 0;
    var root_im = false;
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.ihsTemplates.length != 0) {
        numIhs += node.ihsTemplates.length;
        if(node.ihsTemplates[0].installAsRoot){
          root_im = true;
        }
        var imgr = new InstallationManager(data.runasId, root_im);
        imgr.hostName = node.hostName;
        installMgr.push(imgr);
      }
    });
    if (numIhs == 0) {
      return null
    } else {
      return installMgr;
    }
  }

  formatPackages(data) {
    var packages = [];
    var numIhs;
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.ihsTemplates.length != 0) {
        numIhs += node.ihsTemplates.length;
        var pkg = new DeployPackage();
        pkg.createDeployPackageTasks(data.cellname, data.installRoot, data.selectedIhsVersion, node);
        packages.push(pkg);
      }
    });
    if (packages.length == 0) {
      return null
    } else {
      return packages;
    }
  }

  formatWlpInstallation(data) {
    var installWlp = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.numJvms != 0) {
        var wlpInstall = new WlpInstallation(node.hostName, data.cellname, data.selectedWlpVersion);
        installWlp.push(wlpInstall);
      }
    });
    if (installWlp.length != 0) {
      return installWlp;
    } else {
      return null;
    }
  }

  formatGlobalSecurityGroup(securityGroup) {
    var globalSecurityGroup = securityGroup.split(",");
    return globalSecurityGroup;
  }

  formatGlobalSecurityUser(securityUser) {
    var globalSecurityUser = securityUser.split(",");
    return globalSecurityUser;
  }

  formatJdkInstallation(data) {
    var manageJdk = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.numJvms != 0) {
        var jdkInstall = new JdkInstallation(node.hostName, data.cellname, data.selectedWlpVersion, data.selectedJavaVersion);
        manageJdk.push(jdkInstall);
      }
    });
    if (manageJdk.length != 0) {
      return manageJdk
    } else {
      return null;
    }
  }

  formatWlpConfigurations(data) {
    var wlpConfig = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.numJvms != 0) {
        var wlp = new WlpConfigurations(node.hostName, data.cellname, data.selectedWlpVersion, node.isCollectiveController);
        wlp.createServerTasks(node, data);
        wlpConfig.push(wlp);
      }
    });
    if (wlpConfig.length != 0) {
      if (data.isCollectiveReplicaSet) {
        var servers = [];
        servers.push(wlpConfig[0].servers[0]);
        wlpConfig[0].servers = servers;
      }
      return wlpConfig;
    } else {
      return null;
    }
  }

  formatMergePlugins(data) {
    var mergePlugin = new MergePluginsRemote();
    var totalJvms = 0;

    for (var i = 0; i < data.nodeTemplates.length; i++) {
      totalJvms = data.nodeTemplates[i].numJvms + totalJvms;
    }

    data.nodeTemplates.forEach(node => {
      // Process each node.

      if (totalJvms > 0) {
        mergePlugin.createSourcePathTasks(node, data);
      }

      if (node.ihsTemplates.length > 0) {
        mergePlugin.createTargetPathTasks(node, data);
      }
    });

    if (mergePlugin.sourcePath.length > 0 && mergePlugin.targetPath.length > 0) {
      return mergePlugin;
    }
    else return null;

  }

  formatPostConfig(data) {
    var postConfig = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      // For each node, we want to create the IHS Post Config Tasks.
      node.ihsTemplates.forEach(function (ihsTemplate) {
        postConfig.push(new CopyFile(ihsTemplate.ihsName, node.hostName, node, data));
        postConfig.push(new AppendLine(ihsTemplate.ihsName, ihsTemplate.portBlock));
        postConfig.push(new ReplaceLine(ihsTemplate.ihsName, ihsTemplate.portBlock, data.runasId));
      });
    });

    if (postConfig.length == 0) {
      return null;
    }
    else {
      return postConfig
    }
  }

  formatRestartServers(data) {
    var restartServers = [];
    data.nodeTemplates.forEach(node => {
      // Process each node.
      node.jvmTemplates.forEach(function (jvmTemplate) {
        var jvm = new RestartServers();
        jvm.type = "wlp";
        jvm.serverName = jvmTemplate.jvmName;
        jvm.host = node.hostName;
        delete jvm.adminctl;
        restartServers.push(jvm);
      });

      node.ihsTemplates.forEach(function (ihsTemplate) {
        var ihs = new RestartServers();
        ihs.type = "ihs";
        ihs.serverName = ihsTemplate.ihsName;
        ihs.host = node.hostName;
        restartServers.push(ihs);
      });
    });
    return restartServers;
  }


  formatLogRotate(data) {
    var logRotate = [];
    var log = new LogRotate();
    data.nodeTemplates.forEach(node => {
      // Process each node.
      log.createLogTasks(node, data);

    });
    logRotate.push(log);
    return logRotate;

  }

  formatAddCCMembers(data) {
    var addCCMembers = [];
    var member = new AddCCMembers();
    data.nodeTemplates.forEach(node => {
      // Process each node.
      if (node.isCollectiveMember) {
        member.createMembersTasks(node, data);
      }
    });
    if (member.ccName == "") {
      return null
    }
    else {
      addCCMembers.push(member);
      return addCCMembers;
    }
  }


  formatCcConfigurations(data) {
    var ccConfigurations = [];
    if (data.isCollectiveReplicaSet) {
      var ccConfig = new CcConfigurations(data.nodeTemplates[0].jvmTemplates[0], data.nodeTemplates[0], data);
      delete ccConfig.keystorePW;
      delete ccConfig.collective;
      delete ccConfig.security;
      ccConfigurations.push(ccConfig);
    }
    else {
      data.nodeTemplates.forEach(node => {
        // Process each node.
        if (node.isCollectiveController) {
          node.jvmTemplates.forEach(jvmTemplate => {
            var ccConfig = new CcConfigurations(jvmTemplate, node, data);
            ccConfigurations.push(ccConfig);
          });
        }
      });

    }
    if (ccConfigurations.length > 0) {
      return ccConfigurations;
    }
    else {
      return null;
    }
  }

  formatCcReplicaSet(data) {
    var ccReplica = [];
    var replicaNum = 1;
    if (data.isCollectiveReplicaSet) {
      data.nodeTemplates.forEach(node => {
        // Process each node.
        for (let i = 0; i < node.jvmTemplates.length; i++) {
          if (node.jvmTemplates[i].jvmName.split("-").pop() !== "01") {
            var replica = new CcReplicaSet(node.jvmTemplates[i], node, data, replicaNum);
            ccReplica.push(replica);
            replicaNum++;
          }
        }
      });
    }
    if (ccReplica.length > 0) {
      return ccReplica;
    }
    else {
      return null;
    }
  }


  toWlpDeployFormat = function (data) {
    var dest = {
      "docId": this.createDocId(data.cellname),
      "cellId": data.cellname || '',
      "installRoot": "/apps/ki01",
      "reGen": true,
      "ldapId": data.ldapId,
      "ldapBindId": data.ldapBindId,
      "runAsId": data.runasId,
      "deploymentType": 'build',
      "administratorRole": {
        "globalSecurityGroup": this.formatGlobalSecurityGroup(data.globalSecurityGroup),
        "globalSecurityUser": this.formatGlobalSecurityUser(data.ldapId)
      },
      "projectInfo": {
        "projectName": data.appName,
        "tciCode": data.tciCode
      },
      "jdkInstallation": this.formatJdkInstallation(data),
      "wlpInstallation": this.formatWlpInstallation(data),
      "wlpConfigurations": this.formatWlpConfigurations(data),
      "installationManager": this.formatInstallManager(data),
      "packages": this.formatPackages(data),
      "rc": wasOps_path + "wasScripts/boot/bin",
      "mergePluginsRemote": this.formatMergePlugins(data),
      "postConfig": this.formatPostConfig(data),
      "restartServers": this.formatRestartServers(data),
      "logrotate": this.formatLogRotate(data),
      "addCCMembers": this.formatAddCCMembers(data),
      "ccConfigurations": this.formatCcConfigurations(data),
      "ccReplicaSet": this.formatCcReplicaSet(data)

    }; //var dest
    return dest;
  }  //toWlpDeployFormat

  toWlpPatchFormat = function (data) {
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "installRoot": "/apps/ki01",
      "deploymentType": 'patch',
      "wlpInstallation": {
        selectedWlpVersion: data.selectedWlpVersion, selectedIhsVersion: data.selectedIhsVersion,
        rollback: data.rollback, selectedJavaVersion: data.selectedJavaVersion, nodes: data.nodes
      }
    };

    return dest;
  }

  toWlpRollbackFormat = function (data) {
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "installRoot": "/apps/ki01",
      "deploymentType": 'rollback',
      "wlpInstallation": {
        selectedWlpVersion: data.selectedWlpVersion, selectedIhsVersion: data.selectedIhsVersion,
        rollback: data.rollback, selectedJavaVersion: data.selectedJavaVersion, nodes: data.nodes
      }
    };

    return dest;
  }

  toWlpUninstallFormat = function (data) {
    var dest = {
      "docId": this.createDocId(data.cellName),
      "cellId": data.cellName || '',
      "installRoot": "/apps/ki01",
      "deploymentType": 'uninstall',
      "wlpInstallation": { _id: data._id, ihsVersion: data.ihsVersion, nodes: data.nodes }
    };

    return dest;
  }



}  // LibertyDataTransformService

