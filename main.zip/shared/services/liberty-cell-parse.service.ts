import { UditUtils } from './../../../core/uditUtils';
import { WlpVersion } from './../../content/apps/manage/wlpversions/wlpversions.model';
import { Injectable } from '@angular/core';
import { Constants } from '../config/constants';
import { LibertyCell } from '../models/liberty-cell';
import { LibertyNodeTemplate } from '../models/liberty-node-template';
import { JvmTemplate } from '../models/jvm-template';
import { IhsTemplate } from '../models/ihs-template';
import { InventoryService } from './inventory.service';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable()
export class LibertyCellParseService {

  constructor(protected _invService: InventoryService) { }

  convertFromInventoryToDesignFormat = function (data, callback) {
    this.fromInventoryFormat(data, function (cell: LibertyCell) {
      callback(cell);
    });
  }

  fromInventoryFormat = function (data, callback) {
    var self = this;
    var destCell = new LibertyCell();
    destCell._id = data._id;
    destCell.cellname = data.cellName;
    destCell.envNumber = this.getEnvNumber(data.cellName);
    destCell.envTypeCode = this.getEnvType(data.cellName);
    destCell.runasId = data.nodes[0].wlp.runAsID;
    destCell.selectedIhsVersion = data.ihsVersion;

    if (data.ihsVersion) {
      destCell.selectedIhsVersion = data.ihsVersion;
    }

    destCell.selectedJavaVersion = data.javaVersion;
    destCell.selectedWlpVersion = data.wlpVersion;
    destCell.tciCode = data.tciCode;
    destCell.selectedProductType = "Liberty-" + this.getwlpProductType(data);
    Constants.ENV_TYPES.forEach((env) => {
      if (env.slice(0, 2) === destCell.envTypeCode) {
        destCell.selectedEnvType = env;
      }
    });

    destCell.selectedLdapType = Constants.DEF_LDAP_TYPE;
    destCell.ldapId = Constants.DEF_LDAP_ID;
    destCell.numNodes = 0;
    destCell.totalJvms = 0;
    destCell.totalIhs = 0;
    var nodeTemplates: LibertyNodeTemplate[] = [];
    var isCollectiveMember = false;
    var collHostName = '';
    var collPortNumber = '';
    var cell = '';
    var ccName = '';
    var collAdminUser = '';
    var collJavaPath = '';

    if (data.nodes.length > 0) {
      destCell.numNodes = data.nodes.length;
      if (data.nodes[0].wlp && data.nodes[0].wlp.shared.length > 0 && data.nodes[0].wlp.shared.filter(x => x.name === 'ldap').length > 0) {
        destCell.ldapId = this.getValues(data, 'user').find(value => value.includes('sys-'));
        if (!destCell.ldapId) {
          destCell.ldapId = data.nodes[0].wlp.shared.filter(x => x.name === 'ldap')
          [0].content.server['administrator-role'].user.find(value => value.includes("sys-"));
        }
        destCell.globalSecurityGroup = data.nodes[0].wlp.shared.filter(x => x.name === 'ldap')
        [0].content.server['administrator-role'].group.toString();
        destCell.ldapBindId = this.getValues(data, 'bindDN')[0].split(",")[0].slice(3);
      }

      if (data.nodes[0].wlp.shared[0] && data.nodes[0].wlp.shared[0].content.server.collectiveMember) {
        isCollectiveMember = true;
        collHostName = data.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerHost;
        if (collHostName.includes('allstate.com')) {
          collHostName = collHostName.split('.')[0];
        }
        collPortNumber = data.nodes[0].wlp.shared[0].content.server.collectiveMember.controllerPort;

        self.getControllerInfo(collHostName, collPortNumber, function (results) {
          if (results.ccName && results.cellName) {
            cell = results.cellName;
            ccName = results.ccName;
            collAdminUser = results.adminUser;
            collJavaPath = results.javaPath;
          }
          setNodeTemplates(data);
          destCell.nodeTemplates = nodeTemplates;
          destCell.updateNodeNames();
          callback(destCell);
        });
      }
      else {
        if (data.nodes[0].wlp.servers[0].name.includes('-cntrlr-')) {
          destCell.isCollectiveController = true;
        }
        if (data.nodes[0].wlp.servers.length > 1) {
          destCell.isCollectiveReplicaSet = true;
        }
        setNodeTemplates(data);
        destCell.nodeTemplates = nodeTemplates;
        destCell.updateNodeNames();
        console.log(destCell);
        callback(destCell);
      }
    }

    function setNodeTemplates(data) {
      for (var i = 0; i < data.nodes.length; i++) {
        nodeTemplates[i] = new LibertyNodeTemplate();
        nodeTemplates[i].hostName = data.nodes[i].hostName;
        if (data.nodes[i].wlp && data.nodes[i].wlp.servers.length > 0) {
          nodeTemplates[i].numJvms = data.nodes[i].wlp.servers.length;

          if (data.nodes[0].wlp.shared[0] && data.nodes[0].wlp.shared[0].content.server.collectiveMember) {
            nodeTemplates[i].collAdminUser = collAdminUser;
            nodeTemplates[i].collCellName = cell;
            nodeTemplates[i].collControllerName = ccName;
            nodeTemplates[i].collJavaPath = collJavaPath;
            nodeTemplates[i].collPortNumber = collPortNumber;
            nodeTemplates[i].isCollectiveMember = isCollectiveMember;
            nodeTemplates[i].collHostName = collHostName;
          }

          for (var j = 0; j < nodeTemplates[i].numJvms; j++) {
            var jvm = new JvmTemplate();
            jvm.jvmName = data.nodes[i].wlp.servers[j].name;
            if (jvm.jvmName.includes("-cntrlr-")) {
              nodeTemplates[i].isCollectiveController = true;
            }
            jvm.portBlock = data.nodes[i].wlp.servers[j].server.httpEndpoint.httpPort.slice(0, 3);
            jvm.maxHeap = data.nodes[i].wlp.servers[j].jvmOption.find(value => value.startsWith('-Xmx')).split(/(\d+)/)[1];
            jvm.minHeap = data.nodes[i].wlp.servers[j].jvmOption.find(value => value.startsWith('-Xms')).split(/(\d+)/)[1];
            nodeTemplates[i].jvmTemplates[j] = jvm;
          }
          nodeTemplates[i].jvmTemplates.sort(function (a, b) {
            if (a.portBlock < b.portBlock) {
              return -1;
            }
            if (a.portBlock > b.portBlock) {
              return 1;
            }
            return 0;
          });
          destCell.totalJvms += nodeTemplates[i].numJvms;
        }
        if (data.nodes[i].ihs && data.nodes[i].ihs.servers.length > 0) {
          nodeTemplates[i].numHttpServers = data.nodes[i].ihs.servers.length;
          for (var j = 0; j < nodeTemplates[i].numHttpServers; j++) {
            var ihs = new IhsTemplate();
            ihs.ihsName = data.nodes[i].ihs.servers[j].ihsName;
            ihs.hostName = data.nodes[i].hostName;
            ihs.portBlock = data.nodes[i].ihs.servers[j].portBlock;
            nodeTemplates[i].ihsTemplates[j] = ihs;
          }
          nodeTemplates[i].ihsTemplates.sort(function (a, b) {
            if (a.portBlock < b.portBlock) {
              return -1;
            }
            if (a.portBlock > b.portBlock) {
              return 1;
            }
            return 0;
          });
          destCell.totalIhs += nodeTemplates[i].numHttpServers;
        }
      }
    }
  }

  getCCInfo(obj) {
    var cntrlr = {
      controllerHost: '',
      controllerPort: ''
    };
    var results = this.getValues(obj, 'controllerHost');
    for (var i = 0; i < results.length; i++) {
      if (results[i].length > 0) {
        cntrlr.controllerHost = results[i];
      }
    }
    results = this.getValues(obj, 'controllerPort');
    for (var i = 0; i < results.length; i++) {
      if (results[i].length > 0) {
        cntrlr.controllerPort = results[i];
      }
    }
    return cntrlr;
  }

  getControllerInfo(ccHost, ccPort, callback) {
    var ccName = ""
    var cellName = "";
    var collJavaPath = "";
    var collAdminUser = ""
    var values = [];
    var paramObj = {
      "nodes.hostName": ccHost,
      "textSearch": ccPort,
    };
    var paramString = UditUtils.buildQueryParams(paramObj);
    let httpParams = new HttpParams({
      fromString: paramString
    });
    this._invService.getWlpInventory(httpParams)
      .then((data) => {
        data.items.forEach(item => {
          if (item.productEdition === "ND") {
            if (item.nodes[0].wlp) {
              item.nodes[0].wlp.servers.forEach((server) => {
                if (server.server.httpEndpoint.httpsPort === ccPort) {
                  ccName = server.name;
                  cellName = item.cellName;
                  collJavaPath = this.getValues(item.nodes[0].wlp, 'javaHome')[0];
                  values = this.getValues(item.nodes[0].wlp, 'user');
                  for (let i = 0; i < values.length; i++) {
                    if (values[i].indexOf("sys-") >= 0) {
                      collAdminUser = values[i];
                    }
                  }
                  callback({ 'javaPath': collJavaPath, 'adminUser': collAdminUser, 'cellName': cellName, 'ccName': ccName });
                }
              });
            }
          }
        });
      });
  }

  //return an array of values that match on a certain key
  getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;
      if (typeof obj[i] == 'object') {
        objects = objects.concat(this.getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }
    return objects;
  }


  getJavaSDKVersions(cell) {
    var javaVersion: string;
    javaVersion = cell.javaVersion;
    if (!javaVersion) {
      javaVersion = "N/A";
    }
    return javaVersion
  };

  getWlpVersion(cell) {
    var wlpVersion = cell.wlpVersion;
    if (!wlpVersion) {
      wlpVersion = "N/A";
    }
    return wlpVersion;

  };

  getIhsVersion(cell){
    if(cell.ihsVersion){
      return cell.ihsVersion;
    }
    else{
      return "None";
    }
  }

  getWlpInstalled(node){
    return node.wlp.installedWlp;
  }

  getJavaInstalled(node){
    return node.wlp.javaInstalled;
  }

  getwlpProductType(cell) {
    var wlpType = cell.productEdition;

    if (wlpType == "BASE") {
      return "Base";
    }
    else if (wlpType == "LIBERTY_CORE") {
      return "Core";
    }
    else if (wlpType == "ND") {
      return "ND";
    }
    else {
      return "Core";
    }
  };


  getTciCode = function (name) {
    if (typeof name === 'string') {
      return name.split('-')[0] || null;
    }
    return null;
  };

  getEnvType = function (name) {
    return name.split('-')[2].slice(0, 2) || null;
  };

  getEnvNumber = function (name) {
    return name.split('-')[2].slice(2) || null;
  };

  getAdminCenterHostName(node) {
    return node.hostName;
  }

  getAdminCenterLink(jvm, node) {
    var link: string;
    try {
      link = "https://HOSTNAME.allstate.com:HTTPS_PORT/adminCenter";
      link = link.replace("HOSTNAME", this.getAdminCenterHostName(node));
      if (node.wlp.servers[0] && jvm.server.httpEndpoint.httpsPort) {
        link = link.replace("HTTPS_PORT", jvm.server.httpEndpoint.httpsPort)
      }
      else {
        link = link.replace("HTTPS_PORT", "21143");
      }
      return link;

    } catch (e) {
      console.log("ERROR", e)
    }
  }
}