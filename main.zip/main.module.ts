import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../core/modules/shared.module';
import { UditMainComponent } from './main.component';
import { UditContentComponent } from './content/content.component';
import { UditFooterComponent } from './footer/footer.component';
import { UditNavbarVerticalComponent } from './navbar/vertical/navbar-vertical.component';
import { UditToolbarComponent } from './toolbar/toolbar.component';
import { UditNavigationModule } from '../core/components/navigation/navigation.module';
import { UditNavbarVerticalToggleDirective } from './navbar/vertical/navbar-vertical-toggle.directive';
import { UditNavbarHorizontalComponent } from './navbar/horizontal/navbar-horizontal.component';
import { UditQuickPanelComponent } from './quick-panel/quick-panel.component';
import { UditThemeOptionsComponent } from '../core/components/theme-options/theme-options.component';
import { UditShortcutsModule } from '../core/components/shortcuts/shortcuts.module';
import { UditSearchBarModule } from '../core/components/search-bar/search-bar.module';
import { AuthenticationModule } from './content/pages/authentication/authentication.module';

@NgModule({
    declarations: [
        UditContentComponent,
        UditFooterComponent,
        UditMainComponent,
        UditNavbarVerticalComponent,
        UditNavbarHorizontalComponent,
        UditToolbarComponent,
        UditNavbarVerticalToggleDirective,
        UditThemeOptionsComponent,
        UditQuickPanelComponent
    ],
    imports     : [
        SharedModule,
        RouterModule,
        UditNavigationModule,
        UditShortcutsModule,
        UditSearchBarModule,
        AuthenticationModule
    ],
    exports     : [
        UditMainComponent
    ]
})

export class UditMainModule
{
}
